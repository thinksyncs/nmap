"""Replay saved application bytes with controlled transport on localhost only.

The candidate retries version queries only after complete requested AppNames
boundaries. Synthetic buffering, segmentation and failures are separate
from live application measurements. The comparison baseline is the frozen 0dd
implementation, which can close the original stream during handoff.
"""

import argparse
import errno
import hashlib
import json
import math
import re
import shutil
import socket
import socketserver
import struct
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POSITIVE = ROOT / "tests/fixtures/real/netbuster/combined-default.json"
NEGATIVE = ROOT / "tests/fixtures/real/netbus/combined-170.json"
INFO_112 = ROOT / "tests/fixtures/real/netbuster/getinfo-112-default.json"
INFO_130 = ROOT / "tests/fixtures/real/netbuster/getinfo-130-default.json"
INFO_170 = ROOT / "tests/fixtures/real/netbus/getinfo-170-complete.json"
REQUEST = b"nbver\rGetInfo\r"
INFO_REQUEST = b"GetInfo\r"
VERSION_REQUEST = b"nbver\r"
APPS_REQUEST = b"GetApps\r"
APPS_BOUNDARY = b"AppNames;synthetic window|title\r"
INFO_SIGNATURE = b"Info;Your IP is logged and you will be nuked VERY soon!\r"
HOLD_SECONDS = 7
RECORDED_VERSIONS = {b"1.30-1-1": "1.30", b"1.31-1-1": "1.31"}
UNSUPPORTED_VERSIONS = {"unsupported_112": b"1.12-1-1", "unsupported_129": b"1.29-1-1",
                        "other_version": b"1.32-1-1", "unsupported_200": b"2.00-1-1"}
FORCED_ONLY = {"unrelated_banner", "banner_eof", "banner_timeout", "no_banner_timeout"}
PAIRED_CASES = ("buffer400_version", "buffer400_info112", "buffer400_info112_busy_banner",
                "late600_version_refuse", "late600_info112_refuse")
RECOVERY_CASES = ("compound_eof_split_info", "compound_eof_split_silent",
    "late600_version_refused", "late1500_version_refused", "late600_partial_banner",
    "late1500_partial_banner", "partial1_late1500_refused", "during_banner_full",
    "during_banner_partial", "handoff_late_lost")
APPS_CASES = ("apps_requery", "apps_empty", "apps_split_1", "apps_split_9",
    "apps_split_cr", "apps_maximum", "apps_only", "apps_partial_version",
    "apps_unsupported_version", "apps_prefix_wrong", "apps_unterminated",
    "apps_oversized", "apps_trailing_version", "apps_trailing_other",
    "apps_after_version_fragment", "apps_embedded", "apps_unsolicited",
    "apps_partial_record_then_version", "apps_requery_eof_valid")
COMPARISON_CASES = RECOVERY_CASES + PAIRED_CASES + ("apps_requery",)
SINGLE_CASES = PAIRED_CASES + RECOVERY_CASES + (
    "split_command_recovery", "info_retry_2", "info_retry_4", "info_late_before_deadline",
    "partial_info_no_retry", "partial_version_no_retry", "default_then_version",
    "custom_then_version", "partial_then_version", "other_then_version", "silent",
    "retry_eof_valid", "retry_reset_valid", "retry_eof_partial", "retry_eof_timeout",
    "retry_eof_late_timeout", "trickle_info",
)
INFO_CASES = ("info112_real", "info112_hold", "info112_repeat", "info112_split_1",
              "info112_split_55", "info112_altered", "info112_embedded", "info112_extra",
              "info112_timeout_0", "info112_timeout_55", "info_retry_valid",
              "info_retry_then_version") + tuple(f"info112_eof_{n}" for n in range(56))
CASES = ("real_positive", "real_negative", "negative_denied", "positive_tail", "valid_eof", "valid_hold",
         "split_banner", "malformed_status", "malformed_count", "unrelated_banner", "banner_eof",
         "banner_timeout", "no_banner_timeout") + tuple(f"split_{n}" for n in range(1,8)) + tuple(
         f"response_eof_{n}" for n in range(8)) + tuple(f"response_timeout_{n}" for n in range(8)) + tuple(
         UNSUPPORTED_VERSIONS) + INFO_CASES + SINGLE_CASES + APPS_CASES
ORDINARY_CASES = ("real_positive", "real_negative", "negative_denied", "valid_hold", "split_7",
                  "response_eof_7", "response_timeout_0", "malformed_status") + tuple(
                  UNSUPPORTED_VERSIONS) + ("info112_real", "info112_split_55", "info112_eof_55",
                  "info112_timeout_55", "info112_altered", "info_retry_valid", "info_retry_then_version") + SINGLE_CASES + APPS_CASES

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def shutdown_write(connection):
    try:
        connection.shutdown(socket.SHUT_WR)
    except OSError as exc:
        # Nmap may close/reset a scan connection while the fixture is holding it.
        # Suppress only peer-disconnection errors from this shutdown operation.
        if exc.errno not in (errno.ENOTCONN, errno.EPIPE, errno.ECONNRESET):
            raise


def load_fixture(path, positive):
    value = json.loads(path.read_text())
    for key in ("banner_hex", "request_hex", "response_hex"):
        if not isinstance(value.get(key), str):
            raise ValueError(f"{path}: missing hexadecimal field {key}")
        value[key.removesuffix("_hex")] = bytes.fromhex(value[key])
    if value["request"] != REQUEST:
        raise ValueError(f"{path}: the recorded request must be exactly nbver CR GetInfo CR")
    if not re.fullmatch(rb"NetBus [\d.]+[^\r]*\r", value["banner"]):
        raise ValueError(f"{path}: expected a complete NetBus banner")
    if positive:
        if value["response"] not in RECORDED_VERSIONS:
            raise ValueError(f"{path}: expected the recorded default NetBuster reply")
        value["version"] = RECORDED_VERSIONS[value["response"]]
    elif value["response"] != b"Info;Pro":
        raise ValueError(f"{path}: expected the recorded eight-byte NetBus reply prefix")
    return value


def load_info_fixture(path):
    value = json.loads(path.read_text())
    for key in ("banner_hex", "request_hex", "response_hex"):
        value[key.removesuffix("_hex")] = bytes.fromhex(value[key])
    if value["request"] != INFO_REQUEST or value["response"] != INFO_SIGNATURE:
        raise ValueError(f"{path}: expected the captured complete default Info record")
    if not re.fullmatch(rb"NetBus [\d.]+[^\r]*\r", value["banner"]):
        raise ValueError(f"{path}: expected a complete NetBus banner")
    return value



def case_spec(case, positive, negative, info112, info_controls, implementation):
    plan = {"mode": "reply", "response": positive["response"], "hold": False,
            "delay": 0, "split": 0, "info_after": 1, "close_delay": 0, "reset": False}
    spec = {"banner": positive["banner"], "signal": True, "version": positive["version"],
            "plans": [plan], "refuse": case.endswith("refuse"), "buffer": case.startswith("buffer400_"),
            "origin": "recorded_application_bytes" if case in {"real_positive", "real_negative", "info112_real"}
                      else "controlled_transport_or_response_mutation", "implementation": implementation}
    if case in {"real_negative", "negative_denied"}:
        spec.update(banner=negative["banner"], signal=False)
        plan["response"] = (info_controls["netbus"]["response"] if case == "real_negative"
                            else b"Info;Sorry, host is password protected.\r")
    elif case == "positive_tail": plan["response"] += b"2345Info;extra\r"
    elif case == "valid_hold": plan["hold"] = True
    elif re.fullmatch(r"split_\d+", case): plan["split"] = int(case.split("_")[1])
    elif case == "malformed_status": plan["response"] = positive["version"].encode() + b"-5-1"; spec["signal"] = False
    elif case == "malformed_count": plan["response"] = positive["version"].encode() + b"-1-X"; spec["signal"] = False
    elif case in UNSUPPORTED_VERSIONS: plan["response"] = UNSUPPORTED_VERSIONS[case]; spec["signal"] = False
    elif case in FORCED_ONLY:
        spec["plans"] = []; spec["signal"] = False
        if case == "unrelated_banner": spec["banner"] = b"unrelated service\r"
        elif case == "no_banner_timeout": spec["banner"] = b""
        else: spec["banner"] = spec["banner"][:-1]
    elif case.startswith(("response_eof_", "response_timeout_")):
        plan["response"] = positive["response"][:int(case.rsplit("_", 1)[1])]
        plan["hold"] = "timeout" in case; spec["signal"] = False
    if case in INFO_CASES:
        plan.update(mode="info", response=info112["response"])
        spec.update(banner=info112["banner"], version=None)
        if case == "info112_hold": plan["hold"] = True
        elif case == "info112_repeat": plan["response"] *= 2
        elif case.startswith("info112_split_"): plan["split"] = int(case.rsplit("_",1)[1])
        elif case == "info112_altered": plan["response"] = plan["response"].replace(b"VERY",b"very"); spec["signal"] = False
        elif case == "info112_embedded": plan["response"] = b"Info;Program Path: " + plan["response"][5:]; spec["signal"] = False
        elif case == "info112_extra": plan["response"] = plan["response"][:-1] + b" extra\r"; spec["signal"] = False
        elif case.startswith(("info112_eof_", "info112_timeout_")):
            plan["response"] = plan["response"][:int(case.rsplit("_",1)[1])]
            plan["hold"] = "timeout" in case; spec["signal"] = False
        elif case in {"info_retry_valid", "info_retry_then_version"}:
            second = dict(plan)
            plan["response"] = info112["response"][:-1]
            if case.endswith("then_version"):
                second.update(mode="reply", response=positive["response"]); spec["version"] = positive["version"]
            spec["plans"].append(second)
    if case in SINGLE_CASES:
        if case in {"buffer400_info112", "buffer400_info112_busy_banner", "late600_info112_refuse"}:
            plan.update(mode="info", response=info112["response"])
            spec["version"] = None
        if case.startswith("buffer400_"):
            plan["mode"] = "buffer"
            if case == "buffer400_info112_busy_banner":
                plan["delay"] = .01
                spec["prospective"] = "delayed_banner"

        elif case.startswith("late600_"):
            plan.update(mode="reply", delay=0.6, hold=True)
            if case == "late600_info112_refuse":
                plan.update(mode="info", delay=0.5)

        elif case == "split_command_recovery":
            spec["plans"] = [dict(plan, mode="info", response=b"Info;Custom message\r"), dict(plan)]
        elif case in {"info_retry_2", "info_retry_4", "info_late_before_deadline"}:
            plan.update(mode="info", response=info112["response"])
            spec["version"] = None
            if case == "info_late_before_deadline": plan["delay"] = 4.7
            else: plan["info_after"] = int(case.rsplit("_",1)[1])
        elif case in {"partial_info_no_retry", "partial_version_no_retry"}:
            plan.update(split=1, split_delay=0.6)
            if case == "partial_info_no_retry": plan["response"] = info112["response"]; spec["version"] = None
        elif case == "default_then_version": plan["response"] = info112["response"] + positive["response"]; spec["version"] = None
        elif case == "custom_then_version": plan["response"] = b"Info;Changed\r" + positive["response"]; spec["signal"] = False
        elif case == "partial_then_version": plan["response"] = info112["response"][:10] + positive["response"]; spec["signal"] = False
        elif case == "other_then_version": plan["response"] = b"x" + positive["response"]; spec["signal"] = False
        elif case == "silent": plan.update(response=b"",hold=True); spec["signal"] = False
        elif case == "trickle_info": plan.update(response=info112["response"][:5],hold=True,trickle=True); spec["signal"] = False
        elif case.startswith("retry_"):
            second = dict(plan)
            plan.update(response=positive["response"][:7], reset="reset" in case)
            if case == "retry_eof_late_timeout": plan["close_delay"] = 4.5
            if case.endswith("partial"): second["response"] = positive["response"][:7]; spec["signal"] = False
            elif case.endswith("timeout"): second.update(response=b"1",hold=True); spec["signal"] = False
            spec["plans"].append(second)
    if case in RECOVERY_CASES:
        spec["prospective"] = "close"
        if case.startswith("compound_"):
            first = dict(plan, response=b"", fragment_eof=True)
            if case.endswith("info"):
                second = dict(plan, mode="info", response=info_controls["1.30"]["response"], split_command=True)
                spec["plans"] = [first, second, dict(plan)]
            else:
                second = dict(plan, response=b"", hold=True, split_command=True)
                spec["plans"] = [first, second, dict(plan, response=b""), dict(plan)]
                spec["prospective"] = "allow"
        elif case == "handoff_late_lost":
            plan.update(delay=1.5, hold=True)
            spec["plans"] = [plan, dict(plan, delay=0, response=b"", hold=False)]
            spec.update(prospective="allow", reject_after=2, signal=implementation == "candidate")
        else:
            delay = 1.5 if "1500" in case else .6
            plan.update(delay=delay, hold=True)
            if case.endswith("refused"):
                spec["real_refusal"] = True
            elif "partial_banner" in case:
                spec["prospective"] = "partial"
            else:
                spec["prospective"] = "delayed_banner"
            if case == "partial1_late1500_refused":
                plan.update(delay=.05, split=1, split_delay=1.45)
            elif case == "during_banner_partial":
                plan.update(split=1, split_delay=.9)
    if case == "compound_eof_split_silent":
        spec["plans"][1].update(apps_response=APPS_BOUNDARY, requery_response=positive["response"])
    if case in APPS_CASES:
        plan.update(response=b"", hold=True, apps_response=APPS_BOUNDARY,
                    requery_response=positive["response"])
        spec["plans"] = [plan]
        if case == "apps_empty": plan["apps_response"] = b"AppNames;\r"
        elif case == "apps_split_1": plan["apps_split"] = 1
        elif case == "apps_split_9": plan["apps_split"] = 9
        elif case == "apps_split_cr": plan["apps_split"] = len(APPS_BOUNDARY)-1
        elif case == "apps_maximum": plan["apps_response"] = b"AppNames;" + b"x"*4086 + b"\r"
        elif case == "apps_only": plan.update(requery_response=b"", requery_hold=True); spec["signal"] = False
        elif case == "apps_partial_version": plan.update(requery_response=positive["response"][:7], requery_hold=True); spec["signal"] = False
        elif case == "apps_unsupported_version": plan["requery_response"] = b"1.32-1-1"; spec["signal"] = False
        elif case == "apps_prefix_wrong": plan["apps_response"] = b"AppNameX;wrong\r"; spec["signal"] = False
        elif case == "apps_unterminated": plan["apps_response"] = APPS_BOUNDARY[:-1]; spec["signal"] = False
        elif case == "apps_oversized": plan["apps_response"] = b"AppNames;" + b"x"*4087 + b"\r"; spec["signal"] = False
        elif case == "apps_trailing_version": plan["apps_response"] += positive["response"]; spec["signal"] = False
        elif case == "apps_trailing_other": plan["apps_response"] += b"x"; spec["signal"] = False
        elif case == "apps_after_version_fragment": plan["apps_response"] = positive["response"][:7]+APPS_BOUNDARY; spec["signal"] = False
        elif case == "apps_embedded": plan["apps_response"] = b"Info;"+APPS_BOUNDARY; spec["signal"] = False
        elif case == "apps_unsolicited": plan.update(response=APPS_BOUNDARY, hold=False); spec["signal"] = False
        elif case == "apps_partial_record_then_version": plan["apps_response"] = APPS_BOUNDARY[:6]+positive["response"]; spec["signal"] = False
        elif case == "apps_requery_eof_valid": plan["requery_response"] = b""
        if case in {"apps_unsupported_version", "apps_after_version_fragment", "apps_embedded"}:
            spec["plans"].append(dict(plan, response=b"x", hold=False))
        elif case == "apps_unsolicited": spec["plans"].append(dict(plan))
        elif case in {"apps_requery", "apps_requery_eof_valid"}:
            spec["plans"].append(dict(plan, response=positive["response"], hold=False))
        if case == "apps_requery": spec["prospective"] = "allow"
    if not spec["signal"] and case not in APPS_CASES and len(spec["plans"]) == 1 and not plan["hold"] and not case.endswith("refuse"):
        spec["plans"].append(dict(plan))
        response = plan["response"]
        if len(response) < 8 and positive["response"].startswith(response) or len(response) < len(INFO_SIGNATURE) and INFO_SIGNATURE.startswith(response):
            spec["plans"].append(dict(plan))
    if case == "retry_eof_partial": spec["plans"].append(dict(spec["plans"][-1]))
    indices = list(range(len(spec["plans"])))
    if implementation == "candidate" and case in {"compound_eof_split_silent", "handoff_late_lost", "apps_requery"}:
        indices = indices[:2 if case == "compound_eof_split_silent" else 1]
    spec["expected_plan_indices"] = indices
    queries, boundary_used = [], False
    for index in indices:
        current = spec["plans"][index]
        queries.append(REQUEST)
        if current["mode"] == "buffer": count = 2 if case.startswith("buffer400_info112") else 1
        elif case == "compound_eof_split_silent" and index == 1: count = 2
        elif implementation == "baseline" and case in {"handoff_late_lost", "apps_requery"} and index == 0: count = 2
        elif case in APPS_CASES and index == 0 and case != "apps_unsolicited": count = 2
        elif not current["response"] and current["hold"]: count = 13
        elif current["mode"] == "info": count = current["info_after"] + math.floor(current["delay"] / 0.4)
        elif case == "during_banner_full": count = 2
        elif case == "during_banner_partial": count = 2
        elif current["delay"]: count = max(0, math.ceil((current["delay"] - 0.1) / 0.4))
        else: count = 0
        requests = [INFO_REQUEST] * count
        first_byte = math.inf if not current["response"] and current["hold"] else (
            (0.5 + current["delay"] if case.startswith("buffer400_info112") else 0.4) if current["mode"] == "buffer" else (
            0.1 + (current["info_after"]-1)*0.4 + current["delay"] if current["mode"] == "info" else
            current["delay"] if current["response"] else 0))
        if implementation == "candidate" and not boundary_used and first_byte > .53 and count >= 2:
            requests.insert(2, APPS_REQUEST); boundary_used = True
            boundary = current.get("apps_response", b"")
            valid_boundary = (boundary.startswith(b"AppNames;") and boundary.endswith(b"\r")
                              and boundary.count(b"\r")==1 and len(boundary)<=4096)
            if valid_boundary:
                requests = requests[:3] + [REQUEST]
                if not current["requery_response"] and current.get("requery_hold"):
                    requests += [INFO_REQUEST]*11
        queries += requests
    spec["queries"] = queries
    return spec


def run_case(nmap, script, case, output, selection, datadir, positive, negative, info112, info_controls, implementation):
    spec = case_spec(case, positive, negative, info112, info_controls, implementation)
    stop, lock = threading.Event(), threading.Lock()
    events, handlers, query_times = [], [], []
    attempts = 0
    active_queries = set()
    def event(**value):
        with lock: events.append(value)
    class Handler(socketserver.BaseRequestHandler):
        def handle(self):
            nonlocal attempts
            done = threading.Event(); workers = []
            with lock: handlers.append(done)
            closed = threading.Event()
            try:
                self.request.settimeout(HOLD_SECONDS + 1)
                with lock: concurrent = bool(active_queries)
                if spec.get("reject_after") and attempts >= spec["reject_after"]:
                    event(unavailable_connection_port=self.client_address[1]); return
                if spec["refuse"] and attempts:
                    event(refused_connection_port=self.client_address[1]); return
                prospective = spec.get("prospective", "close")
                if concurrent and prospective == "close":
                    event(prospective_closed_before_banner=self.client_address[1]); return
                if concurrent and prospective == "partial":
                    self.request.sendall(b"NetBus 1.")
                    event(prospective_partial_banner_port=self.client_address[1])
                    stop.wait(.3); return
                if concurrent and prospective == "delayed_banner":
                    stop.wait(.15)
                    event(prospective_delayed_banner_port=self.client_address[1])
                if case == "split_banner":
                    self.request.sendall(spec["banner"][:3]); stop.wait(0.05)
                    self.request.sendall(spec["banner"][3:])
                elif spec["banner"]: self.request.sendall(spec["banner"])
                if not spec["plans"]:
                    if "timeout" in case: stop.wait(HOLD_SECONDS)
                    shutdown_write(self.request); return
                if spec["buffer"] and attempts == 0: stop.wait(0.4)
                initial = REQUEST
                request = b""
                pending_plan = spec["plans"][min(attempts,len(spec["plans"])-1)]
                if pending_plan.get("fragment_eof"):
                    prefix = self.request.recv(2)
                    if not prefix: return
                    request += prefix
                    event(eof_after_fragment_hex=prefix.hex(), connection_port=self.client_address[1])
                    shutdown_write(self.request)
                if case == "split_command_recovery" and attempts == 0 or pending_plan.get("split_command"):
                    prefix = self.request.recv(2)
                    if not prefix: return
                    request += prefix
                    event(discarded_initial_query_fragment_hex=prefix.hex())
                    if pending_plan.get("split_command"): stop.wait(.05)
                while len(request) < len(initial):
                    chunk = self.request.recv(257 - len(request))
                    if not chunk: return
                    request += chunk
                with lock:
                    index = attempts; attempts += 1
                    active_queries.add(self.client_address[1])
                if index >= len(spec["plans"]): event(error="unexpected additional query connection"); return
                plan = spec["plans"][index]
                if not request.startswith(initial): event(error="unexpected initial request", received_hex=request.hex()); return
                def query(data):
                    now = time.monotonic()
                    query_times.append(now)
                    event(request_hex=data.hex(), connection_port=self.client_address[1], attempt=index+1,
                          elapsed_seconds=now-started)
                query(initial)
                if spec.get("real_refusal") and index == 0:
                    def close_listener():
                        server.shutdown(); server.server_close()
                        with socket.socket() as control:
                            control.settimeout(1)
                            error = control.connect_ex(("127.0.0.1", port))
                        event(listener_closed=True, refusal_control_errno=error,
                              refusal_control_expected=errno.ECONNREFUSED)
                    listener_worker=threading.Thread(target=close_listener,daemon=True)
                    workers.append(listener_worker);listener_worker.start()
                extra = request[len(initial):]
                if spec["buffer"] and index == 0:
                    expected = REQUEST + INFO_REQUEST
                    if request != expected: event(error="controlled first read did not join expected commands", received_hex=request.hex()); return
                    event(buffered_first_read_hex=request.hex(), connection_port=self.client_address[1])
                while extra:
                    command, separator, extra = extra.partition(b"\r")
                    if not separator: event(error="partial buffered command"); return
                    query(command + separator)
                boundary_condition = threading.Condition()
                boundary_replies = boundary_barrier = 0
                def respond(reply_plan, stage):
                    nonlocal boundary_replies
                    try:
                        witness = case == "handoff_late_lost" and stage == "initial" and reply_plan["delay"] > 0
                        if witness:
                            time.sleep(reply_plan["delay"])
                            event(late_complete_send_attempted=True, response_hex=reply_plan["response"].hex(),
                                  connection_port=self.client_address[1], elapsed_seconds=time.monotonic()-started)
                        elif stop.wait(reply_plan["delay"]): return
                        response = reply_plan["response"]
                        if reply_plan.get("trickle"):
                            for i, byte in enumerate(response):
                                if i and stop.wait(0.6): return
                                self.request.sendall(bytes([byte]))
                        elif reply_plan["split"]:
                            self.request.sendall(response[:reply_plan["split"]])
                            if stop.wait(reply_plan.get("split_delay",0.05)): return
                            self.request.sendall(response[reply_plan["split"]:])
                        elif response: self.request.sendall(response)
                        event(sent_response_hex=response.hex(), connection_port=self.client_address[1],
                              response_stage=stage, elapsed_seconds=time.monotonic()-started)
                        if stage == "boundary" and response.startswith(b"AppNames;") and response.endswith(b"\r") and response.count(b"\r")==1 and len(response)<=4096:
                            with boundary_condition:
                                boundary_replies += 1
                                boundary_condition.notify_all()
                        if reply_plan["close_delay"] and stop.wait(reply_plan["close_delay"]): return
                        if not reply_plan["hold"]:
                            with lock: active_queries.discard(self.client_address[1])
                            if reply_plan["reset"]:
                                closed.set()
                                self.request.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack("ii",1,0))
                                self.request.close()
                            else: shutdown_write(self.request)
                    except (BrokenPipeError, ConnectionResetError) as exc:
                        if case == "handoff_late_lost": event(late_response_delivery_error=repr(exc))
                    except OSError as exc:
                        if case == "handoff_late_lost": event(late_response_delivery_error=repr(exc))
                        elif not closed.is_set(): event(error=repr(exc))
                scheduled = False
                def schedule():
                    nonlocal scheduled
                    if scheduled: return
                    scheduled = True
                    worker=threading.Thread(target=respond,args=(plan,"initial"),daemon=True); workers.append(worker); worker.start()
                def schedule_extra(reply_plan, stage):
                    worker=threading.Thread(target=respond,args=(reply_plan,stage),daemon=True)
                    workers.append(worker);worker.start()
                if plan.get("fragment_eof"):
                    with lock: active_queries.discard(self.client_address[1])
                elif plan["mode"] == "reply": schedule()
                elif plan["mode"] == "buffer":
                    if case == "buffer400_version": schedule()
                if plan["reset"]:
                    # Closing a socket in a different thread need not wake a
                    # blocking recv on macOS. This plan sends its RST first.
                    for worker in workers: worker.join(timeout=HOLD_SECONDS + 1)
                    return
                info_count = 0
                apps_count = requery_count = 0
                pending = b""
                while not stop.is_set():
                    chunk=self.request.recv(257)
                    if not chunk: break
                    pending += chunk
                    while b"\r" in pending:
                        if pending.startswith(VERSION_REQUEST):
                            if len(pending)<len(REQUEST): break
                            if not pending.startswith(REQUEST): event(error="unexpected version requery bytes");return
                            command,pending=REQUEST,pending[len(REQUEST):]
                        else:
                            command,_,pending = pending.partition(b"\r"); command += b"\r"
                        query(command)
                        if command == INFO_REQUEST:
                            info_count += 1
                            if plan["mode"] in {"info","buffer"} and info_count >= plan["info_after"]: schedule()
                        elif command == APPS_REQUEST:
                            apps_count += 1
                            if apps_count>6: event(error="boundary request limit exceeded");return
                            if "apps_response" in plan:
                                schedule_extra(dict(plan,response=plan["apps_response"],delay=0,
                                    split=plan.get("apps_split",0),hold=True,reset=False),"boundary")
                        elif command == REQUEST:
                            requery_count += 1
                            with boundary_condition:
                                authorized = boundary_condition.wait_for(
                                    lambda: boundary_replies > boundary_barrier, timeout=.1)
                                previous_barrier = boundary_barrier
                                if authorized:
                                    boundary_barrier = apps_count
                                replies = boundary_replies
                            if implementation != "candidate" or requery_count>2 or not authorized:
                                event(error="version requery without a complete newer requested boundary");return
                            event(boundary_authorized_requery=True,connection_port=self.client_address[1],
                                  boundary_reply_count=replies,apps_request_count=apps_count,
                                  previous_version_barrier=previous_barrier,
                                  version_barrier_after_query=boundary_barrier)
                            schedule_extra(dict(plan,response=plan["requery_response"],delay=0,
                                split=0,hold=plan.get("requery_hold",False),reset=False),"requery")
                        else:
                            event(error="unexpected extra query",request_hex=command.hex());return
                if pending: event(error="unterminated extra query", received_hex=pending.hex())
            except (BrokenPipeError, ConnectionResetError): pass
            except OSError as exc:
                if not closed.is_set(): event(error=repr(exc))
            except Exception as exc: event(error=repr(exc))
            finally:
                with lock: active_queries.discard(self.client_address[1])
                for worker in workers: worker.join(timeout=1)
                done.set()
    class Server(socketserver.ThreadingTCPServer): daemon_threads=True
    result={"case":case,"data_origin":spec["origin"],"expected_signal":spec["signal"],
            "expected_version":spec["version"] if spec["signal"] else None,"failures":[],
            "fixture_banner_hex":spec["banner"].hex(),
            "fixture_plans":[{k:(v.hex() if isinstance(v,bytes) else v) for k,v in plan.items()} for plan in spec["plans"]]}
    if implementation == "baseline":
        result["expected_query_count"] = len(spec["queries"])
        result["expected_query_sequence_hex"] = [q.hex() for q in spec["queries"]]
    xml_path=output/(case+".xml"); stdout_path=output/(case+".stdout.log"); stderr_path=output/(case+".stderr.log")
    started=time.monotonic()
    with Server(("127.0.0.1",0),Handler) as server:
        port=server.server_address[1]
        thread=threading.Thread(target=lambda:server.serve_forever(poll_interval=.01),daemon=True); thread.start()
        command=[nmap,"--unprivileged","-n","-Pn","-sT","-p",str(port),"--script",
                 "+"+str(script) if selection=="forced" else "netbus-version","--script-timeout","12s",
                 "--script-trace","-d1","-oX",str(xml_path),"127.0.0.1"]
        if selection=="ordinary": command[1:1]=["-sV","--version-intensity","7","--datadir",str(datadir)]
        result["command"]=command
        (output/(case+".command.json")).write_text(json.dumps(command,indent=2)+"\n")
        stdout=stderr=""
        try:
            process=subprocess.run(command,capture_output=True,text=True,timeout=25)
            stdout,stderr=process.stdout,process.stderr; result["nmap_exit_code"]=process.returncode
            if process.returncode: result["failures"].append("Nmap exit was nonzero")
        except subprocess.TimeoutExpired:
            result["nmap_exit_code"]=None; result["failures"].append("Nmap exceeded 25 seconds")
        finally:
            stop.set(); server.shutdown(); thread.join(timeout=2)
            with lock: active=list(handlers)
            if not all(done.wait(2) for done in active): result["failures"].append("Fixture handlers did not finish")
    stdout_path.write_text(stdout); stderr_path.write_text(stderr)
    result["fixture_events"]=events; result["elapsed_seconds"]=round(time.monotonic()-started,6)
    logs=stdout+stderr; script_name=script.stem if selection=="forced" else "netbus-version"
    marker=f"NSE: Starting {script_name} against 127.0.0.1:{port}."
    phase=re.search(r"Completed NSE at [^\n]*, ([0-9.]+)s elapsed",logs[logs.find(marker):]) if marker in logs else None
    result["action_phase_seconds"]=float(phase[1]) if phase else None
    for word in ("Starting","Finished"):
        if f"NSE: {word} {script_name} against 127.0.0.1:{port}." not in logs: result["failures"].append(f"NSE did not {word.lower()}")
    if re.search(r"threw an error!|ERROR: Script execution failed|yielded unexpectedly|execution timed out|^NSE:.*timed out",logs,re.I|re.M):
        result["failures"].append("NSE execution failure")
    requests=[e["request_hex"] for e in events if "request_hex" in e]
    if implementation == "baseline" and requests != result["expected_query_sequence_hex"]:
        result["failures"].append("Unexpected query bytes or query count")
    if requests.count(APPS_REQUEST.hex()) > (6 if implementation=="candidate" else 0):
        result["failures"].append("Action-wide boundary query limit exceeded")
    if implementation=="candidate":
        connections = {e["connection_port"] for e in events if "request_hex" in e}
        if any(q not in {REQUEST.hex(), INFO_REQUEST.hex(), APPS_REQUEST.hex()} for q in requests):
            result["failures"].append("Unexpected query bytes")
        if requests.count(REQUEST.hex()) > len(connections) + 2 or len(connections) > 4:
            result["failures"].append("Connection or version-query limit exceeded")
        # Use the NSE read/send order, not the server's wall-clock prediction,
        # to forbid retries after successful response bytes on each socket.
        received = {}
        trace = logs[logs.find(marker):] if marker in logs else ""
        for client,direction,payload in re.findall(
                rf"^NSE: TCP 127\.0\.0\.1:(\d+) ([<>]) 127\.0\.0\.1:{port} \| ([^\n]*)",trace,re.M):
            if direction=="<":
                if client in received: received[client]=True
            elif payload.startswith("00000000: "):
                encoded=re.match(r"[0-9a-f]{2}(?: [0-9a-f]{2})*",payload[10:])
                if encoded is None: result["failures"].append("Unreadable NSE query trace");continue
                command_bytes=bytes.fromhex(encoded[0])
                if command_bytes==REQUEST: received[client]=False
                elif command_bytes in (INFO_REQUEST,APPS_REQUEST) and received.get(client):
                    result["failures"].append("Query sent after successful response bytes")
    if any("error" in e for e in events): result["failures"].append("Fixture handler error")
    if spec.get("real_refusal"):
        controls=[e for e in events if "refusal_control_errno" in e]
        if len(controls)!=1 or controls[0]["refusal_control_errno"]!=errno.ECONNREFUSED:
            result["failures"].append("Actual listener refusal was not verified")
    if case == "handoff_late_lost":
        witnesses=[e for e in events if e.get("late_complete_send_attempted")]
        if len(witnesses)!=1 or witnesses[0]["response_hex"]!=positive["response"].hex():
            result["failures"].append("Paired preservation case lacks the delayed complete-response attempt")
        result["interpretation"]="0dd baseline abandons the original reply; the candidate must preserve and identify it"
    result["query_connection_count"]=len({e["connection_port"] for e in events if "request_hex" in e})
    expected_connections=len(spec["expected_plan_indices"])
    if result["query_connection_count"]!=expected_connections:
        result["failures"].append("Unexpected query connection count")
    if case in PAIRED_CASES:
        queries=[e for e in events if "request_hex" in e]
        result["query_connection_count"]=len({e["connection_port"] for e in queries})
        result["refused_connection_count"]=sum("refused_connection_port" in e for e in events)
        if implementation=="candidate" and result["query_connection_count"]!=1: result["failures"].append("Candidate required a new query connection")
        if implementation=="candidate" and (phase is None or not 0.35 <= float(phase[1]) <= 0.9): result["failures"].append("Candidate recovery exceeded the controlled latency limit")
    if case in {"silent","response_timeout_0","info112_timeout_0","retry_eof_late_timeout","info_late_before_deadline"}:
        minimum=4.5
        if phase is None or not minimum <= float(phase[1]) <= 5.5: result["failures"].append("Shared query deadline changed")
    try:
        tree=ET.parse(xml_path).getroot(); finish=tree.find("./runstats/finished")
        if finish is None or finish.get("exit")!="success": raise ValueError("Nmap did not finish successfully")
        target=tree.find(f"./host/ports/port[@portid='{port}']")
        if target is None or target.find("state").get("state")!="open": raise ValueError("Open loopback port absent")
        service=target.find("service"); metadata=dict(service.attrib) if service is not None else {}
        result["service"]=metadata
        actual=[metadata.get(k) for k in ("name","product","version","extrainfo")]
        if spec["signal"]:
            expected=["netbus","NetBuster",spec["version"],"honeypot"]
            if actual!=expected: result["failures"].append(f"Positive metadata differs: {actual}")
        elif selection=="ordinary":
            version=re.match(rb"NetBus ([\d.]+)",spec["banner"])[1].decode()
            if actual!=["netbus","NetBus trojan",version,None]: result["failures"].append(f"Negative metadata changed: {actual}")
        elif actual[1:]!=[None,None,None]: result["failures"].append(f"False positive metadata: {actual}")
    except (ET.ParseError,OSError,ValueError,AttributeError) as exc: result["failures"].append(str(exc))
    result["status"]="fail" if result["failures"] else "pass"
    result["artifacts"]={path.name:{"sha256":digest(path),"size_bytes":path.stat().st_size}
                         for path in (xml_path,stdout_path,stderr_path,output/(case+".command.json")) if path.exists()}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--script", type=Path, default=ROOT / "nse/netbus-version.nse")
    parser.add_argument("--positive-fixture", type=Path, default=POSITIVE)
    parser.add_argument("--negative-fixture", type=Path, default=NEGATIVE)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--selection", choices=("forced", "ordinary"), default="forced")
    parser.add_argument("--cases", choices=CASES, nargs="+")
    parser.add_argument("--implementation", choices=("candidate", "baseline"), default="candidate")
    args = parser.parse_args()
    cases = args.cases or (COMPARISON_CASES if args.implementation == "baseline" else
                           (CASES if args.selection == "forced" else ORDINARY_CASES))
    if args.selection == "ordinary" and FORCED_ONLY.intersection(cases):
        parser.error("Incomplete or unrelated banners require --selection forced to exercise the NSE action")
    if args.implementation == "baseline" and not set(cases) <= set(COMPARISON_CASES):
        parser.error("Baseline comparison supports the frozen 0dd preservation cases only")
    nmap = shutil.which("nmap")
    if not nmap:
        parser.error("nmap is required")
    script = args.script.resolve(strict=True)
    positive_path, negative_path = args.positive_fixture.resolve(strict=True), args.negative_fixture.resolve(strict=True)
    positive, negative = load_fixture(positive_path, True), load_fixture(negative_path, False)
    info112 = load_info_fixture(INFO_112)
    info_controls = {}
    for name, path in (("1.30", INFO_130), ("netbus", INFO_170)):
        control = json.loads(path.read_text())
        control["response"] = bytes.fromhex(control["response_hex"])
        if bytes.fromhex(control["request_hex"]) != INFO_REQUEST or not control["response"].endswith(b"\r"):
            raise ValueError(f"{path}: expected a complete recorded GetInfo response")
        info_controls[name] = control
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any((output / (case + suffix)).exists() for case in cases for suffix in (".xml", ".stdout.log", ".stderr.log", ".command.json")) or (output / "report.json").exists():
        parser.error("Choose a fresh output directory to preserve previous evidence")
    report = {
        "scope": "loopback replay of recorded application bytes with controlled transport and response mutations",
        "selection": args.selection, "implementation": args.implementation, "status": "incomplete", "cases": [],
        "baseline_contract": "0dd9584e preserve-stream comparison; not the prior 57bf baseline",
        "script": str(script), "script_sha256": digest(script),
        "harness_sha256": digest(Path(__file__)),
        "fixtures": {str(path): {"sha256": digest(path)} for path in (positive_path, negative_path, INFO_112, INFO_130, INFO_170)},
        "negative_recorded_response_hex": negative["response"].hex(),
        "positive_recorded_version": positive["version"],
        "positive_detection_preserved": "not yet evaluated",
        "nmap_version": subprocess.check_output([nmap, "--version"], text=True).strip(),
    }
    try:
        with tempfile.TemporaryDirectory(prefix="netbuster-nmap-data-") as temporary:
            datadir = None
            if args.selection == "ordinary":
                datadir = Path(temporary).resolve()
                (datadir / "scripts").mkdir()
                help_xml = subprocess.check_output([nmap, "--script-help", "netbus-version", "-oX", "-"], text=True)
                installed = Path(ET.fromstring(help_xml).find("script").get("filename")).resolve(strict=True)
                # -sV also loads other version scripts. Keep this fixture's
                # service-based selection separate from unrelated port rules.
                entries = [line for line in (installed.parent / "script.db").read_text().splitlines()
                           if re.search(r'filename\s*=\s*"netbus-version\.nse"', line)]
                if len(entries) != 1:
                    raise RuntimeError("Expected one installed netbus-version script entry")
                (datadir / "scripts/script.db").write_text(entries[0] + "\n")
                report["ordinary_selection_scope"] = "Service-based selection with only netbus-version indexed; original service probes retained"
                report["overlay_script_db_sha256"] = digest(datadir / "scripts/script.db")
                shutil.copyfile(datadir / "scripts/script.db", output / "script.db")
                shutil.copyfile(script, datadir / "scripts/netbus-version.nse")
                selected_xml = subprocess.check_output([nmap, "--datadir", str(datadir), "--script-help", "netbus-version", "-oX", "-"], text=True)
                selected = Path(ET.fromstring(selected_xml).find("script").get("filename")).resolve(strict=True)
                if selected != datadir / "scripts/netbus-version.nse" or digest(selected) != digest(script):
                    raise RuntimeError("Nmap did not select the intended overlay script")
                report["overlay_script_verified"] = True
            for case in cases:
                result = run_case(nmap, script, case, output, args.selection, datadir, positive, negative, info112, info_controls, args.implementation)
                report["cases"].append(result)
                print(f"{case}: {result['status']}" + ("; " + "; ".join(result["failures"]) if result["failures"] else ""), flush=True)
        if digest(script) != report["script_sha256"]:
            raise RuntimeError("The candidate script changed during the run")
        if digest(Path(__file__)) != report["harness_sha256"]:
            raise RuntimeError("The replay harness changed during the run")
        report["failed_cases"] = sum(case["status"] != "pass" for case in report["cases"])
        report["status"] = "fail" if report["failed_cases"] else "pass"
        real_positive = next((case for case in report["cases"] if case["case"] == "real_positive"), None)
        report["positive_detection_preserved"] = (
            "recorded real NetBuster default reply identified in loopback replay"
            if real_positive and real_positive["status"] == "pass"
            else "failed or not evaluated"
        )
    except Exception as exc:
        report["error"] = repr(exc)
        raise
    finally:
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    return int(report["status"] != "pass")


if __name__ == "__main__":
    raise SystemExit(main())
