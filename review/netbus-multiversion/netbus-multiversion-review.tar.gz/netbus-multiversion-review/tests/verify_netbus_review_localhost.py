"""Verify bundled localhost evidence without using recorded host paths or sockets.

The bundle preserves repository-relative paths. MANIFEST.json records the old
workspace as recorded_root and each bundled file's sha256 and size_bytes.
"""

import argparse
import hashlib
import json
import re
import statistics
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath


def require(condition, message):
    if not condition:
        raise ValueError(message)


class Bundle:
    def __init__(self, root):
        self.root = Path(root).resolve(strict=True)
        manifest_path = self.contained(self.root / "MANIFEST.json")
        manifest = json.loads(manifest_path.read_bytes())
        self.files = manifest["files"]
        self.recorded_root = PurePosixPath(manifest["recorded_root"])
        require(self.recorded_root.is_absolute() and ".." not in self.recorded_root.parts,
                "Manifest recorded_root must be an absolute path without '..'")

    def contained(self, path):
        require(not path.is_symlink(), f"Symlink is not a bundled file: {path.name}")
        resolved = path.resolve(strict=True)
        require(self.root in resolved.parents, "File escapes the bundle root")
        require(resolved.is_file(), "Expected a regular bundled file")
        return resolved

    def file(self, recorded):
        require(isinstance(recorded, str) and bool(recorded), "Missing recorded path")
        relative = PurePosixPath(recorded)
        require(".." not in relative.parts, "Recorded path contains '..'")
        if relative.is_absolute():
            require(self.recorded_root in relative.parents,
                    "Absolute recorded path is outside recorded_root")
            relative = relative.relative_to(self.recorded_root)
        name = relative.as_posix()
        require(name in self.files, f"File is not listed in the manifest: {name}")
        path = self.contained(self.root.joinpath(*relative.parts))
        expected = self.files[name]
        data = path.read_bytes()
        require(len(data) == expected["size_bytes"] and
                hashlib.sha256(data).hexdigest() == expected["sha256"],
                f"Bundled file changed: {name}")
        return path


def verify(directory, root, conditions=17):
    bundle = Bundle(root)
    directory = Path(directory)
    if not directory.is_absolute():
        directory = bundle.root / directory
    directory = directory.resolve(strict=True)
    require(bundle.root in directory.parents, "Comparison directory escapes the bundle root")
    relative_directory = directory.relative_to(bundle.root).as_posix()
    summary_path = bundle.file(relative_directory + "/summary.json")
    summary = json.loads(summary_path.read_bytes())
    require(summary["status"] == "pass", "Saved comparison did not pass")
    require(summary["repetitions"] == 3 and summary["warmups_per_variant_condition"] == 1,
            "Unexpected measurement/warmup counts")
    require(len(summary["conditions"]) == conditions and len(summary["runs"]) == conditions * 8,
            "Incomplete comparison")
    condition_keys = {(item["scenario"], item["version_label"]) for item in summary["conditions"]}
    require(len(condition_keys) == conditions, "Duplicate comparison conditions")
    stored_harness = PurePosixPath(summary["runs"][0]["source"]).parents[1] / "compare_localhost.py"
    harness = bundle.file(stored_harness.as_posix())
    require(hashlib.sha256(harness.read_bytes()).hexdigest() == summary["harness_sha256"],
            "Measured harness differs from saved source")
    artifacts = original_delay_cases = merge_cases = pending_merge_cases = 0
    report_paths = set()
    for entry in summary["runs"]:
        report_path = bundle.file(entry["report"])
        require(directory in report_path.parents, "Run report is outside the comparison directory")
        require(report_path not in report_paths, "Duplicate run report")
        report_paths.add(report_path)
        report = json.loads(report_path.read_bytes())
        require({key: value for key, value in entry.items() if key not in (
            "warmup", "iteration", "report")} == report, "Run summary differs from its report")
        require(report["status"] == "pass" and report["checks"] and all(report["checks"].values()),
                "Saved run checks failed")
        require(not report["errors"] and report["exit_code"] == 0, "Saved run failed")
        source = bundle.file(report["source"])
        require(hashlib.sha256(source.read_bytes()).hexdigest() == report["source_sha256"] ==
                summary["source_sha256"][report["implementation"]], "Measured source changed")
        require(set(report["artifacts"]) == {"events.json", "result.xml", "stdout.log", "stderr.log"},
                "Missing or unexpected raw artifacts")
        raw = {}
        for filename, expected in report["artifacts"].items():
            recorded = (report_path.parent / filename).relative_to(bundle.root).as_posix()
            raw[filename] = bundle.file(recorded)
            require(hashlib.sha256(raw[filename].read_bytes()).hexdigest() == expected,
                    f"Raw artifact differs from report: {filename}")
            artifacts += 1
        command = report["command"]
        port = command[command.index("-p") + 1]
        xml = ET.parse(raw["result.xml"])
        finished = xml.find("./runstats/finished")
        require(finished is not None and finished.get("exit") == "success", "Nmap XML is incomplete")
        service = xml.find(f"./host/ports/port[@portid='{port}']/service")
        attributes = {} if service is None else service.attrib
        require(attributes == report["service"], "XML identity differs from saved metadata")
        matched = attributes.get("product") == "NetBuster"
        require(matched == report["detected"], "Detection summary differs from XML")
        if matched:
            expected_version = None if report["version_label"] == "1.12" else report["version_label"]
            require(attributes.get("version") == expected_version, "Detected version differs")
        output = raw["stdout.log"].read_text() + raw["stderr.log"].read_text()
        phases = re.findall(r"Completed NSE at .*?, ([\d.]+)s elapsed", output)
        require(len(phases) == 3 and float(phases[1]) == report["nse_seconds"],
                "NSE phase timing differs from raw output")
        events = json.loads(raw["events.json"].read_bytes())
        initial = [event for event in events if event["event"] == "initial_query"]
        require(len(initial) == 1, "Expected one queried connection")
        selected = initial[0]["connection"]
        query_reads = [event for event in events if event["event"] == "receive" and
                       event["connection"] == selected and event.get("data_hex")]
        if report["scenario"].startswith("retry_coalescing"):
            merge = [event for event in events if event["event"] == "merged_retry_release"]
            require(len(merge) == 1 and bytes.fromhex(merge[0]["data_hex"]) == b"GetInfo\rGetApps\r",
                    "Later Info/Apps merge was not established")
            require(report["detected"] == (report["implementation"] == "candidate"),
                    "Unexpected merge detection")
            if report["implementation"] == "candidate":
                require(report["nse_seconds"] < 2, "Candidate merge timing differs")
            else:
                require(4.9 <= report["nse_seconds"] <= 5.1, "Baseline miss timing differs")
            merge_cases += 1
        if report["scenario"].startswith("pending_apps_query_merge"):
            merge = [event for event in events if event["event"] == "merged_apps_query_release"]
            expect_merge = report["implementation"] == "candidate" or summary.get("baseline_repeated_apps", False)
            if expect_merge:
                require(len(merge) == 1 and
                        bytes.fromhex(merge[0]["data_hex"]) == b"GetApps\rnbver\rGetInfo\r",
                        "Pending Apps/version-query merge was not established")
                pending_merge_cases += 1
            else:
                require(not merge, "Unexpected pending-query merge")
            request_stream = b"".join(bytes.fromhex(event["data_hex"]) for event in query_reads)
            require(request_stream.count(b"nbver\rGetInfo\r") == (3 if expect_merge else 2),
                    "Unexpected version-query count")
        if report["scenario"].startswith("hold400"):
            merge = [event for event in events if event["event"] == "merged_initial_release"]
            require(len(merge) == 1 and
                    bytes.fromhex(merge[0]["data_hex"]) == b"nbver\rGetInfo\rGetInfo\r",
                    "Initial three-command merge was not established")
            require(report["detected"] and attributes.get("version") is None,
                    "1.12 merge did not preserve versionless detection")
        if report["scenario"] == "split50":
            reads = [bytes.fromhex(event["data_hex"]) for event in events if event["event"] == "application_read"]
            require(reads[:2] == [b"nb", b"ver\rGetInfo\r"] and report["detected"],
                    "Initial command split differs or missed detection")
        if report["scenario"].startswith(("delay1500", "fragment1500")):
            held = [event for event in events if event["event"] == "response_held"]
            require(held, "Original response was not held")
            delivered = [event for event in events if event["event"] == "response" and
                         event["connection"] == selected and
                         event["elapsed_seconds"] - initial[0]["elapsed_seconds"] >= 1.49]
            require(delivered, "Original delayed data was not delivered")
            response_stream = b"".join(bytes.fromhex(event["data_hex"]) for event in events
                                       if event["event"] == "response" and event["connection"] == selected
                                       and event["elapsed_seconds"] > initial[0]["elapsed_seconds"])
            require(response_stream.startswith((report["version_label"] + "-1-1").encode()),
                    "Later reply overtook original data")
            require(report["detected"] and 1.49 <= report["nse_seconds"] < 1.7,
                    "Original delayed detection or timing differs")
            original_delay_cases += 1
            if report["scenario"].startswith("fragment1500"):
                require(not any(event["elapsed_seconds"] > initial[0]["elapsed_seconds"]
                                for event in query_reads), "Commands sent after original response fragment")
        if report["scenario"].endswith("_refuse"):
            require(any(event["event"] == "listener_closed" for event in events),
                    "Replacement listener was not closed")
    for condition in summary["conditions"]:
        selected = [run for run in summary["runs"] if run["scenario"] == condition["scenario"] and
                    run["version_label"] == condition["version_label"]]
        require(len(selected) == 8 and [run["implementation"] for run in selected] == [
            "baseline", "candidate", "candidate", "baseline",
            "baseline", "candidate", "candidate", "baseline"], "Run ordering differs")
        require(set(condition["variants"]) == {"baseline", "candidate"}, "Missing comparison variant")
        for variant, stats in condition["variants"].items():
            all_runs = [run for run in selected if run["implementation"] == variant]
            require(len(all_runs) == 4 and sum(run["warmup"] for run in all_runs) == 1,
                    "Measurement/warmup allocation differs")
            runs = [run for run in all_runs if not run["warmup"]]
            require(stats["samples"] == len(runs) == 3 and
                    stats["detected"] == sum(run["detected"] for run in runs), "Summary counts differ")
            for metric in ("nse_seconds", "wall_seconds"):
                values = [run[metric] for run in runs]
                require(stats[metric] == {"values": values, "median": statistics.median(values),
                                         "minimum": min(values), "maximum": max(values)},
                        f"Saved {metric} summary differs")
    return {"status": "pass", "summary_sha256": hashlib.sha256(summary_path.read_bytes()).hexdigest(),
            "verified_conditions": conditions, "verified_scans": conditions * 8,
            "measured_scans": conditions * 6, "warmup_scans": conditions * 2,
            "raw_artifacts_checked": artifacts, "forced_info_apps_merges": merge_cases,
            "forced_pending_apps_query_merges": pending_merge_cases,
            "original_delayed_response_cases": original_delay_cases,
            "source_sha256": summary["source_sha256"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="Comparison directory, absolute or relative to --root")
    parser.add_argument("--root", type=Path, required=True, help="Extracted bundle root with MANIFEST.json")
    parser.add_argument("--conditions", type=int, default=17)
    args = parser.parse_args()
    try:
        result = verify(args.directory, args.root, args.conditions)
    except (OSError, ValueError, KeyError, IndexError, TypeError, ET.ParseError) as error:
        result = {"status": "fail", "error": str(error)}
    print(json.dumps(result, indent=2))
    return int(result["status"] != "pass")


if __name__ == "__main__":
    raise SystemExit(main())
