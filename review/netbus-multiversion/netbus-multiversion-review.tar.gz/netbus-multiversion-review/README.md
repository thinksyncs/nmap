# NetBuster multiversion review candidate

This is a local follow-up to [Nmap PR #3570](https://github.com/nmap/nmap/pull/3570).
It has not been submitted. The existing PR and its published evidence are unchanged.
The candidate SHA-256 is
`1dab4ae5605d6830daade00ea7fe859ec9f9276f8ea85c9c86bc83a59e38b130`.

The NSE recognizes the complete default Info response observed in NetBuster 1.12
without assigning a version. Explicit version replies identify 1.30 and 1.31.
Silence, connection failure and incomplete records are not positive evidence.
The bounded retry logic keeps the original connection open for delayed replies.

## Reproduce

Extract `netbus-multiversion-review.tar.gz` into a fresh directory. From the
extracted `netbus-multiversion-review` directory, run:

```sh
python3 run_review.py --output ../review-offline
```

This needs Python 3.9+, Git and Lua 5.3+. It opens no sockets. It checks every
bundled file, both patches, 169 response-driven contracts, the raw files from
136 synthetic localhost scans, and the saved captures/logs/XML from 168
archived-application scans. It recomputes the application timing summaries and
checks 11 direct controls. Application programs and VM disks are not included.
The default command verifies retained measurements; it does not rerun those
applications. Original recorded paths are metadata only; reads use this bundle.

With Nmap and its standard data installed, use a different output directory:

```sh
python3 run_review.py --output ../review-network --replay --compare
```

This adds 20 saved-response replay cases and 28 synthetic comparison scans on
127.0.0.1 only. It covers versionless 1.12, 1.30/1.31, the NetBus 1.70 negative
control, incomplete/altered replies, silence, later command coalescing, refused
replacement connections and original responses delayed by 1.5 seconds.
It does not run the archived programs or measure real-world detection rates.

Each command writes `review-report.json` and the underlying logs. An exit code
other than zero is a failed or incomplete verification. Use a fresh output
directory outside the attachment each time; preserved evidence is never replaced.

## Changes and measurements

`patches/after-pr3570.patch` shows the additions to the submitted PR head
`74f11fdb`. `patches/netbus-multiversion.patch` applies to the bundled upstream
snapshot. Both must produce exactly the bundled candidate. The former is the
proposed follow-up scope; these are two views of the same change, not two PRs.
Refresh the upstream base before any submission.

The retained timing comparison is against the immediately preceding local
multiversion candidate `72aee081`, not against PR #3570 or current upstream.
Five measured runs per variant/condition follow one excluded warmup. All 168
formal scans are retained; six pilot scans are excluded from the statistics.

| Archived-application condition | Before | Candidate |
| --- | ---: | ---: |
| 1.30, Info disabled, later GetInfo/GetApps coalesced | 5.17 s, missed | 1.53 s, detected |
| 1.31, same condition | 5.17 s, missed | 1.55 s, detected |
| 1.30, original response delayed 1.5 s, new connections refused | 1.84 s | 1.82 s |
| 1.31, same condition | 1.83 s | 1.82 s |
| 1.12, coalesced commands | 0.81 s | 0.78 s |

The candidate had 78/78 expected positive identifications, including 18/18
versionless 1.12 results, and 6/6 expected NetBus negative controls (warmups
included). Other application conditions had median changes from -0.03 to +0.03 s;
this is not a claim that every path is faster. A synthetic pending-Apps condition
retains a 0.02 s median increase.

The full table, sample provenance, raw captures and reproduction instructions
are under `evidence/netbuster112-retry-boundary/lab/final/`. Those programs ran
under Wine 10.7 in QEMU, not native Windows. Relay writes and reconstructed TCP
bytes do not establish application receive-call boundaries. The default Info
text is configurable. Responses beyond the five-second query budget, more loss
than the retry bounds, and Apps records exceeding 4 KiB remain outside coverage.

The source grows from 80 lines in #3570 to 282. Review should weigh the added
version coverage and transport recovery against that maintenance cost. There
are no new production dependencies. A full scan alongside unrelated NSE scripts
and real-world false-positive/detection rates have not been established.
