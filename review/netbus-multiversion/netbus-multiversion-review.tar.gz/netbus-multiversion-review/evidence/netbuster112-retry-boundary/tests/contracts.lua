-- Independent virtual-clock contracts. No Nmap socket or application execution.
-- The peer schedules responses from requests; it does not prescribe the NSE's
-- exact call sequence or timeout values. Network behavior is measured separately.
local source = assert(arg[1], "source path required")
local INFO = "Info;Your IP is logged and you will be nuked VERY soon!\r"
local QUERY = "nbver\rGetInfo\r"
local APPS = "AppNames;synthetic\r"
local cases, results = {}, {}
local function add(name, config, expected, version)
  cases[#cases + 1] = {name=name, config=config, expected=expected, version=version}
end
local function run(case)
  local cfg = case.config
  local now, active, published, max_active, first_query = 0, 0, 0, 0, nil
  local total_apps=0
  local sockets, trace = {}, {}
  local function log(event, id, data)
    trace[#trace + 1] = {time_ms=now, event=event, connection=id, data=data}
  end
  local function new_socket()
    local s = {id=#sockets+1, pending={}, timeout=5000, queries=0, apps=0, info=0}
    sockets[#sockets+1] = s
    assert(#sockets <= 4, "connection budget exceeded")
    active=active+1; max_active=math.max(max_active,active)
    assert(active==1, "old stream abandoned for overlapping connection")
    local serial=0
    local function reply(at, data, status)
      serial=serial+1
      s.pending[#s.pending+1]={at=at,data=data,status=status~=false,serial=serial}
      table.sort(s.pending,function(a,b)return a.at==b.at and a.serial<b.serial or a.at<b.at end)
    end
    function s:set_timeout(value)
      assert(value >= 10 and value <= 5000, "timeout out of bounds")
      self.timeout=value
    end
    function s:connect()
      assert(not self.closed)
      log("connect",self.id)
      if self.id > 1 and cfg.refuse then return false,"ERROR" end
      reply(now,"NetBus 1.60\r")
      return true
    end
    function s:send(data)
      assert(not self.closed)
      log("send",self.id,data)
      if data==QUERY then
        self.queries=self.queries+1
        assert(self.queries<=3,"version query budget exceeded")
        first_query=first_query or now
        if cfg.original then
          if self.queries==1 then
            local value=cfg.original
            if cfg.split then
              reply(now,value:sub(1,cfg.split))
              reply(now+(cfg.delay or 1),value:sub(cfg.split+1))
            elseif cfg.failed then
              reply(now+(cfg.delay or 0),value,false)
            else reply(now+(cfg.delay or 0),value) end
          else error("requery after original response") end
        elseif self.queries>=2 then
          if self.held_apps then
            log("application_read",self.id,"GetApps\r"..data)
            self.held_apps=false
            reply(cfg.old_apps_reply_at or now,APPS)
          elseif cfg.drop_queries and self.queries<=cfg.drop_queries then
            log("discarded_query",self.id,data)
          elseif cfg.requery then reply(now+(cfg.requery_delay or 0),cfg.requery) end
        end
      elseif data=="GetInfo\r" then
        self.info=self.info+1
        if cfg.merge_info_after and now>=cfg.merge_info_after then self.info_hold_until=now+100 end
        if cfg.info_reply and self.info >= (cfg.info_after or 1) then reply(now,cfg.info_reply) end
      elseif data=="GetApps\r" then
        self.apps=self.apps+1
        total_apps=total_apps+1
        assert(total_apps<=6,"Apps request budget exceeded")
        if cfg.apps_send_failed then return false,"ERROR" end
        if cfg.apps_mode=="second" and self.apps==2 then
          reply(now,cfg.apps_value or APPS)
        elseif cfg.apps_mode=="first" and self.apps==1 then
          if cfg.apps_split then
            reply(now,APPS:sub(1,cfg.apps_split))
            reply(now+20,APPS:sub(cfg.apps_split+1))
          else reply(now,cfg.apps_value or APPS) end
        elseif cfg.apps_mode=="duplicates" then
          if self.apps==1 then
            self.apps_due=now+700
            reply(self.apps_due,APPS)
          elseif self.apps==2 then
            reply(self.apps_due+(cfg.duplicate_delay or 0),APPS)
          end
        elseif cfg.apps_mode=="pending_retry" then
          if self.apps==1 then reply(now+700,APPS)
          elseif self.apps==2 then self.held_apps=true
          elseif self.info_hold_until and now<self.info_hold_until then
            log("application_read",self.id,"GetInfo\rGetApps\r")
          else reply(now,APPS) end
        elseif cfg.apps_mode=="all" then reply(now,APPS)
        elseif cfg.apps_mode=="nth" and self.apps==cfg.apps_nth then reply(now,APPS)
        elseif cfg.apps_mode=="excess" and self.apps==1 then
          reply(now,string.rep(APPS,7))
        elseif cfg.apps_mode=="after_requery_send_failure" then
          if self.apps==1 then reply(now+700,APPS)
          elseif self.apps==2 then reply(now+500,APPS) end
        elseif cfg.apps_mode=="mixed" and self.apps==1 then
          reply(now,APPS..(cfg.mixed_tail or "1.31-1-1"))
        elseif cfg.apps_mode=="partial" and self.apps==1 then
          reply(now,"AppNames;unterminated")
        elseif cfg.apps_mode=="failed" and self.apps==1 then
          reply(now,APPS,false)
        end
        if (cfg.apps_fail_first and self.apps==1) or self.apps==cfg.apps_fail_at then return false,"ERROR" end
      else error("unexpected request bytes: "..data) end
      return true
    end
    function s:receive()
      assert(not self.closed)
      local until_ms=now+self.timeout
      if self.pending[1] and self.pending[1].at<=until_ms then
        local event=table.remove(self.pending,1)
        now=math.max(now,event.at)
        log(event.status and "receive" or "failed_receive",self.id,event.data)
        return event.status,event.data
      end
      now=until_ms;log("timeout",self.id)
      return false,"TIMEOUT"
    end
    function s:close()
      assert(not self.closed,"double close")
      self.closed=true;active=active-1;log("close",self.id)
      return true
    end
    return s
  end
  local fake={new_socket=new_socket,clock_ms=function()return now end,
    set_port_version=function()published=published+1 end}
  local env=setmetatable({require=function(name)
    if name=="nmap" then return fake end
    if name=="stdnse" then return {debug1=function(fmt,...)log("debug",0,string.format(fmt,...))end,
      sleep=function(seconds)now=now+seconds*1000 end} end
    if name=="shortport" then return {version_port_or_service=function()return function()return true end end} end
    error("unexpected dependency: "..name)
  end},{__index=_G})
  assert(loadfile(source,"t",env))()
  local port={version={name="netbus",product="previous",version="1.60"}}
  env.action({ip="127.0.0.1"},port)
  assert(active==0,"socket leak")
  assert(published==(case.expected and 1 or 0),"wrong publication count")
  if case.expected then
    assert(port.version.product=="NetBuster","wrong product")
    assert(port.version.version==case.version,"wrong version or stale prior version")
  else
    assert(port.version.product=="previous" and port.version.version=="1.60","negative mutates identity")
  end
  if first_query then assert(now-first_query<=5000,"shared deadline restarted") end
  if cfg.split then
    local seen=false
    for _,event in ipairs(trace)do
      if event.event=="receive" and event.data==cfg.original:sub(1,cfg.split) then seen=true end
      assert(not(seen and event.event=="send"),"request after first original response byte")
    end
  end
  if cfg.refuse and case.expected then assert(#sockets==1,"positive depended on replacement connection") end
  if cfg.expected_queries then assert(sockets[1].queries==cfg.expected_queries,"unexpected version query after failed Apps send") end
  if cfg.expected_apps then assert(sockets[1].apps==cfg.expected_apps,"Apps recovery continued after send failure") end
  if cfg.max_elapsed then assert(now <= cfg.max_elapsed,"Info retry schedule was delayed") end
  return {name=case.name,status="pass",elapsed_ms=now,connections=#sockets,
    max_live_sockets=max_active,apps_sent=sockets[1].apps,queries=sockets[1].queries,trace=trace}
end

add("complete default Info clears version",{original=INFO},true)
add("complete Info before large unrelated tail",{original=INFO..string.rep("x",25000)},true)
add("initial three command merge retains 500ms Info retry",{info_reply=INFO,info_after=2,max_elapsed=500,refuse=true},true)
add("lost first two Info retries retain 900ms response",{info_reply=INFO,info_after=3,max_elapsed=900,refuse=true},true)
for split=1,#INFO-1 do
  add("default Info split "..split,{original=INFO,split=split,delay=1500,refuse=true},true)
end
for _,version in ipairs({"1.30","1.31"})do
  local response=version.."-1-1"
  add("direct "..version,{original=response},true,version)
  add("complete version before large unrelated tail "..version,{original=response..string.rep("x",25000)},true,version)
  for split=1,7 do
    add("delayed fragment "..version.." "..split,{original=response,split=split,delay=1500,refuse=true},true,version)
  end
  add("delayed original with refused replacement "..version,{original=response,delay=1500,refuse=true},true,version)
  add("lost first Apps recovers "..version,{apps_mode="second",requery=response,refuse=true},true,version)
  for split=1,#APPS-1 do
    add("Apps fragmentation "..version.." "..split,{apps_mode="first",apps_split=split,requery=response},true,version)
  end
  for _,delay in ipairs({0,20})do
    add("queued duplicate Apps "..version.." "..delay,{apps_mode="duplicates",duplicate_delay=delay,requery_delay=50,requery=response},true,version)
  end
  add("failed Apps disables recovery even if delivered "..version,{apps_mode="duplicates",apps_fail_first=true,
    duplicate_delay=20,requery_delay=50,requery=response,expected_queries=1,expected_apps=1,refuse=true},false)
  add("failed later Apps drains old record before version "..version,{apps_mode="after_requery_send_failure",apps_fail_at=3,
    requery_delay=470,requery=response,expected_queries=2,expected_apps=3,refuse=true},true,version)
  add("failed first Apps drains delivered record before original "..version,{original=response,delay=1500,
    apps_mode="first",apps_fail_first=true,expected_queries=1,expected_apps=1,refuse=true},true,version)
  add("Apps send failure retains original "..version,{original=response,delay=1500,apps_send_failed=true,refuse=true},true,version)
  add("pending Apps retry cannot swallow new query "..version,{apps_mode="pending_retry",requery=response,refuse=true},true,version)
  for _,phase in ipairs({1290,1295,1300})do
    add("old Apps phase avoids Info merge "..version.." "..phase,{apps_mode="pending_retry",requery=response,
      old_apps_reply_at=phase,merge_info_after=1300,max_elapsed=2000,refuse=true},true,version)
  end
  add("second query also discarded "..version,{apps_mode="all",drop_queries=2,requery=response,refuse=true},true,version)
  for attempt=2,6 do
    add("first "..(attempt-1).." Apps lost "..version,{apps_mode="nth",apps_nth=attempt,requery=response,refuse=true},true,version)
  end
end
add("Info after Apps has no version",{apps_mode="first",requery=INFO},true)
add("Apps alone is not positive",{apps_mode="first"},false)
add("repeated Apps alone is not positive",{apps_mode="duplicates"},false)
add("excess unsolicited Apps cannot supply a boundary",{apps_mode="excess",requery="1.31-1-1",refuse=true},false)
add("Apps retry budget is bounded",{apps_mode="nth",apps_nth=7,requery="1.31-1-1"},false)
add("version query budget is bounded",{apps_mode="all",drop_queries=3,requery="1.31-1-1"},false)
add("partial Apps is not positive",{apps_mode="partial"},false)
add("failed Apps read cannot authorize",{apps_mode="failed"},false)
add("mixed Apps and version does not splice",{apps_mode="mixed"},false)
add("mixed Apps and garbage does not splice",{apps_mode="mixed",mixed_tail="garbage"},false)
add("partial requery cannot borrow Apps bytes",{apps_mode="duplicates",duplicate_delay=20,requery="1.31-1-"},false)
add("failed version read is not evidence",{original="1.31-1-1",failed=true},false)
add("truncated version is not positive",{original="1.31-1-"},false)
add("silence is not positive",{},false)
for _,value in ipairs({"1.29-1-1","1.32-1-1","1.31-5-1","1.31-x-1","Info;other\r","AppNames;unsolicited\r"})do
  add("unsupported or unrelated "..value,{original=value},false)
end

local function json(value)
  if value==nil then return "null" end
  if type(value)=="string" then
    return '"'..value:gsub('[%z\1-\31\\"]',function(c)return string.format("\\u%04x",string.byte(c))end)..'"'
  elseif type(value)=="number" or type(value)=="boolean" then return tostring(value) end
  local parts={}
  if #value>0 then
    for _,item in ipairs(value)do parts[#parts+1]=json(item)end
    return "["..table.concat(parts,",").."]"
  end
  for key,item in pairs(value)do parts[#parts+1]=json(key)..":"..json(item)end
  table.sort(parts);return "{"..table.concat(parts,",").."}"
end
local failed=0
for _,case in ipairs(cases)do
  local ok,result=pcall(run,case)
  if not ok then failed=failed+1;result={name=case.name,status="fail",error=tostring(result)} end
  results[#results+1]=result
end
print(json({scope="independent virtual-clock socket contracts; not measured network timing",source=source,
  status=failed==0 and "pass" or "fail",total=#cases,failed=failed,cases=results}))
os.exit(failed==0 and 0 or 1)
