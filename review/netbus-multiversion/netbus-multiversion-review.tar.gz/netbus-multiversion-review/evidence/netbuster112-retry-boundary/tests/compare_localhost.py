"""Compare two NSE snapshots using actual Nmap and a synthetic localhost peer.

No archived applications are executed. Each peer uses the same dispatch policy
for both implementations. Application reads intentionally do not retain bytes
after the first CR-delimited command. Server traces distinguish modeled reads
from the actual TCP receives. Use a fresh output directory for every run.
"""
import argparse
import hashlib
import json
import re
import select
import shutil
import socket
import statistics
import subprocess
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path

QUERY = b"nbver\rGetInfo\r"
INFO = b"Info;Your IP is logged and you will be nuked VERY soon!\r"
CASES = [("direct", version) for version in ("1.12", "1.30", "1.31")]
CASES += [(scenario, version) for scenario in (
    "retry_coalescing", "retry_coalescing_refuse", "delay1500_refuse",
    "fragment1500_refuse", "pending_apps_query_merge_refuse") for version in ("1.30", "1.31")]
CASES += [("hold400", "1.12"), ("hold400_refuse", "1.12"),
          ("split50", "1.30"), ("split50", "1.31")]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def run_case(source, directory, version, scenario, implementation, baseline_repeated_apps=False):
    directory.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    events, errors, workers = [], [], []
    lock, stop = threading.Lock(), threading.Event()
    state = {"connections": 0, "selected": None, "listening": True}
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen()
    listener.settimeout(.1)
    port = listener.getsockname()[1]

    def record(event, ident=None, **fields):
        with lock:
            events.append({"elapsed_seconds": time.monotonic() - started,
                           "event": event, "connection": ident, **fields})

    def handle(peer, ident):
        first, info_count, selected = True, 0, False
        apps_count, held_apps = 0, False
        pending, unblock_at = [], 0
        peer.setblocking(False)

        def send(data):
            peer.sendall(data)
            record("response", ident, data_hex=data.hex())

        def dispatch(data):
            record("application_read", ident, data_hex=data.hex())
            command = data.split(b"\r", 1)[0]
            response = None
            if command == b"nbver" and version != "1.12":
                response = (version + "-1-1").encode()
            elif command == b"GetInfo" and version == "1.12":
                response = INFO
            elif command == b"GetApps" and version != "1.12":
                response = b"AppNames;synthetic\r"
            if response:
                # A newly processed request must not overtake output already
                # queued when the release time passes during receive/dispatch.
                if pending or time.monotonic() < unblock_at:
                    pending.append(response)
                    record("response_held", ident, data_hex=response.hex())
                else:
                    send(response)

        def receive():
            data = peer.recv(8192)
            record("receive", ident, data_hex=data.hex())
            return data

        try:
            send(b"NetBus 1.60\r")
            while not stop.is_set():
                now = time.monotonic()
                if pending and now >= unblock_at:
                    send(b"".join(pending))
                    pending.clear()
                wait = min(.1, max(0, unblock_at - now)) if pending else .1
                ready, _, _ = select.select([peer], [], [], wait)
                if not ready:
                    continue
                data = receive()
                if not data:
                    break
                if first:
                    while len(data) < len(QUERY) and QUERY.startswith(data):
                        ready, _, _ = select.select([peer], [], [], 2)
                        if not ready:
                            raise ValueError("incomplete initial query")
                        extra = receive()
                        if not extra:
                            raise ValueError("closed during initial query")
                        data += extra
                    if data != QUERY:
                        raise ValueError(f"unexpected initial query: {data!r}")
                    with lock:
                        if state["selected"] is None:
                            state["selected"] = ident
                        selected = state["selected"] == ident
                    first = False
                    record("initial_query", ident, selected=selected)
                    if selected and scenario.endswith("_refuse"):
                        state["listening"] = False
                        listener.close()
                        record("listener_closed", ident)
                    if selected and scenario.startswith("hold400"):
                        deadline = time.monotonic() + .4
                        held = bytearray(data)
                        while (remaining := deadline - time.monotonic()) > 0:
                            ready, _, _ = select.select([peer], [], [], remaining)
                            if not ready:
                                break
                            extra = receive()
                            if not extra:
                                raise ValueError("closed during initial hold")
                            held.extend(extra)
                        record("merged_initial_release", ident, data_hex=held.hex())
                        dispatch(bytes(held))
                        continue
                    if selected and (scenario.startswith(("retry_coalescing", "pending_apps_query_merge")) or scenario == "split50"):
                        dispatch(data[:2])
                        stop.wait(.05)
                        dispatch(data[2:])
                        continue
                    if selected and scenario == "delay1500_refuse":
                        unblock_at = time.monotonic() + 1.5
                    elif selected and scenario == "fragment1500_refuse":
                        response = (version + "-1-1").encode()
                        send(response[:7])
                        unblock_at = time.monotonic() + 1.5
                        pending.append(response[7:])
                        record("response_held", ident, data_hex=response[7:].hex())
                        continue
                if selected and scenario.startswith("retry_coalescing") and data == b"GetInfo\r":
                    info_count += 1
                    if info_count == 2:
                        deadline = time.monotonic() + .1
                        held = bytearray(data)
                        record("holding_second_info", ident)
                        while (remaining := deadline - time.monotonic()) > 0:
                            ready, _, _ = select.select([peer], [], [], remaining)
                            if not ready:
                                break
                            extra = receive()
                            if not extra:
                                record("closed_during_hold", ident, data_hex=held.hex())
                                return
                            held.extend(extra)
                        record("merged_retry_release", ident, data_hex=held.hex())
                        dispatch(bytes(held))
                        continue
                if selected and scenario.startswith("pending_apps_query_merge"):
                    if data == b"GetApps\r":
                        apps_count += 1
                        if apps_count == 1:
                            unblock_at = time.monotonic() + .7
                        elif apps_count == 2:
                            held_apps = True
                            record("holding_second_apps", ident)
                            continue
                    elif data == QUERY and held_apps:
                        held_apps = False
                        data = b"GetApps\r" + data
                        record("merged_apps_query_release", ident, data_hex=data.hex())
                dispatch(data)
        except (BrokenPipeError, ConnectionResetError):
            record("peer_reset", ident)
        except Exception as exc:
            with lock:
                errors.append(repr(exc))
            record("error", ident, error=repr(exc))
        finally:
            peer.close()
            record("closed", ident)

    def accept_connections():
        while not stop.is_set() and state["listening"]:
            try:
                peer, _ = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                if not state["listening"] or stop.is_set():
                    break
                raise
            with lock:
                state["connections"] += 1
                ident = state["connections"]
            record("connected", ident)
            worker = threading.Thread(target=handle, args=(peer, ident), daemon=True)
            workers.append(worker)
            worker.start()

    acceptor = threading.Thread(target=accept_connections, daemon=True)
    acceptor.start()
    command = [shutil.which("nmap"), "--unprivileged", "-n", "-Pn", "-sT",
               "-p", str(port), "--script", "+" + str(source),
               "--script-timeout", "12s", "--script-trace", "-d1", "-oX",
               str(directory / "result.xml"), "127.0.0.1"]
    source_hash = digest(source)
    scan_started = time.monotonic()
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        wall = time.monotonic() - scan_started
    finally:
        stop.set()
        listener.close()
        acceptor.join(timeout=2)
        for worker in workers:
            worker.join(timeout=2)
    (directory / "stdout.log").write_text(result.stdout)
    (directory / "stderr.log").write_text(result.stderr)
    write_json(directory / "events.json", events)
    combined = result.stdout + result.stderr
    phases = re.findall(r"Completed NSE at .*?, ([\d.]+)s elapsed", combined)
    service = ET.parse(directory / "result.xml").find(
        f"./host/ports/port[@portid='{port}']/service")
    attributes = {} if service is None else service.attrib
    matched = attributes.get("product") == "NetBuster"
    expected = implementation == "candidate" or not scenario.startswith("retry_coalescing")
    checks = {
        "no_server_errors": not errors,
        "exit_zero": result.returncode == 0,
        "no_lua_errors": "Script execution failed" not in combined and "threw an error!" not in combined,
        "three_nse_phases": len(phases) == 3,
        "script_ran": f"NSE: Starting netbus-version against 127.0.0.1:{port}." in combined,
        "script_finished": f"NSE: Finished netbus-version against 127.0.0.1:{port}." in combined,
        "expected_detection": matched == expected,
        "expected_version": not matched or attributes.get("version") == (None if version == "1.12" else version),
        "source_unchanged": source_hash == digest(source),
    }
    if scenario.startswith("retry_coalescing"):
        releases = [event for event in events if event["event"] == "merged_retry_release"]
        checks["forced_info_apps_merge"] = len(releases) == 1 and bytes.fromhex(releases[0]["data_hex"]) == b"GetInfo\rGetApps\r"
    if scenario.startswith("pending_apps_query_merge"):
        releases = [event for event in events if event["event"] == "merged_apps_query_release"]
        expect_merge = implementation == "candidate" or baseline_repeated_apps
        checks["forced_apps_query_merge"] = (len(releases) == 1 and bytes.fromhex(releases[0]["data_hex"]) == b"GetApps\r" + QUERY) if expect_merge else not releases
    if scenario.startswith("hold400"):
        releases = [event for event in events if event["event"] == "merged_initial_release"]
        checks["forced_initial_three_command_merge"] = len(releases) == 1 and bytes.fromhex(releases[0]["data_hex"]) == QUERY + b"GetInfo\r"
    if scenario == "split50":
        reads = [bytes.fromhex(event["data_hex"]) for event in events if event["event"] == "application_read"]
        checks["forced_initial_split"] = reads[:2] == [QUERY[:2], QUERY[2:]]
    selected = state["selected"]
    queries = [event for event in events if event["event"] == "initial_query"]
    checks["single_query_connection"] = len(queries) == 1
    if scenario.endswith("_refuse"):
        checks["listener_closed"] = any(event["event"] == "listener_closed" for event in events)
    if scenario == "fragment1500_refuse":
        initial = next(event for event in events if event["event"] == "initial_query")
        checks["no_followup_after_fragment"] = not any(
            event["event"] == "receive" and event["connection"] == selected
            and event["elapsed_seconds"] > initial["elapsed_seconds"]
            and event.get("data_hex") for event in events)
    report = {"kind": "actual Nmap with synthetic localhost peer, not real NetBuster",
              "status": "pass" if all(checks.values()) else "fail",
              "implementation": implementation, "version_label": version, "scenario": scenario,
              "command": command, "exit_code": result.returncode, "errors": errors,
              "checks": checks, "detected": matched, "service": attributes,
              "nse_seconds": float(phases[1]) if len(phases) == 3 else None,
              "all_nse_phases": phases, "wall_seconds": wall,
              "source_sha256": source_hash, "source": str(source),
              "artifacts": {name: digest(directory / name) for name in (
                  "events.json", "result.xml", "stdout.log", "stderr.log")}}
    write_json(directory / "report.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--baseline-repeated-apps", action="store_true",
                        help="Baseline also sends repeated Apps queries; change assertions only")
    parser.add_argument("--case", action="append", help="scenario:version, repeatable")
    args = parser.parse_args()
    assert args.repetitions > 0
    cases = [tuple(case.split(":")) for case in args.case] if args.case else CASES
    assert all(case in CASES for case in cases)
    assert not args.output.exists(), "Choose a fresh output directory"
    args.output.mkdir(parents=True)
    sources = {name: getattr(args, name).resolve() for name in ("baseline", "candidate")}
    # NSE uses the file basename as the script identifier.
    assert all(path.name == "netbus-version.nse" for path in sources.values())
    summary = {"scope": "actual Nmap and synthetic loopback peer, not real NetBuster",
               "nmap_version": subprocess.check_output([shutil.which("nmap"), "--version"], text=True),
               "harness_sha256": digest(__file__), "repetitions": args.repetitions,
               "baseline_repeated_apps": args.baseline_repeated_apps,
               "warmups_per_variant_condition": 1,
               "source_sha256": {key: digest(path) for key, path in sources.items()},
               "status": "incomplete", "runs": []}
    write_json(args.output / "summary.json", summary)
    for scenario, version in cases:
        for iteration in range(args.repetitions + 1):
            order = ("baseline", "candidate") if iteration % 2 == 0 else ("candidate", "baseline")
            for implementation in order:
                if shutil.disk_usage(args.output).free < 200 * 1024**2:
                    raise RuntimeError("Stop: free capacity below 200 MiB")
                directory = args.output / f"{scenario}-{version}" / f"{iteration:02}-{implementation}"
                report = run_case(sources[implementation], directory, version, scenario, implementation,
                                  args.baseline_repeated_apps)
                report["warmup"] = iteration == 0
                report["iteration"] = iteration
                report["report"] = str(directory / "report.json")
                summary["runs"].append(report)
                write_json(args.output / "summary.json", summary)
                print(json.dumps({key: report[key] for key in (
                    "scenario", "version_label", "implementation", "iteration", "status",
                    "detected", "nse_seconds", "wall_seconds")}), flush=True)
                if report["status"] != "pass":
                    return 1
    summary["conditions"] = []
    for scenario, version in cases:
        row = {"scenario": scenario, "version_label": version, "variants": {}}
        for name in sources:
            runs = [run for run in summary["runs"] if run["scenario"] == scenario and
                    run["version_label"] == version and run["implementation"] == name and not run["warmup"]]
            row["variants"][name] = {"detected": sum(run["detected"] for run in runs),
                                    "samples": len(runs)}
            for metric in ("nse_seconds", "wall_seconds"):
                values = [run[metric] for run in runs]
                row["variants"][name][metric] = {"values": values, "median": statistics.median(values),
                                                "minimum": min(values), "maximum": max(values)}
        summary["conditions"].append(row)
    summary["status"] = "pass"
    write_json(args.output / "summary.json", summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
