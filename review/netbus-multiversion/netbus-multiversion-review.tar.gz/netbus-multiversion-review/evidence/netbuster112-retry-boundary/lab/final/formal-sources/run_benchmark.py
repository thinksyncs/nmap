"""One fixed application/relay condition; capture all scans and lifecycle checks."""
import argparse,datetime,hashlib,json,signal,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('product');p.add_argument('label');p.add_argument('--repeats',type=int,default=5);p.add_argument('--smoke',action='store_true');p.add_argument('--condition',choices=['direct','hold400','hold400-refuse','delay600-refuse','split50','delay1500-refuse','delay1500-handoff-fail','retry-merge100'],default='direct');a=p.parse_args()
assert a.label.replace('-','').isalnum()
r=Path('/home/lab/retry-boundary-results');assert not(r/a.label).exists();prefix=str(Path(__file__).resolve().parent)+'/';port=12345 if a.condition=='direct'else 23456
cmd=['python3',prefix+'compare.py','--product',a.product,'--baseline','/home/lab/retry-boundary-baseline.nse','--candidate','/home/lab/retry-boundary-candidate.nse','--output',str(r/a.label),'--repeats',str(a.repeats),'--scan','syn','--port',str(port),'--condition',a.condition,'--proxy',prefix+'condition_proxy.py']
if a.smoke:cmd.append('--smoke')
capcmd=['tcpdump','--immediate-mode','-i','lo','-n','-s','0','-U','-w',str(r/(a.label+'.pcap')),'tcp port 12345'if a.condition=='direct'else'tcp port 12345 or tcp port 23456']
record={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparison_command':cmd,'capture_command':capcmd,'condition':a.condition,'comparison_exit':None,'capture_exit':None,'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
log=(r/(a.label+'-runner.log')).open('w');caplog=(r/(a.label+'-tcpdump.log')).open('w');cap=None
try:
 cap=subprocess.Popen(capcmd,stdout=caplog,stderr=subprocess.STDOUT);time.sleep(.3);assert cap.poll()is None,'Capture exited during startup'
 record['comparison_exit']=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=420).returncode
except Exception as error:record['wrapper_error']=repr(error)
finally:
 time.sleep(1);record['capture_drain_seconds']=1.0
 if cap is not None:
  if cap.poll()is None:cap.send_signal(signal.SIGINT)
  try:record['capture_exit']=cap.wait(timeout=10)
  except subprocess.TimeoutExpired:cap.kill();record['capture_exit']=cap.wait();record['capture_forced_stop']=True
 log.close();caplog.close();record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(r/(a.label+'-completion.json')).write_text(json.dumps(record,indent=2)+'\n')
raise SystemExit(record['comparison_exit']!=0 or record['capture_exit']!=0)
