"""Edit one persisted setting only while this prefix's Wine server is stopped."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('product', choices=['130', '131'])
p.add_argument('count', choices=['0', '1'])
p.add_argument('label')
a = p.parse_args()
assert a.label.replace('-', '').isalnum()
registry = Path('/home/lab/prefix' + a.product) / 'user.reg'
text = registry.read_text()
start = text.rfind('[', 0, text.index('Eclipse'))
end = text.index('\n[', start + 1)
block = text[start:end]
assert 'NetBuster]' in block.splitlines()[0]
assert '"InfoMessage"="Your IP is logged and will be reported to your internet provider!"' in block
old = '1' if a.count == '0' else '0'
needle = '"Infomessages"="' + old + '"'
assert block.count(needle) == 1
changed = block.replace(needle, '"Infomessages"="' + a.count + '"', 1)
result = text[:start] + changed + text[end:]
out = Path('/home/lab/retry-boundary-results')
(out / (a.label + '-before-user.reg')).write_text(text)
registry.write_text(result)
(out / (a.label + '-after-user.reg')).write_text(result)
(out / (a.label + '-registry-change.json')).write_text(json.dumps({
    'method': 'Change only persisted REG_SZ Infomessages in the stopped prefix; preserve default InfoMessage.',
    'old': old, 'new': a.count,
    'before_sha256': hashlib.sha256(text.encode()).hexdigest(),
    'after_sha256': hashlib.sha256(result.encode()).hexdigest(),
}, indent=2) + '\n')
print('Changed Info count only:', old, '->', a.count)
