"""Reassemble saved loopback captures and compare every NSE send/read with its log."""

import argparse
import hashlib
import json
import re
import statistics
import struct
from collections import Counter
from pathlib import Path


RESULTS = Path(__file__).with_name("results")
PLAN = json.loads(Path(__file__).with_name("measurement-plan.json").read_text())
INITIAL = b"nbver\rGetInfo\r"
INFO = b"GetInfo\r"
APPS = b"GetApps\r"


def query_kind(query, variant):
    if not query:
        return "connection_without_query"
    require(query.startswith(INITIAL), "Version query was not first")
    tail, commands = query[len(INITIAL):], []
    while tail:
        command = next((value for value in (INITIAL, INFO, APPS) if tail.startswith(value)), None)
        require(command is not None, "Unknown query bytes")
        commands.append(command)
        tail = tail[len(command):]
    require(commands.count(APPS) <= (6 if variant == "candidate" else 1),
            "Exceeded Apps request bound")
    require(commands.count(INITIAL) <= (2 if variant == "candidate" else 1),
            "Exceeded version retry bound")
    require(commands.count(INFO) <= 13, "Exceeded Info retry bound")
    if INITIAL in commands:
        require(APPS in commands and commands.index(APPS) < commands.index(INITIAL),
                "Version retry preceded its boundary request")
        return "apps_boundary_version_retry"
    return "single_version_apps_requested" if APPS in commands else "single_version"


DEFAULT_INFO = b"Info;Your IP is logged and you will be nuked VERY soon!\r"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stream_key(stream):
    return stream["port"], stream["first_timestamp"], stream["client"]["syn"]


def capture(path, service_port=12345):
    data = path.read_bytes()
    require(len(data) >= 24 and data[:4] == b"\xd4\xc3\xb2\xa1", "Expected little-endian PCAP")
    require(struct.unpack_from("<I", data, 20)[0] == 1, "Expected Ethernet PCAP")
    position, records, streams, current = 24, 0, [], {}
    while position < len(data):
        require(position + 16 <= len(data), "Truncated PCAP record header")
        sec, usec, included, original = struct.unpack_from("<IIII", data, position)
        position += 16
        require(included == original and position + included <= len(data), "Truncated packet")
        packet = data[position:position + included]
        position += included
        records += 1
        require(len(packet) >= 14, "Short Ethernet frame")
        if packet[12:14] != b"\x08\x00":
            continue
        ip = packet[14:]
        ihl = (ip[0] & 15) * 4
        require(ip[0] >> 4 == 4 and len(ip) >= 20 and ihl >= 20, "Invalid IPv4 header")
        total = struct.unpack_from("!H", ip, 2)[0]
        require(len(ip) >= total and total >= ihl, "Truncated IP packet")
        require(not struct.unpack_from("!H", ip, 6)[0] & 0x3fff, "Fragmented IP packet")
        if ip[9] != 6:
            continue
        tcp = ip[ihl:total]
        require(len(tcp) >= 20, "Short TCP header")
        sport, dport, sequence = struct.unpack_from("!HHI", tcp)
        if service_port not in (sport, dport):
            continue
        require(ip[12:20] == b"\x7f\x00\x00\x01" * 2, "Unexpected non-loopback peer")
        client_port, direction = (sport, "client") if dport == service_port else (dport, "server")
        header = (tcp[12] >> 4) * 4
        require(20 <= header <= len(tcp), "Invalid TCP data offset")
        flags, payload = tcp[13], tcp[header:]
        if direction == "client" and flags & 2 and not flags & 16:
            previous = current.get(client_port)
            if previous is None or previous["client"]["syn"] != sequence:
                current[client_port] = {"port": client_port, "first_timestamp": sec + usec / 1e6,
                    "client": {"syn": sequence, "segments": [], "fin": [], "reset": False},
                    "server": {"syn": None, "segments": [], "fin": [], "reset": False}}
                streams.append(current[client_port])
        require(client_port in current, f"Packet without opening SYN: {client_port}")
        side = current[client_port][direction]
        if flags & 2:
            require(side["syn"] in (None, sequence), "Conflicting SYN sequence")
            side["syn"] = sequence
        if payload:
            side["segments"].append((sequence + bool(flags & 2), payload))
        if flags & 1:
            side["fin"].append((sequence + len(payload)) & 0xffffffff)
        side["reset"] |= bool(flags & 4)
    return records, streams


def reassemble(side):
    require(side["syn"] is not None, "Missing direction's SYN")
    base, positions, duplicates = (side["syn"] + 1) & 0xffffffff, {}, 0
    for sequence, payload in side["segments"]:
        start = (sequence - base) & 0xffffffff
        require(start < 1024 * 1024, "Unexpected TCP sequence span")
        for offset, byte in enumerate(payload, start):
            if offset in positions:
                require(positions[offset] == byte, "Conflicting TCP retransmission")
                duplicates += 1
            positions[offset] = byte
    size = max(positions, default=-1) + 1
    if side["fin"]:
        size = max(size, max((sequence - base) & 0xffffffff for sequence in side["fin"]))
    require(size < 1024 * 1024, "Unexpected FIN sequence span")
    gaps = [offset for offset in range(size) if offset not in positions]
    require(not gaps, f"TCP sequence gaps: {gaps[:20]}")
    return bytes(positions[offset] for offset in range(size)), duplicates


def trace(path, service_port=12345):
    # NSOCK event IDs identify the requested socket even while a prospective
    # connection is open. The previous sequential parser could misattribute
    # an old-socket read after a new socket's banner.
    connections, by_port, by_iod, reads, connect_events = [], {}, {}, {}, {}
    pending_connect, pending_read, newest = None, None, None
    active_ports = set()
    raw = path.read_text()
    start = f"NSE: Starting netbus-version against 127.0.0.1:{service_port}."
    finish = f"NSE: Finished netbus-version against 127.0.0.1:{service_port}."
    require(raw.count(start) == raw.count(finish) == 1, "Expected one completed NSE action")
    lines = raw[raw.index(start):raw.index(finish)].splitlines()
    for line_index, line in enumerate(lines):
        request = re.search(r"TCP connection requested .*\(IOD #(\d+)\).* EID (\d+)", line)
        if request:
            connect_events[int(request[2])] = int(request[1])
        connected = re.search(r"Callback: CONNECT .* for EID (\d+)", line)
        if connected:
            pending_connect = connect_events.get(int(connected[1]))
        request = re.search(r"Read request from IOD #(\d+) .*\(timeout: (\d+)ms\) EID (\d+)", line)
        if request:
            iod, timeout, eid = map(int, request.groups())
            if iod not in by_iod:
                require(newest is not None and newest.get("iod") is None,
                        "Unknown NSOCK read descriptor")
                newest["iod"] = iod
                by_iod[iod] = newest
            require(eid not in reads, "Reused NSOCK event ID")
            reads[eid] = by_iod[iod]
            by_iod[iod]["read_timeouts_ms"].append(timeout)
        callback = re.search(r"Callback: READ (SUCCESS|ERROR|TIMEOUT|EOF).* for EID (\d+)", line)
        if callback:
            reason, eid = callback[1], int(callback[2])
            require(eid in reads, "Read callback without descriptor request")
            entry = reads[eid]
            if reason == "SUCCESS":
                size = re.search(r"\((\d+) bytes\)", line)
                require(size is not None and pending_read is None, "Ambiguous successful read")
                pending_read = entry, int(size[1])
            else:
                entry["read_failures"].append(reason)
                entry["events"].append({"kind": "read_failure", "reason": reason})
        match = re.match(rf"NSE: TCP 127\.0\.0\.1:(\d+) ([<>]) 127\.0\.0\.1:{service_port} \| (.*)", line)
        if not match:
            continue
        port, direction, text = int(match[1]), match[2], match[3]
        if text == "CONNECT":
            require(port not in by_port, "Reused NSE local port")
            active_ports.add(port)
            newest = {"port": port, "query": b"", "reads": [], "read_failures": [],
                      "sends": [], "events": [], "read_timeouts_ms": [], "iod": pending_connect,
                      "active_connections_at_connect": len(active_ports)}
            connections.append(newest); by_port[port] = newest
            if pending_connect is not None:
                require(pending_connect not in by_iod, "Reused NSOCK descriptor")
                by_iod[pending_connect] = newest
            pending_connect = None
            continue
        if text == "CLOSE":
            active_ports.discard(port)
            continue
        if text == "SEND":
            continue
        require(port in by_port, "Unknown trace connection")
        entry = by_port[port]
        hex_dump = re.match(r"00000000: ((?:[0-9a-f]{2} )+)", text)
        if direction == ">":
            require(hex_dump is not None, "Unsupported query trace encoding")
            payload = bytes.fromhex(hex_dump[1]); entry["query"] += payload
            entry["sends"].append(payload.hex())
            entry["events"].append({"kind": "send", "hex": payload.hex()})
        else:
            require(pending_read is not None and pending_read[0] is entry,
                    "Receive trace and NSOCK descriptor differ")
            size = pending_read[1]
            rendered = text
            if not hex_dump:
                continuation = []
                for following in lines[line_index + 1:]:
                    if not following or following.startswith(("NSE:", "NSOCK ")):
                        break
                    continuation.append(following)
                if continuation:
                    rendered += "\n" + "\n".join(continuation)
            entry["reads"].append({"size": size,
                "hex": bytes.fromhex(hex_dump[1]).hex() if hex_dump else None,
                "text": None if hex_dump else rendered})
            entry["events"].append({"kind": "read", "size": size})
            pending_read = None
    require(connections and pending_read is None, f"Incomplete NSE trace in {path.name}")
    return connections


def verify_proxy(condition, pcap, front_by_port, scans):
    from datetime import datetime

    folder = RESULTS / condition
    report = json.loads((folder / "report.json").read_text())
    mode = report["condition"]
    require(mode in ("hold400", "hold400-refuse", "delay600-refuse", "delay1500-refuse", "delay1500-handoff-fail", "split50", "retry-merge100"), "Unknown relay condition")
    source_candidates = [RESULTS.parent / name for name in
                         ("formal-sources", "pilot-v1-sources")]
    source_matches = [folder for folder in source_candidates
                      if (folder / "compare.py").is_file()
                      and sha(folder / "compare.py") == report["runner_sha256"]]
    require(source_matches, "No matching saved relay/runner source")
    source_folder = source_matches[0]
    _, backend_streams = capture(pcap, 12345)
    backend_by_port = {}
    for stream in backend_streams:
        backend_by_port.setdefault(stream["port"], []).append(stream)
    result = {"status": "incomplete", "application_read_boundaries_verified": False,
              "scope": "Per-scan relay writes and TCP byte streams on both sides; these do not establish application read-event boundaries.",
              "connections": [], "scans": [], "conditioned_nse_connections": 0,
              "expected_baseline_misses": 0, "nse_refused_connections": 0}
    for scan in scans:
        stem = scan["stem"]
        log_path = folder / (stem + "-proxy.jsonl")
        control_path = folder / (stem + "-relay.json")
        events = [json.loads(line) for line in log_path.read_text().splitlines()]
        control = json.loads(control_path.read_text())
        ready = [e for e in events if e["event"] == "ready"]
        require(len(ready) == 1 and events[-1]["event"] == "stopped", "Incomplete relay lifecycle")
        ready = ready[0]
        require(ready["listen"] == ["127.0.0.1", 23456] and
                ready["backend"] == ["127.0.0.1", 12345], "Unexpected relay endpoints")
        require(ready["hold_seconds"] == (0.4 if mode.startswith("hold400") else 0)
                and ready["response_delay"] == ({"delay600-refuse": 0.6, "delay1500-refuse": 1.5, "delay1500-handoff-fail": 1.5}.get(mode, 0))
                and ready["refuse_later"] == mode.endswith("-refuse"), "Relay condition differs")
        require(ready.get("fail_replacement_after_banner", False) == (mode == "delay1500-handoff-fail"),
                "Replacement-failure policy differs")
        if mode in ("split50", "retry-merge100"):
            require(ready["split_seconds"] == 0.05, "Split interval differs")
        require(ready.get("retry_merge_seconds", 0) == (0.1 if mode == "retry-merge100" else 0),
                "Later-query merge interval differs")
        require(all(a["elapsed_seconds"] <= b["elapsed_seconds"] for a, b in zip(events, events[1:])),
                "Relay time went backwards")
        require(control["condition"] == mode and control["status"] == "pass" and
                control["ready"] and control["condition_complete"] and control["proxy_exit"] == 0,
                "Relay control did not finish successfully")
        require(control["lifecycle_outside_nmap_wall_timing"] is True and
                not control.get("forced_stop") and not control.get("control_error"), "Invalid relay lifecycle")
        require(control["proxy_sha256"] == sha(source_folder / "condition_proxy.py")
                and control["control_sha256"] == sha(source_folder / "single_query_relay.py"),
                "Relay source hashes changed")
        established = [e for e in events if e["event"] == "condition_established"]
        claims = [e for e in events if e["event"] == "candidate_nse_query"]
        resets = [e for e in events if e["event"] == "condition_claim_reset"]
        require(len(established) == control["established_condition_count"] == 1,
                "Expected exactly one established delivery condition")
        established = established[0]
        target = [e for e in claims if e["connection"] == established["connection"]]
        require(len(target) == 1 and len(claims) == control["candidate_nse_query_count"]
                and len(resets) == control["condition_claim_resets"] == len(claims) - 1,
                "Claim/reset accounting differs")
        target = target[0]
        replacement_failures = [e for e in events if e["event"] == "replacement_failed_after_banner"]
        replacement_expected = mode == "delay1500-handoff-fail" and scan["variant"] == "baseline"
        if mode == "delay1500-handoff-fail":
            require(len(replacement_failures) == int(replacement_expected),
                    "Wrong replacement-failure branch count")
            require(control["replacement_failures"] == replacement_failures and
                    control["replacement_branch_used"] == replacement_expected,
                    "Replacement control differs from raw events")
            require(control["refusal_required"] == replacement_expected,
                    "Candidate unused replacement path was treated as exercised")
            if replacement_expected:
                require(replacement_failures[0]["original_connection"] == target["connection"] and
                        replacement_failures[0]["connection"] != target["connection"],
                        "Replacement failure did not preserve the selected original connection")
            else:
                require(not any(e["event"] == "listener_closed" for e in events),
                        "Candidate unexpectedly exercised replacement/listener failure")
        require(events[-1]["selected_nse_query_connection"] == target["connection"]
                and events[-1]["condition_established"] is True, "Relay target changed")
        for claim in claims:
            if claim["connection"] == target["connection"]:
                continue
            reset = [e for e in resets if e["connection"] == claim["connection"]]
            require(len(reset) == 1 and claim["elapsed_seconds"] < reset[0]["elapsed_seconds"] < target["elapsed_seconds"],
                    "Abandoned condition claim was not reset before the selected connection")
            require(not any(e["event"] == "listener_closed" and e.get("connection") == claim["connection"] for e in events),
                    "Listener closed before a delivery condition was established")
        mappings = {}
        grouped = {}
        for e in events:
            if "connection" in e:
                grouped.setdefault(e["connection"], []).append(e)
            if e["event"] == "connected":
                require(e["front_local"] == ["127.0.0.1", 23456] and
                        e["backend_peer"] == ["127.0.0.1", 12345] and
                        e["front_peer"][0] == e["backend_local"][0] == "127.0.0.1",
                        "Relay endpoint changed")
                require(e["front_peer"][1] not in mappings, "Reused relay frontend port")
                mappings[e["front_peer"][1]] = e
        target_items = []
        for item in scan["connections"]:
            if item.get("status") == "connection_refused":
                continue
            front_port = item["port"]
            require(item.get("status") != "missing_from_capture" and front_port in mappings,
                    "Missing NSE frontend mapping")
            mapping = mappings[front_port]
            backend_port = mapping["backend_local"][1]
            front_candidates = [stream for stream in front_by_port.get(front_port, [])
                                if stream["first_timestamp"] == item["tcp_syn_timestamp"]
                                and stream["client"]["syn"] == item["tcp_client_syn"]]
            require(len(front_candidates) == 1,
                    "Missing or ambiguous relay frontend TCP stream")
            front = front_candidates[0]
            # The OS may reuse a backend ephemeral port in a later scan. Its
            # SYN follows the frontend SYN and precedes the relay's connected
            # event, so this interval must identify exactly one TCP connection.
            connected_at = datetime.fromisoformat(mapping["utc"]).timestamp()
            backend_candidates = [stream for stream in backend_by_port.get(backend_port, [])
                                  if front["first_timestamp"] <= stream["first_timestamp"] <= connected_at]
            require(len(backend_candidates) == 1,
                    "Missing or ambiguous relay backend TCP stream")
            backend = backend_candidates[0]
            fc, _ = reassemble(front["client"]); fs, _ = reassemble(front["server"])
            bc, _ = reassemble(backend["client"]); bs, _ = reassemble(backend["server"])
            ce = grouped[mapping["connection"]]
            def logged(kind, direction):
                return b"".join(bytes.fromhex(e["hex"]) for e in ce
                                if e["event"] == kind and e.get("direction") == direction)
            cr = logged("receive", "client_to_backend"); cw = logged("write", "client_to_backend")
            sr = logged("receive", "backend_to_client"); sw = logged("write", "backend_to_client")
            require(fc.startswith(cr) and cr.startswith(cw) and bc == cw, "Relay client bytes differ")
            require(bs.startswith(sr) and sr.startswith(sw) and fs == sw, "Relay server bytes differ")
            if item["identity_evidence"]:
                require(fc == cr == cw == bc, "Identity-bearing query was not fully forwarded")
            writes = [e for e in ce if e["event"] == "write" and e.get("direction") == "client_to_backend"]
            conditioned = mapping["connection"] == target["connection"]
            extra = {}
            if conditioned:
                result["conditioned_nse_connections"] += 1
                target_items.append(item)
                require(fc.startswith(bytes.fromhex(target["hex"])), "Target query differs from NSE stream")
                if mode in ("split50", "retry-merge100"):
                    splits = [e for e in ce if e["event"] == "split_first_query_complete"]
                    require(len(splits) == 1 and len(writes) >= 2, "Missing split delivery")
                    split = splits[0]
                    initial = b"nbver\rGetInfo\r"
                    require(bytes.fromhex(split["hex"]) == initial
                            and bytes.fromhex(split["prefix_hex"]) == initial[:2]
                            and bytes.fromhex(split["remainder_hex"]) == initial[2:]
                            and split["split_seconds"] == 0.05
                            and split["split_elapsed_seconds"] >= 0.05
                            and split["application_read_verified"] is False,
                            "Split payload or interval differs")
                    require(writes[0]["reason"] == "split_prefix" and writes[0]["hex"] == split["prefix_hex"]
                            and writes[1]["reason"] == "split_remainder" and writes[1]["hex"] == split["remainder_hex"]
                            and writes[1]["elapsed_seconds"] - writes[0]["elapsed_seconds"] >= 0.05,
                            "First query was not written as a two-byte prefix and delayed remainder")
                    if mode == "split50":
                        require(established["reason"] == "split_remainder_written"
                                and established["hex"] == split["hex"]
                                and writes[1]["elapsed_seconds"] <= established["elapsed_seconds"] <= split["elapsed_seconds"],
                                "Split was not established after forwarding the remainder")
                        require(control["split_queries"] == splits, "Split control differs from its raw event")
                    extra["split_prefix_hex"] = split["prefix_hex"]
                    extra["split_remainder_hex"] = split["remainder_hex"]
                    extra["split_interval_seconds"] = writes[1]["elapsed_seconds"] - writes[0]["elapsed_seconds"]
                if mode == "retry-merge100":
                    holds = [e for e in ce if e["event"] == "holding_retry_query"]
                    merged = [e for e in ce if e["event"] == "retry_window_release"]
                    require(len(holds) == len(merged) == 1,
                            "Missing unique later-command merge window")
                    merged = merged[0]
                    payload = b"GetInfo\rGetApps\r"
                    require(holds[0]["hold_seconds"] == 0.1 and
                            bytes.fromhex(holds[0]["first_hex"]).startswith(INFO) and
                            merged["held_seconds"] >= 0.1 and
                            bytes.fromhex(merged["hex"]) == payload and
                            merged["application_read_verified"] is False,
                            "Later commands were not grouped exactly as declared")
                    grouped_writes = [e for e in writes if e["reason"] == "retry_window_release"]
                    require(len(grouped_writes) == 1 and grouped_writes[0]["hex"] == payload.hex(),
                            "Merged commands lack one corresponding backend write")
                    require(established["reason"] == "retry_window_release" and
                            established["hex"] == payload.hex() and
                            grouped_writes[0]["elapsed_seconds"] <= established["elapsed_seconds"] <= merged["elapsed_seconds"],
                            "Condition established before grouped bytes were written")
                    require(control["merged_retries"] == [merged],
                            "Merged control differs from raw events")
                    require(any(e["reason"] == "earlier_retry_passthrough" and
                                e["hex"] == INFO.hex() and
                                e["elapsed_seconds"] < holds[0]["elapsed_seconds"]
                                for e in writes), "First Info retry was not forwarded separately")
                    extra["merged_retry_hex"] = merged["hex"]
                    extra["retry_hold_seconds"] = merged["held_seconds"]
                if mode.startswith("hold400"):
                    holds = [e for e in ce if e["event"] == "holding_first_query"]
                    releases = [e for e in ce if e["event"] == "fixed_window_release"]
                    require(len(holds) == len(releases) == 1 and holds[0]["hold_seconds"] == 0.4,
                            "Missing fixed-duration hold")
                    release = releases[0]
                    expected = b"nbver\rGetInfo\rGetInfo\r"
                    require(release["held_seconds"] >= 0.4 and release["application_read_verified"] is False
                            and bytes.fromhex(release["hex"]) == expected,
                            "Initial commands were not combined under the fixed hold")
                    require(writes and writes[0]["reason"] == "fixed_window_release"
                            and writes[0]["hex"] == release["hex"], "Held commands were not written together")
                    require(established["reason"] == "fixed_window_release" and established["hex"] == release["hex"]
                            and writes[0]["elapsed_seconds"] <= established["elapsed_seconds"] <= release["elapsed_seconds"], "Hold establishment does not follow the released write")
                    extra["fixed_hold_seconds"] = release["held_seconds"]
                    extra["released_hex"] = release["hex"]
                if mode in ("delay600-refuse", "delay1500-refuse", "delay1500-handoff-fail"):
                    delays = [e for e in ce if e["event"] == "response_delay"]
                    reply_writes = [e for e in ce if e["event"] == "write"
                                    and e.get("direction") == "backend_to_client"
                                    and e["elapsed_seconds"] >= target["elapsed_seconds"]]
                    expected_delay = 0.6 if mode == "delay600-refuse" else 1.5
                    require(delays and delays[0]["seconds"] == expected_delay,
                            "Original reply delay was not applied")
                    original_reply = bytes.fromhex(delays[0]["hex"])
                    require(re.fullmatch(rb"1\.3[01]-[0-4]-[0-9]", original_reply) and
                            original_reply.startswith(("1." + report["sample"][1:]).encode()),
                            "Delayed original bytes were not a complete actual version reply")
                    require(any(e["event"] == "receive" and e.get("direction") == "backend_to_client"
                                and e["hex"] == delays[0]["hex"] and
                                target["elapsed_seconds"] <= e["elapsed_seconds"] <= delays[0]["elapsed_seconds"]
                                for e in ce), "Original reply was not received from the real backend")
                    require(established["reason"] == "response_received" and established["hex"] == delays[0]["hex"]
                            and established["elapsed_seconds"] <= delays[0]["elapsed_seconds"],
                            "Delay establishment does not precede its actual reply")
                    extra["original_explicit_response_hex"] = original_reply.hex()
                    if replacement_expected:
                        require(not reply_writes and item["identity_evidence"] is None,
                                "Baseline unexpectedly received the delayed original reply")
                        failed = replacement_failures[0]
                        closed = [e for e in ce if e["event"] == "closed"]
                        require(len(closed) == 1 and delays[0]["elapsed_seconds"] < failed["elapsed_seconds"]
                                <= closed[0]["elapsed_seconds"] < delays[0]["elapsed_seconds"] + expected_delay,
                                "Original connection did not end after replacement failure and before delayed delivery")
                        require("query_handoff" in (folder / (stem + ".log")).read_text(),
                                "Expected miss does not contain the old NSE handoff")
                        extra["original_response_lost_after_handoff"] = True
                    else:
                        require(reply_writes and reply_writes[0]["reason"] == "delayed_response"
                                and delays[0]["hex"] == reply_writes[0]["hex"],
                                "Delayed version response was not forwarded")
                        delay = reply_writes[0]["elapsed_seconds"] - delays[0]["elapsed_seconds"]
                        require(delay >= expected_delay, "Version reply forwarded before delay elapsed")
                        extra["actual_response_delay_seconds"] = delay
                        if mode == "delay1500-handoff-fail":
                            require(item["identity_evidence"] is not None and
                                    item["identity_evidence"]["rule"] == "explicit_version",
                                    "Candidate lacks original-stream explicit identity")
                            extra["replacement_branch_exercised"] = False
                if mode.endswith("-refuse"):
                    closed = [e for e in ce if e["event"] == "listener_closed"]
                    require(len(closed) == 1 and closed[0]["existing_connection_preserved"] is True
                            and established["elapsed_seconds"] <= closed[0]["elapsed_seconds"],
                            "Listener was not closed while preserving the selected connection")
            if replacement_expected and mapping["connection"] == replacement_failures[0]["connection"]:
                failed = replacement_failures[0]
                banner = bytes.fromhex(failed["banner_hex"])
                require(banner.startswith(b"NetBus ") and banner.endswith(b"\r") and
                        bs.startswith(banner) and fs == banner,
                        "Replacement banner was fabricated or not forwarded exactly")
                forwarded = [e for e in ce if e["event"] == "write" and
                             e.get("reason") == "replacement_banner_before_failure"]
                closed_listener = [e for e in ce if e["event"] == "listener_closed"]
                require(len(forwarded) == len(closed_listener) == 1 and
                        forwarded[0]["hex"] == failed["banner_hex"] and
                        forwarded[0]["elapsed_seconds"] <= closed_listener[0]["elapsed_seconds"]
                        <= failed["elapsed_seconds"] and
                        closed_listener[0]["existing_connection_preserved"] is True,
                        "Replacement failure preceded its real banner or closed original")
                extra["replacement_branch_exercised"] = True
                extra["actual_replacement_banner_hex"] = banner.hex()
            result["connections"].append({"ordinal": scan["ordinal"], "variant": scan["variant"],
                "front_port": front_port, "backend_port": backend_port, "proxy_connection": mapping["connection"],
                "query_kind": item["query_kind"], "conditioned": conditioned,
                "backend_client_hex": bc.hex(), "backend_server_hex": bs.hex(),
                "unreceived_frontend_tail_hex": fc[len(cr):].hex(), "unforwarded_query_tail_hex": cr[len(cw):].hex(),
                "unreceived_backend_tail_hex": bs[len(sr):].hex(), "unforwarded_response_tail_hex": sr[len(sw):].hex(),
                "proxy_write_reasons": [e["reason"] for e in writes], **extra})
        require(len(target_items) == 1, "The delivery condition did not target exactly one NSE connection")
        if mode == "retry-merge100":
            if scan["variant"] == "baseline":
                require(target_items[0]["identity_evidence"] is None,
                        "Baseline merge unexpectedly yielded explicit identity")
                result["expected_baseline_misses"] += 1
            else:
                require(target_items[0]["identity_evidence"] is not None and
                        target_items[0]["identity_evidence"]["rule"] == "explicit_version_after_apps",
                        "Candidate did not recover on the original conditioned stream")
        refused = []
        manual_port = None
        if mode.endswith("-refuse") or replacement_expected:
            check = control["refusal_check"]
            require(check["status"] == "pass" and check["outside_nmap_wall_timing"] is True
                    and check["peer"] == ["127.0.0.1", 23456] and check["local"][0] == "127.0.0.1"
                    and check["connect_ex"] == check["expected_errno"] == 111, "Refusal control failed")
            manual_port = check["local"][1]
            begin = datetime.fromisoformat(ready["utc"]).timestamp()
            end = datetime.fromisoformat(events[-1]["utc"]).timestamp()
            manual_candidates = [stream for stream in front_by_port.get(manual_port, [])
                                 if begin <= stream["first_timestamp"] <= end]
            require(len(manual_candidates) == 1, "Missing or ambiguous refusal-control SYN")
            manual = manual_candidates[0]
            require(manual["server"]["reset"] and manual["server"]["syn"] is None
                    and not manual["client"]["segments"], "Refusal control lacks a captured TCP refusal")
            for port, streams in front_by_port.items():
                for stream in streams:
                    if (begin <= stream["first_timestamp"] <= end and port != manual_port
                            and port not in mappings and stream["server"]["reset"]
                            and stream["server"]["syn"] is None and not stream["client"]["segments"]):
                        refused.append(port)
            expected_miss = scan["variant"] == "baseline" and report["baseline_miss_expected"]
            log = (folder / (stem + ".log")).read_text()
            if expected_miss:
                require(refused and "connection_failed: ERROR" in log,
                        "Expected baseline miss lacks an actual failed NSE reconnection")
                if mode.startswith("hold400"):
                    require("info_receive_failed: TIMEOUT" in log and not target_items[0]["successful_read_response_hex"], "Held baseline miss did not come from an unanswered Info deadline")
                result["expected_baseline_misses"] += 1
            require(set(refused) == {item["port"] for item in scan["connections"] if item.get("status") == "connection_refused"}, "Refused TCP attempts differ from NSE trace")
            result["nse_refused_connections"] += len(refused)
        result["scans"].append({"ordinal": scan["ordinal"], "variant": scan["variant"],
            "status": "pass", "abandoned_condition_claims": len(resets), "proxy_log_sha256": sha(log_path), "relay_control_sha256": sha(control_path),
            "manual_refusal_check_port": manual_port, "nse_refused_ports": refused,
            "replacement_branch_exercised": bool(replacement_failures),
            "expected_baseline_miss": scan["expected_baseline_miss"]})
    result["status"] = "pass"
    return result


def analyze_responses(entry, server, variant):
    """Independent command/reply ledger, using only successful read bytes.

    Every requery needs more complete Apps records than requests sent before
    the preceding version query. No pending fragment may cross that boundary.
    """
    cursor = banner_bytes = query_count = apps_count = info_count = 0
    replies = barrier = 0
    pending = bytearray()
    boundaries = []
    parsed_apps = []
    for event in entry["events"]:
        if event["kind"] == "read":
            payload = server[cursor:cursor + event["size"]]
            require(len(payload) == event["size"], "Missing successful read payload")
            cursor += event["size"]
            if not query_count:
                banner_bytes += event["size"]
                continue
            pending.extend(payload)
            while pending.startswith(b"AppNames;") and b"\r" in pending:
                ending = pending.index(13) + 1
                require(apps_count and ending <= 4096, "Unrequested or excessive Apps record")
                record = bytes(pending[:ending]); del pending[:ending]
                replies += 1
                require(replies <= apps_count, "More Apps replies than sent requests")
                parsed_apps.append({"hex": record.hex(), "reply_ordinal": replies,
                                    "version_queries_sent": query_count})
        elif event["kind"] == "send":
            command = bytes.fromhex(event["hex"])
            if not query_count:
                require(command == INITIAL and b"\r" in server[:banner_bytes],
                        "Initial query lacks a complete received banner")
                query_count = 1
                barrier = apps_count
            elif command == INITIAL:
                require(query_count < (3 if variant == "candidate" else 2),
                        "Too many version queries")
                require(not pending and replies > barrier,
                        "Version retry lacks a complete fresh Apps boundary")
                boundaries.append({"apps_sent_before_previous_query": barrier,
                    "apps_received_before_retry": replies, "apps_sent_before_retry": apps_count,
                    "records": parsed_apps[:], "is_identity_evidence": False})
                barrier = apps_count
                query_count += 1
            elif command in (INFO, APPS):
                require(not pending, "Retry was sent while response bytes remained buffered")
                if command == APPS:
                    apps_count += 1
                    require(apps_count <= (6 if variant == "candidate" else 1),
                            "Apps request bound exceeded")
                else:
                    info_count += 1
            else:
                raise ValueError("Unknown sent command")
    response = bytes(pending)
    identity = None
    # If a new boundary is eligible, pre-query text is not version evidence.
    fresh_boundary_pending = replies > barrier
    if query_count and not fresh_boundary_pending:
        if response.startswith(DEFAULT_INFO):
            identity = {"product": "NetBuster", "version": None, "rule": "default_info"}
        else:
            match = re.fullmatch(rb"(1\.3[01])-[0-4]-[0-9]", response[:8])
            if match:
                identity = {"product": "NetBuster", "version": match[1].decode(),
                            "rule": "explicit_version_after_apps" if boundaries else "explicit_version"}
    return {"identity": identity, "banner_read_bytes": banner_bytes,
            "read_bytes_matched": cursor, "successful_read_response_hex": response.hex(),
            "apps_boundary": boundaries[-1] if boundaries else None,
            "apps_boundaries": boundaries, "apps_records": parsed_apps,
            "apps_query_count": apps_count, "version_query_count": query_count,
            "info_retries": info_count}


def verify(condition):
    import xml.etree.ElementTree as ET

    pcap, folder = RESULTS / (condition + ".pcap"), RESULTS / condition
    report_path = folder / "report.json"
    report = json.loads(report_path.read_text())
    require(report["status"] == "pass", f"Benchmark failed: {condition}")
    entries = PLAN["pilot_conditions"] if report["smoke"] else PLAN["ordered_conditions"]
    planned = [entry for entry in entries if entry["label"] == condition]
    require(len(planned) == 1,
            "Condition label is not in the declared plan")
    require(report["sample"] == planned[0]["product"] and
            report["condition"] == planned[0]["condition"],
            "Condition/product differs from its planned label")
    for variant in ("baseline", "candidate"):
        expected_sha = PLAN[variant + "_source_sha256"]
        require(report["variants"][variant]["script_sha256"] == expected_sha and
                sha(RESULTS.parent / (variant + ".nse")) == expected_sha and
                sha(folder / (variant + "-data/scripts/netbus-version.nse")) == expected_sha,
                "Frozen source differs from selected or saved source")
    require(report["runner_sha256"] == sha(RESULTS.parent / "formal-sources/compare.py"),
            "Comparison helper hash differs")
    if report["smoke"]:
        plan = [{"variant": v, "warmup": False, "round": 0}
                for v in ("baseline", "candidate")]
    else:
        plan = [{"variant": v, "warmup": True, "round": None}
                for v in ("baseline", "candidate")]
        for number in range(5):
            plan.extend({"variant": v, "warmup": False, "round": number}
                        for v in (("baseline", "candidate") if number % 2 == 0
                                  else ("candidate", "baseline")))
    require(report["plan"] == plan and len(report["samples"]) == len(plan),
            "Measured/warmup ordering differs from declared plan")
    service_port = report.get("port", 12345)
    require(service_port in (12345, 23456), "Unexpected benchmark port")
    count, streams = capture(pcap, service_port)
    by_port = {}
    for stream in streams:
        by_port.setdefault(stream["port"], []).append(stream)
    result = {"status": "incomplete", "benchmark_report_status": report["status"],
              "pcap_sha256": sha(pcap), "report_sha256": sha(report_path),
              "captured_packets": count, "tcp_connections": len(streams), "scans": [],
              "sequence_gaps": [], "duplicate_payload_bytes": 0, "missing_nse_connections": []}
    matched, totals, expected = set(), Counter(), Counter()
    for sample_index, sample in enumerate(report["samples"]):
        require(sample["status"] == "pass" and not sample["failures"], "Failed scan")
        require(sample["ordinal"] == sample_index, "Duplicate or out-of-order sample ordinal")
        require({k: sample[k] for k in ("variant", "warmup", "round")} == plan[sample["ordinal"]],
                "Sample ordering differs from plan")
        require(sample["script_sha256"] == PLAN[sample["variant"] + "_source_sha256"],
                "Sample source differs from frozen input")
        xml_name = Path(sample["command"][sample["command"].index("-oX") + 1]).name
        xml_path = folder / xml_name
        tree = ET.parse(xml_path).getroot()
        finished = tree.find("./runstats/finished")
        require(finished is not None, "Missing raw XML completion")
        require(finished.get("exit") == "success" and
                float(finished.get("elapsed")) == sample["nmap_elapsed_seconds"],
                "Raw XML elapsed/result differs")
        # XML timestamps have whole-second resolution. Select the SYN within
        # this scan's inclusive second range, then require exactly one stream.
        # A reused ephemeral port in a later scan must not shadow this one.
        scan_start = int(tree.get("start"))
        scan_end = int(finished.get("time")) + 1
        service_element = tree.find(f"./host/ports/port[@portid='{service_port}']/service")
        require(service_element is not None, "Missing raw XML service")
        service = dict(service_element.attrib)
        require(service == sample["service"], "Raw XML differs from saved service")
        actual = {k: service.get(k) for k in ("name", "product", "version", "extrainfo")}
        expect_miss = sample["variant"] == "baseline" and report["condition"] == "retry-merge100"
        if expect_miss:
            required_service = {"name": "netbus", "product": "NetBus trojan", "version": "1.60", "extrainfo": None}
        elif report["sample"] == "170":
            required_service = {"name": "netbus", "product": "NetBus trojan", "version": "1.70", "extrainfo": None}
        else:
            required_service = {"name": "netbus", "product": "NetBuster", "version": None if report["sample"] == "112" else "1." + report["sample"][1:], "extrainfo": "honeypot"}
        require(actual == required_service, "Service differs from independently required identity")
        log = folder / (Path(xml_name).stem + ".log")
        raw_log = log.read_text()
        marker = f"NSE: Starting netbus-version against 127.0.0.1:{service_port}."
        require(raw_log.count(marker) == 1, "Missing unique NSE phase start")
        phase = re.search(r"Completed NSE at [^\n]*, ([0-9.]+)s elapsed",
                          raw_log[raw_log.index(marker):])
        require(phase is not None and float(phase[1]) == sample["nse_phase_seconds"],
                "Raw NSE phase timing differs")
        scan = {"ordinal": sample["ordinal"], "variant": sample["variant"], "stem": Path(xml_name).stem,
                "log_sha256": sha(log), "xml_sha256": sha(xml_path), "connections": [],
                "expected_baseline_miss": expect_miss}
        identities = []
        entries = trace(log, service_port)
        for entry in entries:
            kind = query_kind(entry["query"], sample["variant"])
            expected[kind + "_queries"] += 1
            candidates = [stream for stream in by_port.get(entry["port"], [])
                          if scan_start <= stream["first_timestamp"] < scan_end]
            require(len(candidates) == 1, f"Missing or ambiguous NSE TCP stream: {entry['port']}")
            stream = candidates[0]
            require(stream_key(stream) not in matched, "One TCP stream matched multiple NSE connections")
            tcp_identity = {"tcp_syn_timestamp": stream["first_timestamp"],
                            "tcp_client_syn": stream["client"]["syn"]}
            if stream["server"]["syn"] is None:
                require(stream["server"]["reset"] and not stream["client"]["segments"]
                        and not entry["query"] and not entry["reads"] and not entry["sends"],
                        "Failed connection lacks an unambiguous captured refusal")
                scan["connections"].append({"port": entry["port"], **tcp_identity, "status": "connection_refused",
                    "query_hex": "", "query_kind": "connection_without_query", "identity_evidence": None,
                    "successful_read_response_hex": "", "apps_query_count": 0,
                    "version_query_count": 0, "info_retries": 0, "server_reset": True})
                matched.add(stream_key(stream))
                totals["connection_without_query_queries"] += 1
                continue
            client, cdup = reassemble(stream["client"])
            server, sdup = reassemble(stream["server"])
            require(client == entry["query"], f"PCAP/query mismatch: {entry['port']}")
            cursor = 0
            for read in entry["reads"]:
                payload = server[cursor:cursor + read["size"]]
                require(len(payload) == read["size"], f"Missing received bytes: {entry['port']}")
                if read["hex"] is not None:
                    require(payload.hex() == read["hex"], "Hex receive differs")
                else:
                    require(payload.replace(b"\r", b"").decode("ascii")
                            == read["text"], "Text receive differs")
                cursor += read["size"]
            analyzed = analyze_responses(entry, server, sample["variant"])
            require(analyzed["read_bytes_matched"] == cursor, "Read/event byte counts differ")
            identity = analyzed.pop("identity")
            if identity:
                identities.append(identity)
            response = server.split(b"\r", 1)[1] if b"\r" in server else b""
            totals[kind + "_queries"] += 1
            totals[kind + "_responses"] += bool(response)
            matched.add(stream_key(stream))
            result["duplicate_payload_bytes"] += cdup + sdup
            scan["connections"].append({"port": entry["port"], **tcp_identity, "query_hex": client.hex(),
                "server_hex": server.hex(), "response_hex": response.hex(),
                "query_sends_hex": entry["sends"], "query_kind": kind,
                "identity_evidence": identity, **analyzed,
                "unread_tail_hex": server[cursor:].hex(), "read_failures": entry["read_failures"],
                "server_reset": stream["server"]["reset"], "duplicate_payload_bytes": cdup + sdup})
        require(len(entries) <= 4, "NSE exceeded its total connection-attempt bound")
        max_live = max(e["active_connections_at_connect"] for e in entries)
        require(max_live <= 1,
                "NSE exceeded its simultaneous socket bound")
        scan["maximum_simultaneous_connections"] = max_live
        scan["candidate_info_retries"] = sum(i["info_retries"] for i in scan["connections"])
        scan["apps_queries"] = sum(i["apps_query_count"] for i in scan["connections"])
        require(sum(i["version_query_count"] for i in scan["connections"]) >= 1,
                "Control did not exercise any NetBuster version query")
        require(scan["apps_queries"] <= (6 if sample["variant"] == "candidate" else 1),
                "Apps action request bound exceeded")
        scan["accepted_apps_boundaries"] = sum(bool(i.get("apps_boundary")) for i in scan["connections"])
        require(sum(max(0, i["version_query_count"] - 1) for i in scan["connections"])
                <= (2 if sample["variant"] == "candidate" else 1),
                "Action version retry budget exceeded")
        if service.get("product") == "NetBuster":
            require(any(i["version"] == service.get("version") for i in identities),
                    "NetBuster metadata lacks successfully read explicit evidence")
        else:
            require(not identities, "Negative service has a successfully read NetBuster rule")
        scan["identity_check"] = "pass"
        result["scans"].append(scan)
    for stream in streams:
        if stream_key(stream) not in matched and stream["client"]["segments"]:
            raise ValueError(f"Unmatched client payload: {stream['port']}")
    require(len(result["scans"]) == len(report["plan"]), "Incomplete scan plan")
    result["query_totals"] = dict(totals)
    result["expected_query_totals_from_logs"] = dict(expected)
    result["matched_nse_connections"] = len(matched)
    result["refused_nse_connections"] = sum(i.get("status") == "connection_refused" for s in result["scans"] for i in s["connections"])
    result["established_nse_connections"] = len(matched) - result["refused_nse_connections"]
    result["status"] = "pass"
    summaries = {}
    for variant in ("baseline", "candidate"):
        measured = [s for s in report["samples"] if s["variant"] == variant and not s["warmup"]]
        summaries[variant] = {}
        for metric in ("wall_seconds", "nmap_elapsed_seconds", "nse_phase_seconds"):
            values = [s[metric] for s in measured]
            summaries[variant][metric] = {"n": len(values), "median": statistics.median(values),
                                         "min": min(values), "max": max(values), "values": values}
    require(summaries == report["summaries"], "Saved timing summary differs from retained samples")
    result["recomputed_summaries"] = summaries
    if service_port == 23456:
        result["proxy_verification"] = verify_proxy(condition, pcap, by_port, result["scans"])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    plan_path = Path(__file__).with_name("measurement-plan.json")
    measurement_plan = json.loads(plan_path.read_text()) if plan_path.exists() else {}
    parser.add_argument("--conditions", nargs="+", default=[entry["label"] if isinstance(entry, dict) else entry
                                      for entry in measurement_plan.get("ordered_conditions", [])])
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("capture-verification.json"))
    args = parser.parse_args()
    require(args.conditions, "Supply conditions or a saved measurement plan")
    result = {"status": "incomplete", "scope": "Saved NSE sends/reads matched byte-for-byte to reassembled PCAP TCP streams, including positive evidence from successful reads",
              "limitation": "All NSE query connections must be captured for this check to pass. Relay writes and TCP streams do not by themselves prove application read-event boundaries.",
              "verifier_sha256": sha(Path(__file__)), "conditions": {}}
    for condition in args.conditions:
        try:
            result["conditions"][condition] = verify(condition)
        except (OSError, ValueError, KeyError, IndexError, struct.error) as exc:
            result["conditions"][condition] = {"status": "fail", "error": str(exc)}
    states = {c["status"] for c in result["conditions"].values()}
    result["status"] = "fail" if "fail" in states else ("partial" if "partial" in states else "pass")
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "conditions": {
        name: {key: item[key] for key in ("status", "matched_nse_connections", "established_nse_connections",
                                        "refused_nse_connections", "error") if key in item}
        for name, item in result["conditions"].items()}}, indent=2))
    return int(result["status"] != "pass")


if __name__ == "__main__":
    raise SystemExit(main())
