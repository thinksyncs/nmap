| Condition | Baseline NSE median (s) | Candidate NSE median (s) | Delta (s) |
|---|---:|---:|---:|
| retry-merge100-130-info0 | 5.17 | 1.53 | -3.64 |
| split50-130-info0 | 0.92 | 0.94 | 0.02 |
| delay1500-refuse-130-info0 | 1.84 | 1.82 | -0.02 |
| direct-130-default | 0.29 | 0.29 | 0.0 |
| split50-130-default | 0.71 | 0.71 | 0.0 |
| retry-merge100-131-info0 | 5.17 | 1.55 | -3.62 |
| split50-131-info0 | 0.96 | 0.99 | 0.03 |
| delay1500-refuse-131-info0 | 1.83 | 1.82 | -0.01 |
| direct-131-default | 0.3 | 0.33 | 0.03 |
| split50-131-default | 0.74 | 0.75 | 0.01 |
| direct-112-default | 0.33 | 0.34 | 0.01 |
| hold400-112-default | 0.81 | 0.78 | -0.03 |
| hold400-refuse-112-default | 0.78 | 0.79 | 0.01 |
| direct-170 | 0.09 | 0.09 | 0.0 |
