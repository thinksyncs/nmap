"""Per-scan relay lifecycle. Startup, refusal checks and stop are outside timing."""
import datetime
import errno
import hashlib
import json
import signal
import socket
import subprocess
import time
from pathlib import Path

class Relay:
    def __init__(self, source, condition, out, stem):
        self.source=Path(source);self.condition=condition;self.out=Path(out);self.stem=stem
        self.events=self.out/(stem+'-proxy.jsonl');self.record_path=self.out/(stem+'-relay.json')
        self.process=None;self.stream=None
        command=['python3',str(self.source),'--log',str(self.events)]
        if condition in ['hold400','hold400-refuse']:command+=['--hold-seconds','0.4']
        if condition=='split50':command+=['--split-seconds','0.05']
        if condition=='retry-merge100':command+=['--split-seconds','0.05','--retry-merge-seconds','0.1']
        if condition in ['delay600-refuse','delay1500-refuse']:command+=['--response-delay','0.6' if condition=='delay600-refuse' else '1.5']
        if condition=='delay1500-handoff-fail':command+=['--response-delay','1.5','--fail-replacement-after-banner']
        if condition.endswith('-refuse'):command+=['--refuse-later']
        self.record={'condition':condition,'command':command,'proxy_sha256':hashlib.sha256(self.source.read_bytes()).hexdigest(),'control_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lifecycle_outside_nmap_wall_timing':True,'proxy_exit':None}

    def save(self):self.record_path.write_text(json.dumps(self.record,indent=2)+'\n')

    def start(self):
        self.stream=(self.out/(self.stem+'-proxy.log')).open('w')
        self.process=subprocess.Popen(self.record['command'],stdout=self.stream,stderr=subprocess.STDOUT)
        self.save()
        try:
            deadline=time.monotonic()+5
            while time.monotonic()<deadline:
                assert self.process.poll() is None,'Relay exited before readiness'
                if self.events.exists() and '"event": "ready"' in self.events.read_text():
                    self.record['ready']=True;self.save();return self
                time.sleep(.05)
            raise RuntimeError('Relay readiness deadline exceeded')
        except Exception as error:
            self.record['startup_error']=repr(error);self.finish(check_refusal=False);raise

    def finish(self, check_refusal=True):
        try:
            events=[json.loads(x)for x in self.events.read_text().splitlines()] if self.events.exists() else []
            self.record['candidate_nse_query_count']=sum(x['event']=='candidate_nse_query'for x in events)
            self.record['condition_claim_resets']=sum(x['event']=='condition_claim_reset'for x in events)
            self.record['established_condition_count']=sum(x['event']=='condition_established'for x in events)
            releases=[x for x in events if x['event']=='fixed_window_release']
            self.record['fixed_window_releases']=releases
            self.record['response_delay_count']=sum(x['event']=='response_delay'for x in events)
            self.record['delayed_responses']=[x for x in events if x['event']=='response_delay']
            self.record['condition_complete']=self.record['established_condition_count']==1
            if self.condition.startswith('hold400'):
                self.record['condition_complete'] &= len(releases)==1 and releases[0]['held_seconds']>=.4
            if self.condition=='split50':
                splits=[x for x in events if x['event']=='split_first_query_complete']
                self.record['split_queries']=splits
                self.record['condition_complete'] &= len(splits)==1 and splits[0]['split_elapsed_seconds']>=.05 and len(bytes.fromhex(splits[0]['prefix_hex']))==2 and splits[0]['prefix_hex']+splits[0]['remainder_hex']==splits[0]['hex']
            if self.condition=='retry-merge100':
                merged=[x for x in events if x['event']=='retry_window_release']
                self.record['merged_retries']=merged
                self.record['condition_complete'] &= len(merged)==1 and merged[0]['held_seconds']>=.1 and bytes.fromhex(merged[0]['hex'])==b'GetInfo\rGetApps\r'
            if self.condition in ['delay600-refuse','delay1500-refuse','delay1500-handoff-fail']:
                self.record['condition_complete'] &= self.record['response_delay_count']>=1
            self.record['replacement_failures']=[x for x in events if x['event']=='replacement_failed_after_banner']
            self.record['replacement_branch_used']=bool(self.record['replacement_failures'])
            refusal_required=self.condition.endswith('-refuse') or (self.condition=='delay1500-handoff-fail' and self.record['replacement_branch_used'])
            self.record['refusal_required']=refusal_required
            if check_refusal and refusal_required:
                self.record['listener_closed_logged']=any(x['event']=='listener_closed'for x in events)
                with socket.socket() as sock:
                    sock.settimeout(1);sock.bind(('127.0.0.1',0));local=sock.getsockname()
                    result=sock.connect_ex(('127.0.0.1',23456))
                self.record['refusal_check']={'outside_nmap_wall_timing':True,'local':local,'peer':['127.0.0.1',23456],'connect_ex':result,'expected_errno':errno.ECONNREFUSED,'status':'pass'if result==errno.ECONNREFUSED else 'fail'}
        except Exception as error:self.record['control_error']=repr(error)
        finally:
            if self.process is not None:
                if self.process.poll() is None:self.process.send_signal(signal.SIGINT)
                try:self.record['proxy_exit']=self.process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    self.process.kill();self.record['proxy_exit']=self.process.wait();self.record['forced_stop']=True
            if self.stream is not None:self.stream.close()
            self.record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            self.record['status']='pass' if self.record.get('ready') and self.record.get('condition_complete') and self.record['proxy_exit']==0 and not self.record.get('control_error') and (not self.record.get('refusal_required') or(self.record.get('listener_closed_logged')and self.record.get('refusal_check',{}).get('status')=='pass')) else 'fail'
            self.save()
        return self.record
