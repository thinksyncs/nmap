# Isolated application comparison

These runs compare `baseline.nse` (72aee081...) with `candidate.nse` (1dab4ae5...).
They use the archived NetBuster 1.12, 1.30 and 1.31 applications and NetBus 1.70
inside an isolated Alpine/Wine VM. These are controlled loopback measurements,
not deployment latency or a measurement of real-world false-positive rates.

`sample-provenance.json` maps each current binary hash to its retained archive
source record. `results/final-setup/environment.txt` records tool versions.

`measurement-plan.json` fixes 14 conditions and their order. Each condition has
one warmup per variant, excluded from statistics, and five measured runs per
variant with alternating order. Pilots are separate. The initial traced pilot
failed to establish the target relay condition; its raw files are retained and
excluded. Both pilots without syscall tracing passed before formal measurement started.
All formal runs keep Nmap script tracing; none uses Wine syscall tracing.

## Recheck the retained evidence

From the repository root:

```sh
python3 evidence/netbuster112-retry-boundary/lab/final/verify_captures.py
```

The verifier checks the frozen source and helper hashes, each raw XML/log, TCP
capture reassembly, the requested relay condition, successful response bytes,
identity fields, request limits, connection use and reported timing summaries.
`capture-verification.json` is the result. The runner's wall time is retained;
only Nmap elapsed time and NSE phase time are independently read from raw output.

## Rerun the application experiment

Use a fresh child overlay of the preserved lab image, never write to a parent.
The exact boot command is recorded in `boot-command.json`. During trusted setup,
keep the sample disk unmounted. Remove the setup NIC and backend before mounting
or executing samples; verify QMP reports no network and the guest has only `lo`.
No host shares or forwarded ports are used. `network-removal.json` records this
run's checks. Leave at least 256 MiB host disk space; stop this VM if that guard
is reached. Use the same 4 GiB RAM / 2 CPU / TCG configuration for comparisons.

Place the two NSE copies at `/home/lab/retry-boundary-{baseline,candidate}.nse`
and `formal-sources/*.py` in `/home/lab/retry-boundary-formal/`. Confirm hashes
against `source-freeze.json`. Use a fresh `/home/lab/retry-boundary-results`.
Start only the application named by the current condition. Retained registry
snapshots record settings. For 1.30/1.31 the Info-disabled conditions use
`Infomessages="0"`; default conditions use `"1"` and preserve the nonempty
original message. Change this setting only with that Wine prefix stopped.

For the minimal target reproduction, with NetBuster 1.30 and Info disabled:

```sh
python3 /home/lab/retry-boundary-formal/run_benchmark.py 130 retry-merge100-130-info0 --condition retry-merge100
```

Repeat with 131 for the other version. `run_benchmark.py` captures all traffic,
runs both NSE copies and records exact Nmap arguments. For the full comparison,
follow every entry in `measurement-plan.json`, stopping the old Wine prefix and
verifying no listener remains before switching applications or settings. Record
settings and direct control responses before each group. Export all results and
run the independent verifier after copying them under this directory's `results/`.

The retry-merge relay splits the initial combined query, then holds the second
standalone GetInfo for 100 ms and sends it together with GetApps. It passes later
bytes without alteration. The delayed-response control holds the application's
actual version bytes for 1.5 s and refuses replacement connections while keeping
the original connection alive. Neither condition fabricates an identity reply.
A grouped relay write and reconstructed TCP stream do not prove the boundaries
of the application's receive callbacks.

After measurement, stop the Wine prefix, verify listeners are gone and check process state to distinguish live
processes from unreaped names, sync and export results, then stop this VM and confirm its process
exited. Check both backing-image hashes against `preparation.json` and record the
final child hash. Preserve all prior images and evidence.

## Shutdown record

The final QEMU process exited with code 0 and both parent-image hashes are
unchanged. The pre-quit name-only process check failed; process state was not
recorded. Its aggregate console status was masked by the final sync command.
`guest-stop-assessment.json` preserves that limitation. No listening sockets
remained, the guest had only loopback, and the VM exit ended guest execution.

`lab-completion.json` separates the 168 formal scan results from that auxiliary
shutdown-check limitation. Preserve each check exit status; do not let a later
sync command replace a failed validation exit code.
