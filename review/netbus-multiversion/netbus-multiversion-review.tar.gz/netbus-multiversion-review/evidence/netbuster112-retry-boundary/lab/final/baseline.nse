local nmap = require "nmap"
local shortport = require "shortport"
local stdnse = require "stdnse"

description = [[
Attempts to identify NetBuster from an explicit response. The default
GetInfo message observed in 1.12 identifies the product without a version.
The version query identifies 1.30 and 1.31 from eight response bytes.
An unavailable or incomplete response is not positive evidence.
]]

---
-- @usage
-- nmap -sV -p 12345 --script netbus-version <target>
--
-- @output
-- 12345/tcp open  netbus  NetBuster 1.31 (honeypot)

author = "Toni Ruottu"
license = "Same as Nmap--See https://nmap.org/book/man-legal.html"
categories = {"version"}

portrule = shortport.version_port_or_service ({}, "netbus", {"tcp"})

-- Add a version only after checking its explicit response in a real sample.
local supported_versions = { ["1.30"] = true, ["1.31"] = true }
local default_info =
  "Info;Your IP is logged and you will be nuked VERY soon!\r"
local apps_prefix = "AppNames;"

-- Recompute the timeout after every chunk, including a trickled response.
-- Keep only the bytes needed by the rule; never adopt a failed read's tail.
local function receive(socket, deadline, length, expected, query_response,
    on_silence)
  local data, response_kind = "", nil
  local boundary_requested = false
  local now = nmap.clock_ms()
  local next_info = query_response and (now + 100)
  local next_probe = on_silence and (now + 530)
  local info_attempts = 0
  while #data < length do
    now = nmap.clock_ms()
    local remaining = math.min(5000, deadline - now)
    if remaining < 10 then
      return false, "TIMEOUT"
    end
    local polling = #data == 0 and (next_info or next_probe)
    local timeout = remaining
    if polling then
      if next_info then timeout = math.min(timeout, math.max(10, next_info - now)) end
      if next_probe then timeout = math.min(timeout, math.max(10, next_probe - now)) end
    end
    socket:set_timeout(timeout)
    local status, chunk = socket:receive()
    if not status then
      if not polling or chunk ~= "TIMEOUT" then
        return false, chunk
      end
      now = nmap.clock_ms()
      remaining = math.min(5000, deadline - now)
      if remaining < 10 then
        return false, "TIMEOUT"
      end
      if next_info and now >= next_info then
        socket:set_timeout(remaining)
        local sent, err = socket:send("GetInfo\r")
        info_attempts = info_attempts + 1
        next_info = nmap.clock_ms() + 400
        if not sent then
          stdnse.debug1("info_retry_send_failed: %s", err)
          next_info = nil
        elseif info_attempts == 1 and next_probe then
          next_probe = next_info + 30
        elseif info_attempts == 2 and next_probe then
          next_probe = nmap.clock_ms() + 30
        end
      end
      -- Give the second Info retry time to answer before asking for a
      -- boundary. Keep this socket so a delayed original reply can arrive.
      if next_probe and nmap.clock_ms() >= next_probe then
        next_probe = nil
        remaining = math.min(5000, deadline - nmap.clock_ms())
        if remaining < 10 then return false, "TIMEOUT" end
        socket:set_timeout(remaining)
        boundary_requested = on_silence()
      end
    end
    if status then
      if nmap.clock_ms() > deadline then
        return false, "TIMEOUT"
      end
      if chunk == "" then
        return false, "EOF"
      end
      if query_response and #data == 0 then
        if chunk:sub(1, 1) == "1" then
          length, expected, response_kind = 8, nil, "version"
        elseif boundary_requested and chunk:sub(1, 1) == "A" then
          length, expected, response_kind = 4096, nil, "apps"
        end
      end
      if response_kind == "apps" and #chunk > length - #data then
        return false, "APPNAMES_TOO_LONG"
      end
      data = data .. chunk:sub(1, length - #data)
      if response_kind == "apps" then
        local checked = math.min(#data, #apps_prefix)
        if data:sub(1, checked) ~= apps_prefix:sub(1, checked) then
          return false, "INVALID_APPNAMES"
        end
        local ending = data:find("\r", 1, true)
        if ending then
          -- Do not carry bytes following the boundary into a new reply.
          if ending ~= #data then return false, "MIXED_APPNAMES" end
          return true, data, "apps"
        end
      end
      if expected and data ~= expected:sub(1, #data) then
        return true, data
      end
      if not query_response and length == 4096 then
        local ending = data:find("\r", 1, true)
        if ending then
          return true, data:sub(1, ending - 1)
        end
      end
    end
  end
  if length == 4096 then
    return false, response_kind == "apps" and "APPNAMES_TOO_LONG" or "BANNER_TOO_LONG"
  end
  return true, data, response_kind
end

local function connect(host, port, budget, deadline)
  if budget.attempts >= 4 then return nil end
  local socket = nmap.new_socket()
  budget.attempts = budget.attempts + 1
  local function fail(reason, err)
    socket:close()
    stdnse.debug1("%s: %s", reason, err)
    return nil
  end
  local remaining = deadline and math.min(5000, deadline - nmap.clock_ms()) or 5000
  if remaining < 10 then return fail("probe_deadline_exceeded", "TIMEOUT") end
  socket:set_timeout(remaining)
  local status, response = socket:connect(host, port)
  if not status then return fail("connection_failed", response) end
  status, response = receive(socket, deadline or (nmap.clock_ms() + 5000), 4096)
  if not status then return fail("banner_receive_failed", response) end
  if not response:match("^NetBus ") then
    return fail("unrelated_banner", response)
  end
  return socket
end

local function probe(host, port, budget)
  local socket = connect(host, port, budget, budget.deadline)
  if not socket then return nil end
  local function finish(reason, err)
    socket:close()
    if err then stdnse.debug1("%s: %s", reason, err)
    else stdnse.debug1("%s", reason) end
    return nil
  end
  if not budget.deadline then budget.deadline = nmap.clock_ms() + 5000 end
  local remaining = budget.deadline - nmap.clock_ms()
  if remaining < 10 then return finish("probe_deadline_exceeded") end
  socket:set_timeout(remaining)
  -- An unterminated version reply must not be joined to a retried reply.
  local status, response = socket:send("nbver\rGetInfo\r")
  if not status then
    finish("query_send_failed", response)
    return nil, nil, "transport"
  end

  local on_silence
  if not budget.boundary_checked then
    on_silence = function()
      budget.boundary_checked = true
      local sent, err = socket:send("GetApps\r")
      if not sent then stdnse.debug1("boundary_query_send_failed: %s", err) end
      return sent
    end
  end
  local response_kind
  status, response, response_kind = receive(socket, budget.deadline,
    #default_info, default_info, true, on_silence)
  if status and response_kind == "apps" then
    -- 1.30/1.31 send AppNames synchronously, with body CRs replaced by '|'.
    -- Its complete CR-terminated record ends the earlier response sequence.
    -- It is not a fingerprint. Retry once, with a fresh response buffer.
    remaining = budget.deadline - nmap.clock_ms()
    if remaining < 10 then return finish("probe_deadline_exceeded") end
    socket:set_timeout(remaining)
    status, response = socket:send("nbver\rGetInfo\r")
    if not status then
      finish("retry_query_send_failed", response)
      return nil, nil, "transport"
    end
    status, response, response_kind = receive(socket, budget.deadline,
      #default_info, default_info, true)
  end
  if not status then
    finish("query_receive_failed", response)
    return nil, nil, (response == "EOF" or response == "ERROR") and "transport"
  end
  local version
  if response_kind == "version" then
    version = response:match("^(%d%.%d%d)%-[0-4]%-%d$")
    if not supported_versions[version] then
      finish("fingerprint_mismatch")
      return nil, nil, "mismatch"
    end
  elseif response ~= default_info then
    finish("fingerprint_mismatch")
    return nil, nil, "mismatch"
  end
  socket:close()
  return true, version
end

action = function(host, port)
  local budget = { attempts = 0, transport_retries = 0, mismatch_retries = 0 }
  while budget.attempts < 4 do
    local matched, version, retry = probe(host, port, budget)
    if matched then
      port.version.name = "netbus"
      port.version.product = "NetBuster"
      port.version.version = version
      port.version.extrainfo = "honeypot"
      nmap.set_port_version(host, port)
      return
    end
    if retry == "transport" and budget.transport_retries < 2
        and budget.attempts < 4 then
      budget.transport_retries = budget.transport_retries + 1
    elseif retry == "mismatch" and budget.mismatch_retries < 1 then
      budget.mismatch_retries = budget.mismatch_retries + 1
    else
      return
    end
  end
end
