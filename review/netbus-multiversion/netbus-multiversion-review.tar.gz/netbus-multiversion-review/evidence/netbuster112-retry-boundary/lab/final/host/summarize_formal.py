"""Summarize only the frozen 14 formal conditions after raw verification."""
import datetime,json,collections,hashlib
from pathlib import Path
f=Path(__file__).resolve().parents[1]
p=json.loads((f/'measurement-plan.json').read_text())
v=json.loads((f/'capture-verification.json').read_text())
assert v['status']=='pass'
assert set(v['conditions'])=={x['label'] for x in p['ordered_conditions']}
rows=[];counts=collections.Counter();identities={k:collections.Counter() for k in ['baseline','candidate']}
for item in p['ordered_conditions']:
 r=json.loads((f/'results'/item['label']/'report.json').read_text());assert r['status']=='pass'
 assert len(r['samples'])==12
 verified=v['conditions'][item['label']]
 assert hashlib.sha256((f/'results'/item['label']/'report.json').read_bytes()).hexdigest()==verified['report_sha256']
 assert r['summaries']==verified['recomputed_summaries']
 row={**item,'raw_report':'results/'+item['label']+'/report.json','raw_xml_and_logs_directory':'results/'+item['label'],'raw_capture':'results/'+item['label']+'.pcap','capture_completion':'results/'+item['label']+'-completion.json','nse_phase_seconds':{},'nmap_elapsed_seconds':{},'wall_seconds':{},'identities':{}}
 for k in ['baseline','candidate']:
  samples=[s for s in r['samples'] if s['variant']==k]
  assert len(samples)==6
  for metric in ['nse_phase_seconds','nmap_elapsed_seconds','wall_seconds']:
   row[metric][k]=r['summaries'][k][metric]
  row['identities'][k]=dict(collections.Counter(json.dumps(s['observed_identity'],sort_keys=True) for s in samples))
  identities[k].update(row['identities'][k])
 for s in r['samples']:
  assert s['status']=='pass'
  counts['total']+=1;counts['warmup' if s['warmup'] else 'measured']+=1
  if s['expected_baseline_miss']:counts['expected_baseline_misses']+=1
  if s['variant']=='candidate':
   counts['candidate_scans']+=1
   if item['product']=='170':assert s['service']['product']=='NetBus trojan';counts['negative_control_success']+=1
   else:assert s['detection']=='NetBuster';counts['candidate_positive_success']+=1
   if item['product']=='112':assert 'version' not in s['service'];counts['versionless_112_success']+=1
 row['candidate_minus_baseline_nse_median_seconds']=round(row['nse_phase_seconds']['candidate']['median']-row['nse_phase_seconds']['baseline']['median'],3)
 rows.append(row)
assert counts=={'total':168,'warmup':28,'measured':140,'expected_baseline_misses':12,'candidate_scans':84,'candidate_positive_success':78,'versionless_112_success':18,'negative_control_success':6},counts
report={'status':'pass','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':p['scope'],'candidate_sha256':p['candidate_source_sha256'],'baseline_sha256':p['baseline_source_sha256'],'formal_counts':dict(counts),'pilot_scans_excluded':6,'formal_scans_excluded':0,'identities':{k:dict(c)for k,c in identities.items()},'conditions':rows,'limitations':['Actual archived applications were executed in Wine/TCG, not native Windows.','Grouped relay writes and TCP reconstruction do not prove application receive-call boundaries.','Five measured runs per variant/condition characterize this lab only.','NetBus 1.70 is one concrete negative control; it does not establish a false-positive rate.']}
(f/'formal-summary.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['| Condition | Baseline NSE median (s) | Candidate NSE median (s) | Delta (s) |','|---|---:|---:|---:|']
for r in rows:lines.append('| '+r['label']+' | '+str(r['nse_phase_seconds']['baseline']['median'])+' | '+str(r['nse_phase_seconds']['candidate']['median'])+' | '+str(r['candidate_minus_baseline_nse_median_seconds'])+' |')
(f/'timing-table.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status':'pass','counts':dict(counts)}))
