import argparse
import hashlib
import json
import socket
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('--mode', choices=['banner', 'combined', 'split', 'getinfo', 'getinfo_fragments'], default='combined')
parser.add_argument('--sample', required=True)
args = parser.parse_args()
out = Path('/home/lab/retry-boundary-results') / (args.label + '.json')
assert not out.exists(), out
events = []
started = time.monotonic()

def event(kind, **fields):
    events.append(dict(kind=kind, elapsed_seconds=time.monotonic()-started, **fields))

def receive(sock, stage, terminator=b'\r', limit=4096, timeout=2.0):
    data = bytearray()
    deadline = time.monotonic() + timeout
    while len(data) < limit:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return bytes(data), 'deadline'
        sock.settimeout(remaining)
        try:
            chunk = sock.recv(min(1024, limit-len(data)))
        except TimeoutError:
            event('receive_timeout', stage=stage)
            return bytes(data), 'timeout'
        except OSError as error:
            event('receive_error', stage=stage, error=repr(error))
            return bytes(data), 'error'
        if not chunk:
            event('receive_eof', stage=stage)
            return bytes(data), 'eof'
        event('receive', stage=stage, hex=chunk.hex())
        data.extend(chunk)
        if terminator is not None and terminator in data:
            return bytes(data), 'terminator'
    return bytes(data), 'limit'

report = {'label': args.label, 'mode': args.mode,
          'sample_sha256': hashlib.sha256(Path(args.sample).read_bytes()).hexdigest(),
          'peer': ['127.0.0.1', 12345], 'events': events}
try:
    with socket.create_connection(('127.0.0.1', 12345), timeout=3) as sock:
        report['local_port'] = sock.getsockname()[1]
        event('connected', local_port=report['local_port'])
        banner, state = receive(sock, 'banner')
        report.update(banner_hex=banner.hex(), banner_end=state)
        if state == 'terminator' and args.mode != 'banner':
            chunks = {'combined': [b'nbver\rGetInfo\r'],
                      'split': [b'nbver\r', b'GetInfo\r'],
                      'getinfo': [b'GetInfo\r'],
                      'getinfo_fragments': [b'Get', b'Info\r']}[args.mode]
            for index, chunk in enumerate(chunks):
                if index:
                    time.sleep(0.05)
                sock.sendall(chunk)
                event('send', hex=chunk.hex())
            response, state = receive(sock, 'response', terminator=None)
            report.update(response_hex=response.hex(), response_end=state,
                          response_bytes_received=len(response),
                          collection_window_seconds=2.0)
except OSError as error:
    report['transport_error'] = repr(error)
event('finished')
out.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
