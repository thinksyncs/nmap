"""Measure two NSE files against an already running isolated legacy sample.

This script supplies no isolation and does not launch the legacy sample.
All scans target a selected loopback port (default 12345). Failed samples remain in the report.
"""
import argparse
import hashlib
import json
import re
import shutil
import statistics
import subprocess
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from single_query_relay import Relay


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def expected(product, label, condition):
    if label == "baseline" and condition == "retry-merge100":
        return {"name": "netbus", "product": "NetBus trojan", "version": "1.60", "extrainfo": None}
    if product == "170":
        return {"name": "netbus", "product": "NetBus trojan", "version": "1.70", "extrainfo": None}
    return {"name": "netbus", "product": "NetBuster", "version": None if product == "112" else "1." + product[1:], "extrainfo": "honeypot"}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--product", required=True, choices=["112", "130", "131", "170"])
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--repeats", type=int, default=5)
    p.add_argument("--port", type=int, default=12345)
    p.add_argument("--scan", choices=["syn", "connect"], default="syn")
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--condition", choices=["direct", "hold400", "hold400-refuse", "delay600-refuse", "split50", "delay1500-refuse", "delay1500-handoff-fail", "retry-merge100"], default="direct")
    p.add_argument("--proxy", type=Path)
    a = p.parse_args()
    assert a.repeats >= 1
    assert a.condition == "direct" or a.proxy is not None
    assert 1 <= a.port <= 65535
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    labels = ["baseline", "candidate"]
    variants = {}
    for label in labels:
        source = getattr(a, label).resolve(strict=True)
        datadir = out / (label + "-data")
        (datadir / "scripts").mkdir(parents=True)
        shutil.copyfile(source, datadir / "scripts/netbus-version.nse")
        shutil.copyfile("/usr/share/nmap/scripts/script.db", datadir / "scripts/script.db")
        cmd = ["nmap", "--datadir", str(datadir), "--script-help", "netbus-version", "-oX", "-"]
        result = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, check=True, timeout=15)
        selected = Path(ET.fromstring(result.stdout).find("script").get("filename")).resolve()
        assert selected == (datadir / "scripts/netbus-version.nse").resolve()
        assert sha(source) == sha(selected)
        (out / (label + "-script-help.xml")).write_text(result.stdout)
        variants[label] = {"source_path": str(source), "script_sha256": sha(source), "selected_path": str(selected), "selection_verified": True, "expected_service": expected(a.product, label, a.condition)}
    if a.smoke:
        plan = [{"variant": label, "warmup": False, "round": 0} for label in labels]
    else:
        plan = [{"variant": label, "warmup": True, "round": None} for label in labels]
        for r in range(a.repeats):
            plan.extend({"variant": label, "warmup": False, "round": r} for label in (labels if r % 2 == 0 else labels[::-1]))
    report = {"status": "incomplete", "sample": a.product, "scope": "Isolated QEMU/Wine loopback; not deployment latency", "condition": a.condition, "baseline_miss_expected": a.condition == "retry-merge100", "baseline_identity_observational": False, "scan": a.scan, "port": a.port, "smoke": a.smoke, "started_at_utc": datetime.now(timezone.utc).isoformat(), "variants": variants, "runner_sha256": sha(Path(__file__)), "plan": plan, "warmup_policy": "One per variant excluded for a full comparison; none for smoke", "ordering": "Alternate baseline/candidate ordering each measured round", "gap_seconds_between_scans": 0.5, "samples": [], "nmap_version": subprocess.check_output(["nmap", "--version"], text=True).strip()}
    write(out / "report.json", report)
    for ordinal, planned in enumerate(plan):
        label = planned["variant"]
        stem = f"{ordinal:02d}-{'warmup' if planned['warmup'] else 'measure'}-{label}"
        xml = out / (stem + ".xml")
        datadir = out / (label + "-data")
        cmd = ["nmap", "-n", "-Pn", "-sS" if a.scan == "syn" else "-sT", "-sV", f"-p{a.port}", "--datadir", str(datadir), "--script", "netbus-version", "--script-timeout", "15s", "--script-trace", "-d1", "-oX", str(xml), "127.0.0.1"]
        write(out / (stem + ".command.json"), cmd)
        sample = dict(planned, ordinal=ordinal, command=cmd, script_sha256=variants[label]["script_sha256"], failures=[])
        relay = Relay(a.proxy, a.condition, out, stem).start() if a.condition != "direct" else None
        started = time.monotonic()
        try:
            result = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=40)
            log = result.stdout
            sample["exit_code"] = result.returncode
        except subprocess.TimeoutExpired as error:
            log = error.stdout or b""
            if isinstance(log, bytes):
                log = log.decode(errors="replace")
            sample["exit_code"] = None
            sample["failures"].append("40-second process deadline exceeded")
        sample["wall_seconds"] = round(time.monotonic() - started, 6)
        if relay is not None:
            sample["relay"] = relay.finish()
            if sample["relay"]["status"] != "pass":
                sample["failures"].append("Relay lifecycle or refusal check failed")
            if a.condition == "delay1500-handoff-fail":
                expected_replacements = 0
                if len(sample["relay"].get("replacement_failures", [])) != expected_replacements:
                    sample["failures"].append("Unexpected replacement-connection failure count")
                expected_version = {"130": b"1.30-2-2", "131": b"1.31-1-1"}.get(a.product)
                delayed = sample["relay"].get("delayed_responses", [])
                if expected_version is None or not delayed or bytes.fromhex(delayed[0]["hex"]) != expected_version:
                    sample["failures"].append("Original connection lacks a complete captured version reply before delay")
        (out / (stem + ".log")).write_text(log)
        if sample["exit_code"] != 0:
            sample["failures"].append("Nonzero Nmap exit")
        begin = f"NSE: Starting netbus-version against 127.0.0.1:{a.port}."
        end = f"NSE: Finished netbus-version against 127.0.0.1:{a.port}."
        sample["starts"] = log.count(begin)
        sample["finishes"] = log.count(end)
        if sample["starts"] != 1 or sample["finishes"] != 1:
            sample["failures"].append("Expected exactly one completed action")
        else:
            phase = re.search(r"Completed NSE at [^\n]*, ([0-9.]+)s elapsed", log[log.index(begin):])
            if phase:
                sample["nse_phase_seconds"] = float(phase[1])
            else:
                sample["failures"].append("Missing NSE phase timing")
        if any(marker.lower() in log.lower() for marker in ["threw an error!", "ERROR: Script execution failed", "execution timed out"]):
            sample["failures"].append("NSE runtime error")
        sample["diagnostics"] = re.findall(rf"NSE: \[netbus-version 127\.0\.0\.1:{a.port}\] ([^\n]+)", log)
        try:
            tree = ET.parse(xml).getroot()
            finished = tree.find("./runstats/finished")
            assert finished is not None and finished.get("exit") == "success"
            sample["nmap_elapsed_seconds"] = float(finished.get("elapsed"))
            service = tree.find(f"./host/ports/port[@portid='{a.port}']/service")
            assert service is not None
            sample["service"] = dict(service.attrib)
            actual = {k: service.get(k) for k in ("name", "product", "version", "extrainfo")}
            sample["identity_observational"] = variants[label]["expected_service"] is None
            sample["observed_identity"] = actual
            sample["detection"] = "NetBuster" if service.get("product") == "NetBuster" else "not_NetBuster"
            sample["expected_baseline_miss"] = label == "baseline" and report["baseline_miss_expected"]
            if variants[label]["expected_service"] is not None and actual != variants[label]["expected_service"]:
                sample["failures"].append({"actual": actual, "expected": variants[label]["expected_service"]})
        except (AssertionError, OSError, ET.ParseError, TypeError) as error:
            sample["failures"].append("Invalid or incomplete XML: " + str(error))
        assert sha(datadir / "scripts/netbus-version.nse") == variants[label]["script_sha256"]
        sample["status"] = "fail" if sample["failures"] else "pass"
        report["samples"].append(sample)
        write(out / "report.json", report)
        print(json.dumps({"sample": a.product, "variant": label, "warmup": planned["warmup"], "status": sample["status"], "nse": sample.get("nse_phase_seconds"), "wall": sample["wall_seconds"], "failures": sample["failures"]}), flush=True)
        time.sleep(0.5)
    report["status"] = "pass" if all(s["status"] == "pass" for s in report["samples"]) else "fail"
    report["summaries"] = {}
    for label in labels:
        entries = [s for s in report["samples"] if s["variant"] == label and not s["warmup"]]
        report["summaries"][label] = {}
        for metric in ["wall_seconds", "nmap_elapsed_seconds", "nse_phase_seconds"]:
            values = [s[metric] for s in entries if metric in s]
            if values:
                report["summaries"][label][metric] = {"n": len(values), "median": statistics.median(values), "min": min(values), "max": max(values), "values": values}
    report["timing_note"] = "All available measured timings retained, including failed samples. Overall pass validates all declared identities, including the baseline miss in the controlled later-command merge condition. Relay startup, refusal checks and shutdown are outside wall timing. NSE phase has 0.01-second output resolution."
    report["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    write(out / "report.json", report)
    raise SystemExit(report["status"] != "pass")


if __name__ == "__main__":
    main()
