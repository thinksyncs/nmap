"""Controlled delivery of real application bytes in an isolated loopback lab.

The first recognizable NSE query claims the condition. Earlier version-scan
connections and later connections pass through. A grouped write does not prove
an application callback boundary. Run once per Nmap scan to reset the listener.
"""
import argparse
import asyncio
import datetime
import ipaddress
import json
import signal
import socket
import time
from pathlib import Path

INFO = b'GetInfo\r'
VERSION = b'nbver\r'


async def client_stream(reader, writer, emit, claim, hold_seconds, idle_seconds, establish=None, split_seconds=0, retry_merge_seconds=0):
    pending = bytearray()
    mode = 'inspect'
    first_received = deadline = None
    retries = 0

    async def send(data, reason):
        writer.write(data)
        await writer.drain()
        emit('write', direction='client_to_backend', hex=data.hex(), reason=reason)

    while True:
        if mode == 'retry_hold' and time.monotonic() >= deadline:
            value = bytes(pending)
            await send(value, 'retry_window_release')
            if establish is not None:
                await establish('retry_window_release', value)
            emit('retry_window_release', hex=value.hex(),
                 held_seconds=time.monotonic()-first_received,
                 application_read_verified=False)
            pending.clear()
            mode = 'pass'
            deadline = None
        if mode == 'hold' and time.monotonic() >= deadline:
            await send(bytes(pending), 'fixed_window_release')
            if establish is not None:
                await establish('fixed_window_release', bytes(pending))
            emit('fixed_window_release', hex=bytes(pending).hex(),
                 held_seconds=time.monotonic()-first_received, application_read_verified=False)
            pending.clear()
            mode = 'pass'
            deadline = None
        wait = idle_seconds if deadline is None else max(.001, deadline-time.monotonic())
        try:
            data = await asyncio.wait_for(reader.read(8192), timeout=wait)
        except asyncio.TimeoutError:
            if mode in ['hold', 'retry_hold']:
                continue
            if pending:
                await send(bytes(pending), 'unrecognized_prefix_timeout')
            emit('idle_timeout', direction='client_to_backend')
            return
        if not data:
            if pending:
                await send(bytes(pending), 'early_eof_release')
                emit('condition_incomplete', reason='eof_before_fixed_release')
            emit('eof', direction='client_to_backend')
            return
        emit('receive', direction='client_to_backend', hex=data.hex())
        if mode == 'pass':
            await send(data, 'passthrough')
            continue
        if mode == 'retry':
            pending.extend(data)
            if b'\r' not in pending:
                continue
            value = bytes(pending)
            if value.startswith(INFO):
                retries += 1
            if retries == 2:
                mode = 'retry_hold'
                first_received = time.monotonic()
                deadline = first_received + retry_merge_seconds
                emit('holding_retry_query', hold_seconds=retry_merge_seconds, first_hex=value.hex())
            else:
                await send(value, 'earlier_retry_passthrough')
                pending.clear()
            continue
        if first_received is None:
            first_received = time.monotonic()
        pending.extend(data)
        if mode in ['hold', 'retry_hold']:
            continue
        value = bytes(pending)
        if split_seconds and (VERSION + INFO).startswith(value) and len(value) < len(VERSION + INFO):
            continue
        if any(command.startswith(value) and len(value)<len(command) for command in [INFO, VERSION]):
            continue
        if any(value.startswith(command) for command in [INFO, VERSION]):
            target = await claim(value)
            if target and split_seconds:
                head, tail = value[:2], value[2:]
                await send(head, 'split_prefix')
                split_started = time.monotonic()
                await asyncio.sleep(split_seconds)
                await send(tail, 'split_remainder')
                if establish is not None and not retry_merge_seconds:
                    await establish('split_remainder_written', value)
                emit('split_first_query_complete', hex=value.hex(), prefix_hex=head.hex(),
                     remainder_hex=tail.hex(), split_seconds=split_seconds,
                     split_elapsed_seconds=time.monotonic()-split_started, application_read_verified=False)
                pending.clear()
                mode = 'retry' if retry_merge_seconds else 'pass'
                continue
            if target and hold_seconds:
                mode = 'hold'
                deadline = first_received + hold_seconds
                emit('holding_first_query', hold_seconds=hold_seconds, first_hex=value.hex())
                continue
            reason = 'target_without_hold' if target else 'later_query_passthrough'
        else:
            reason = 'non_target_probe'
        await send(value, reason)
        pending.clear()
        mode = 'pass'


async def serve(args):
    started = time.monotonic()
    stream = args.log.open('x', buffering=1)
    next_id = 0
    first_query = None
    condition_established = False
    active = set()
    stop = asyncio.Event()
    server = None

    def log(event, **fields):
        stream.write(json.dumps({'event':event,'elapsed_seconds':time.monotonic()-started,
                                 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**fields})+'\n')

    async def connection(client_reader, client_writer):
        nonlocal next_id, first_query, condition_established
        next_id += 1
        ident = next_id
        task = asyncio.current_task()
        active.add(task)
        backend_writer = None
        workers = []
        target_state = {'selected':False}

        def emit(event, **fields):
            log(event, connection=ident, **fields)

        async def claim(value):
            nonlocal first_query
            if first_query is not None:
                return False
            first_query = ident
            target_state['selected'] = True
            emit('candidate_nse_query', hex=value.hex())
            return True

        async def establish(reason, data):
            nonlocal condition_established
            if first_query != ident or condition_established:
                return
            condition_established = True
            emit('condition_established', reason=reason, hex=data.hex())
            if args.refuse_later:
                server.close()
                emit('listener_closed', existing_connection_preserved=True)

        try:
            backend_reader, backend_writer = await asyncio.wait_for(
                asyncio.open_connection(args.backend_host,args.backend_port),timeout=3)
            for writer in [client_writer, backend_writer]:
                writer.get_extra_info('socket').setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            emit('connected',front_peer=client_writer.get_extra_info('peername'),
                 front_local=client_writer.get_extra_info('sockname'),
                 backend_peer=backend_writer.get_extra_info('peername'),
                 backend_local=backend_writer.get_extra_info('sockname'))

            async def backend_stream():
                replacement_banner = bytearray()
                while True:
                    data = await asyncio.wait_for(backend_reader.read(8192),timeout=args.idle_seconds)
                    if not data:
                        emit('eof',direction='backend_to_client')
                        return
                    emit('receive',direction='backend_to_client',hex=data.hex())
                    if args.fail_replacement_after_banner and condition_established and ident != first_query:
                        replacement_banner.extend(data)
                        if len(replacement_banner) > 4096:
                            raise ValueError('Replacement banner exceeds capture limit')
                        if b'\r' not in replacement_banner:
                            continue
                        if not replacement_banner.startswith(b'NetBus '):
                            raise ValueError('Unexpected replacement banner')
                        # Forward the actual banner before imposing failure.
                        # The original delayed stream stays under its own task.
                        client_writer.write(replacement_banner)
                        await client_writer.drain()
                        emit('write', direction='backend_to_client', hex=replacement_banner.hex(),
                             reason='replacement_banner_before_failure')
                        server.close()
                        emit('listener_closed', existing_connection_preserved=True,
                             reason='replacement_banner_forwarded')
                        emit('replacement_failed_after_banner', original_connection=first_query,
                             banner_hex=replacement_banner.hex())
                        return
                    delay = args.response_delay if target_state['selected'] else 0
                    if delay:
                        await establish('response_received', data)
                        emit('response_delay',seconds=delay,hex=data.hex())
                        await asyncio.sleep(delay)
                    client_writer.write(data)
                    await client_writer.drain()
                    emit('write',direction='backend_to_client',hex=data.hex(),reason='delayed_response' if delay else 'passthrough')

            workers=[asyncio.create_task(client_stream(client_reader,backend_writer,emit,claim,args.hold_seconds,args.idle_seconds,establish,args.split_seconds,args.retry_merge_seconds)),asyncio.create_task(backend_stream())]
            done,_=await asyncio.wait(workers,return_when=asyncio.FIRST_COMPLETED)
            for worker in done:
                worker.result()
        except asyncio.CancelledError:
            emit('cancelled')
            raise
        except Exception as error:
            emit('connection_error',error=repr(error))
        finally:
            if first_query == ident and not condition_established:
                first_query = None
                emit('condition_claim_reset', reason='selected_connection_ended_before_condition_established')
            for worker in workers:
                worker.cancel()
            await asyncio.gather(*workers,return_exceptions=True)
            for writer in [client_writer,backend_writer]:
                if writer is not None:
                    writer.close()
                    try:await writer.wait_closed()
                    except (ConnectionError,OSError):pass
            emit('closed')
            active.discard(task)

    loop=asyncio.get_running_loop()
    for sig in [signal.SIGINT,signal.SIGTERM]:loop.add_signal_handler(sig,stop.set)
    server=await asyncio.start_server(connection,args.listen_host,args.listen_port)
    log('ready',listen=[args.listen_host,args.listen_port],backend=[args.backend_host,args.backend_port],hold_seconds=args.hold_seconds,split_seconds=args.split_seconds,retry_merge_seconds=args.retry_merge_seconds,response_delay=args.response_delay,refuse_later=args.refuse_later,fail_replacement_after_banner=args.fail_replacement_after_banner,idle_seconds=args.idle_seconds)
    print('READY',flush=True)
    try:await stop.wait()
    finally:
        server.close()
        for task in list(active):task.cancel()
        await asyncio.gather(*list(active),return_exceptions=True)
        await server.wait_closed()
        log('stopped',connections=next_id,selected_nse_query_connection=first_query,condition_established=condition_established)
        stream.close()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--listen-host',default='127.0.0.1');p.add_argument('--listen-port',type=int,default=23456)
    p.add_argument('--backend-host',default='127.0.0.1');p.add_argument('--backend-port',type=int,default=12345)
    p.add_argument('--hold-seconds',type=float,default=0);p.add_argument('--response-delay',type=float,default=0)
    p.add_argument('--split-seconds',type=float,default=0)
    p.add_argument('--retry-merge-seconds',type=float,default=0)
    p.add_argument('--refuse-later',action='store_true');p.add_argument('--idle-seconds',type=float,default=10)
    p.add_argument('--fail-replacement-after-banner',action='store_true')
    p.add_argument('--log',type=Path,required=True);args=p.parse_args()
    assert ipaddress.ip_address(args.listen_host).is_loopback and ipaddress.ip_address(args.backend_host).is_loopback
    assert 0<=args.hold_seconds<=2 and 0<=args.response_delay<=2 and args.idle_seconds>max(args.hold_seconds,args.response_delay)
    assert 0 <= args.split_seconds <= 1
    assert 0 <= args.retry_merge_seconds <= 1
    assert not args.retry_merge_seconds or args.split_seconds
    assert not args.split_seconds or (args.hold_seconds == 0 and args.response_delay == 0)
    assert not args.fail_replacement_after_banner or (args.response_delay > 0 and not args.refuse_later and args.hold_seconds == 0 and args.split_seconds == 0)
    asyncio.run(serve(args))

if __name__=='__main__':main()
