"""Check retained settings and direct application-response controls."""
import json,re
from pathlib import Path
f=Path(__file__).resolve().parents[1];p=json.loads((f/'sample-provenance.json').read_text());hashes={r['version_label'].replace('.',''):r['executable_sha256_verified_in_this_guest'] for r in p['samples']};checks=[]
def read_control(label, mode, product):
 r=json.loads((f/'results'/(label+'.json')).read_text())
 assert r['label']==label and r['mode']==mode and r['sample_sha256']==hashes[product]
 assert 'transport_error' not in r
 events=r['events'];times=[e['elapsed_seconds'] for e in events]
 assert times==sorted(times) and not any(e['kind'].endswith('_error') for e in events)
 received=b''.join(bytes.fromhex(e['hex']) for e in events if e['kind']=='receive' and e['stage']=='response')
 assert received.hex()==r['response_hex'] and len(received)==r['response_bytes_received']
 sends=[e for e in events if e['kind']=='send'];assert len(sends)==1
 assert bytes.fromhex(sends[0]['hex'])==(b'GetInfo\r' if mode=='getinfo' else b'nbver\rGetInfo\r')
 if not received:
  assert r['response_end'] in ('timeout','deadline') and r['collection_window_seconds']==2.0
  finished=[e for e in events if e['kind']=='finished'];assert len(finished)==1
  assert finished[0]['elapsed_seconds']-sends[0]['elapsed_seconds']>=1.99
 return r

for product in ['130','131']:
 for setting in ['info0','default']:
  label=product+'-formal-'+setting
  reg=(f/'results'/ (label+'-loaded-user.reg')).read_text()
  assert '"Infomessages"="'+('0'if setting=='info0'else'1')+'"' in reg
  assert '"InfoMessage"="Your IP is logged and will be reported to your internet provider!"' in reg
  for mode in ['getinfo','combined']:
   name=label+'-'+mode;r=read_control(name,mode,product)
   assert r['label']==name and r['mode']==mode and r['sample_sha256']==hashes[product]
   assert r['banner_hex']==b'NetBus 1.60\r'.hex()
   response=bytes.fromhex(r['response_hex'])
   if mode=='combined':assert re.fullmatch(b'1\\.'+product[1:].encode()+b'-[0-9]-[0-9]',response)
   elif setting=='info0':assert not response and r['collection_window_seconds']==2.0
   else:assert response==b'Info;Your IP is logged and will be reported to your internet provider!\r'
   checks.append({'label':name,'response_hex':r['response_hex'],'status':'pass'})
  change=json.loads((f/'results'/(product+'-formal-default-registry-change.json')).read_text());assert change['old']=='0' and change['new']=='1'
for mode in ['getinfo','combined']:
 name='112-formal-default-'+mode;r=read_control(name,mode,'112');assert r['sample_sha256']==hashes['112'];assert r['banner_hex']==b'NetBus 1.60\r'.hex();assert bytes.fromhex(r['response_hex'])==(b'Info;Your IP is logged and you will be nuked VERY soon!\r' if mode=='getinfo' else b'');checks.append({'label':name,'response_hex':r['response_hex'],'status':'pass'})
name='170-formal-default-getinfo';r=read_control(name,'getinfo','170');assert r['sample_sha256']==hashes['170'];assert r['banner_hex']==b'NetBus 1.70 \r'.hex();response=bytes.fromhex(r['response_hex']);assert response.startswith(b'Info;') and response.endswith(b'\r');assert b'Your IP is logged' not in response;checks.append({'label':name,'response_hex':r['response_hex'],'status':'pass'})
(f/'control-verification.json').write_text(json.dumps({'status':'pass','checks':checks,'scope':'Retained direct control events, sample hashes and settings; formal traffic is independently checked by verify_captures.py.'},indent=2)+'\n')
print(json.dumps({'status':'pass','direct_control_checks':len(checks)}))
