"""Verify the extracted review bundle; optionally run localhost regressions."""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOUNDARY = "evidence/netbuster112-retry-boundary"
LAB = BOUNDARY + "/lab/final"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def run(command, output, name, timeout=180):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    (output / (name + ".stdout.log")).write_text(result.stdout)
    (output / (name + ".stderr.log")).write_text(result.stderr)
    require(result.returncode == 0, f"{name} failed (exit {result.returncode}); see its logs")
    return result.stdout


def verify_manifest():
    manifest = load(ROOT / "MANIFEST.json")
    for name, expected in manifest["files"].items():
        relative = Path(name)
        require(not relative.is_absolute() and ".." not in relative.parts, "Invalid manifest path")
        path = ROOT / relative
        require(path.resolve().is_relative_to(ROOT) and path.is_file() and not path.is_symlink(),
                f"Missing or external artifact: {name}")
        require(path.stat().st_size == expected["size_bytes"] and digest(path) == expected["sha256"],
                f"Changed artifact: {name}")
    require(digest(ROOT / "nse/netbus-version.nse") == manifest["candidate_sha256"], "Wrong candidate")
    return manifest


def verify_patches(output):
    checked = []
    for label, base, patch in (
        ("upstream", "tests/fixtures/upstream/netbus-version.nse", "patches/netbus-multiversion.patch"),
        ("pr3570", "baselines/pr3570/netbus-version.nse", "patches/after-pr3570.patch"),
    ):
        with tempfile.TemporaryDirectory(prefix="netbus-review-patch-") as temporary:
            target = Path(temporary) / "scripts/netbus-version.nse"
            target.parent.mkdir()
            shutil.copyfile(ROOT / base, target)
            command = ["git", "apply", "--whitespace=error-all", str(ROOT / patch)]
            result = subprocess.run(command, cwd=temporary, capture_output=True, text=True)
            require(result.returncode == 0, f"{label} patch failed: {result.stderr}")
            require(target.read_bytes() == (ROOT / "nse/netbus-version.nse").read_bytes(),
                    f"{label} patch did not produce the tested source")
            checked.append(label)
    return checked


def verify_saved_applications(output):
    # The frozen control/summary scripts write beside their inputs. Run copies
    # so neither the attachment nor its preserved measurements are overwritten.
    work = output / "application-recheck"
    shutil.copytree(ROOT / LAB, work)
    run([sys.executable, str(work / "verify_captures.py"), "--output",
         str(work / "capture-verification.json")], output, "application-captures")
    actual, expected = load(work / "capture-verification.json"), load(ROOT / LAB / "capture-verification.json")
    require(actual == expected, "Recomputed capture verification differs from the retained result")
    run([sys.executable, str(work / "host/verify_controls.py")], output, "application-controls")
    require(load(work / "control-verification.json") == load(ROOT / LAB / "control-verification.json"),
            "Recomputed direct controls differ")
    run([sys.executable, str(work / "host/summarize_formal.py")], output, "application-summary")
    actual, expected = load(work / "formal-summary.json"), load(ROOT / LAB / "formal-summary.json")
    for report in (actual, expected):
        report.pop("at_utc", None)
    require(actual == expected, "Recomputed application measurements differ")
    return actual["formal_counts"]


def verify_fixture_sources():
    count = 0
    for path in sorted((ROOT / "tests/fixtures/real").rglob("*.json")):
        fixture = load(path)
        for key in ("source_capture", "pcap"):
            if key + "_sha256" in fixture:
                require(digest(ROOT / fixture[key]) == fixture[key + "_sha256"], "Fixture provenance changed")
        count += 1
    return count


def replay(output):
    counts = {}
    for version in ("1.30", "1.31"):
        folder = output / ("replay-" + version)
        cases = ["real_positive", "real_negative", "info112_real", "info112_eof_55",
                 "info112_altered", "response_eof_7", "response_timeout_0",
                 "late1500_version_refused", "apps_requery", "apps_only"]
        command = [sys.executable, str(ROOT / "tests/test_netbuster_detection.py"),
                   "--selection", "forced", "--output", str(folder), "--cases", *cases]
        if version == "1.30":
            command += ["--positive-fixture", str(ROOT / "tests/fixtures/real/netbuster/combined-130-default.json")]
        run(command, output, "replay-" + version)
        report = load(folder / "report.json")
        require(report["status"] == "pass" and report["failed_cases"] == 0
                and [c["case"] for c in report["cases"]] == cases, "Incomplete replay")
        require(report["script_sha256"] == digest(ROOT / "nse/netbus-version.nse"), "Wrong replay source")
        require(report["positive_recorded_version"] == version, "Wrong replay control")
        counts[version] = len(cases)
    return counts


def compare(output):
    folder = output / "comparison"
    sources = ROOT / BOUNDARY / "tests/comparison-sources-final-guarded"
    cases = ["retry_coalescing:1.30", "retry_coalescing:1.31",
             "retry_coalescing_refuse:1.30", "retry_coalescing_refuse:1.31",
             "hold400_refuse:1.12", "delay1500_refuse:1.30", "delay1500_refuse:1.31"]
    command = [sys.executable, str(ROOT / BOUNDARY / "tests/compare_localhost.py"),
               "--baseline", str(sources / "baseline/netbus-version.nse"),
               "--candidate", str(sources / "candidate/netbus-version.nse"),
               "--repetitions", "1", "--output", str(folder)]
    for case in cases:
        command += ["--case", case]
    run(command, output, "comparison", timeout=300)
    report = load(folder / "summary.json")
    require(report["status"] == "pass" and len(report["runs"]) == 28, "Incomplete comparison")
    require(report["source_sha256"]["candidate"] == digest(ROOT / "nse/netbus-version.nse"),
            "Wrong comparison candidate")
    return {"conditions": len(cases), "scans": len(report["runs"]),
            "scope": "Fresh synthetic localhost reproduction; not new application measurements"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Fresh result directory outside the attachment")
    parser.add_argument("--replay", action="store_true", help="Run 20 actual Nmap saved-response replay cases on localhost")
    parser.add_argument("--compare", action="store_true", help="Run 28 synthetic localhost comparison scans")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() or output.is_relative_to(ROOT):
        parser.error("Choose a new output directory outside the attachment")
    output.mkdir(parents=True)
    report = {"status": "incomplete", "new_application_runs": False, "checks": {}}
    try:
        manifest = verify_manifest()
        report["candidate_sha256"] = manifest["candidate_sha256"]
        report["checks"]["manifest_files"] = len(manifest["files"])
        report["checks"]["patches"] = verify_patches(output)
        report["checks"]["fixture_files"] = verify_fixture_sources()
        stdout = run(["lua", str(ROOT / BOUNDARY / "tests/contracts.lua"),
                      str(ROOT / "nse/netbus-version.nse")], output, "contracts")
        contracts = json.loads(stdout)
        require(contracts["status"] == "pass" and contracts["total"] == 169
                and contracts["failed"] == 0, "Independent contracts failed")
        report["checks"]["contracts"] = contracts["total"]
        stdout = run([sys.executable, str(ROOT / "tests/verify_netbus_review_localhost.py"),
                      str(ROOT / BOUNDARY / "tests/localhost-comparison-final-guarded"),
                      "--root", str(ROOT)], output, "saved-localhost")
        report["checks"]["saved_localhost"] = json.loads(stdout)
        report["checks"]["saved_applications"] = verify_saved_applications(output)
        report["checks"]["fresh_replay"] = replay(output) if args.replay else "not run"
        report["checks"]["fresh_comparison"] = compare(output) if args.compare else "not run"
        verify_manifest()
        report["checks"]["attachment_unchanged"] = True
        report["status"] = "pass"
    except Exception as error:
        report["status"], report["error"] = "fail", str(error)
    (output / "review-report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return int(report["status"] != "pass")


if __name__ == "__main__":
    raise SystemExit(main())
