Title: Extend explicit NetBuster identification

## Summary

- Recognize the default Info reply observed in NetBuster 1.12 without assigning
  a version, and retain explicit 1.30/1.31 identification.

## Changes

- Accept only complete positive response signatures.
- Keep delayed replies on the original connection. Retry version queries only
  after a fresh, complete Apps response confirms a boundary after the previous
  query, with bounded retries and a shared five-second query budget.
- Provide a separate reproduction bundle with control bytes, raw measurements
  and a diff relative to #3570.

## Testing

- Independent socket contracts: 169. Retained synthetic timing comparison: 136 scans.
- Archived applications under Wine/QEMU: 168 scans. The candidate retained all
  78 positive identifications and six negative controls, including 18 versionless
  1.12 results. Later-command coalescing changed from misses at 5.17 seconds to
  detection at 1.53/1.55 seconds for 1.30/1.31.
- The attachment rechecks the retained raw data offline and provides a smaller
  localhost reproduction. See the separate bundle validation report for the
  checks actually run from the extracted attachment.

## Notes

This is an unsubmitted follow-up draft. The timing baseline is the preceding
local multiversion implementation, not #3570. Some other medians increased by up
to 0.03 seconds. Native Windows and real-world detection rates are untested.
The configurable default Info response does not establish a version.
