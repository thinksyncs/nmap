"""Compare NSE variants against an already running isolated loopback service.

This runner does not start an application or provide isolation. Run it inside
the prepared disposable VM. It always scans 127.0.0.1:12345 with SYN scanning.
Warmups are retained but excluded from summaries. All timing samples are saved.
"""

import argparse
import hashlib
import json
import platform
import random
import re
import shutil
import statistics
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path


TARGET = "127.0.0.1"
PORT = 12345
METRICS = ("wall_seconds", "nmap_elapsed_seconds", "action_phase_seconds",
           "nsock_connection_seconds")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def script_location(nmap, datadir=None):
    command = [nmap]
    if datadir is not None:
        command += ["--datadir", str(datadir)]
    command += ["--script-help", "netbus-version", "-oX", "-"]
    result = subprocess.run(command, capture_output=True, text=True, timeout=15,
                            check=True)
    script = ET.fromstring(result.stdout).find("script")
    if script is None:
        raise RuntimeError("Cannot locate installed netbus-version script")
    return Path(script.attrib["filename"]).resolve(strict=True)


def expected_service(product, label):
    if product == "netbus":
        return {"name": "netbus", "product": "NetBus trojan", "version": "1.70",
                "extrainfo": None}
    return {"name": "netbus", "product": "NetBuster",
            "version": None if label in {"upstream", "old", "baseline"} else "1.31",
            "extrainfo": "honeypot"}


def run_sample(nmap, label, datadir, expected, output, ordinal, round_index,
               warmup, script_sha256):
    name = f"{ordinal:03d}-{'warmup' if warmup else 'measure'}-{label}"
    xml_path = output / (name + ".xml")
    command = [nmap, "-n", "-Pn", "-sS", "-sV", "-p", str(PORT),
               "--datadir", str(datadir), "--script", "netbus-version",
               "--script-timeout", "15s", "--script-trace", "-d1",
               "-oX", str(xml_path), TARGET]
    sample = {"ordinal": ordinal, "variant": label, "round": round_index,
              "warmup": warmup, "script_sha256": script_sha256,
              "started_at_utc": datetime.now(timezone.utc).isoformat(),
              "command": command, "status": "incomplete", "failures": []}
    write_json(output / (name + ".command.json"), command)
    started = time.monotonic()
    try:
        # Merge at the subprocess boundary so NSOCK stderr timestamps remain
        # ordered with NSE stdout markers. The .stdout.log is this combined log.
        process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, timeout=40)
        stdout, stderr = process.stdout, ""
        sample["exit_code"] = process.returncode
        if process.returncode:
            sample["failures"].append(f"Nmap exited {process.returncode}")
    except subprocess.TimeoutExpired as exc:
        stdout, stderr = exc.stdout or b"", exc.stderr or b""
        stdout = stdout.decode(errors="replace") if isinstance(stdout, bytes) else stdout
        stderr = stderr.decode(errors="replace") if isinstance(stderr, bytes) else stderr
        sample["exit_code"] = None
        sample["failures"].append("Nmap exceeded the 40-second process deadline")
    sample["wall_seconds"] = round(time.monotonic() - started, 6)
    (output / (name + ".stdout.log")).write_text(stdout)
    (output / (name + ".stderr.log")).write_text(stderr)
    logs = stdout + stderr
    for marker in ("threw an error!", "ERROR: Script execution failed",
                   "yielded unexpectedly", "execution timed out"):
        if marker.lower() in logs.lower():
            sample["failures"].append("NSE failure marker: " + marker)
    if re.search(r"^NSE:.*timed out", logs, re.MULTILINE | re.IGNORECASE):
        sample["failures"].append("NSE timeout marker")
    begin = f"NSE: Starting netbus-version against {TARGET}:{PORT}."
    end = f"NSE: Finished netbus-version against {TARGET}:{PORT}."
    starts = re.findall(r"^NSE: Starting (.+) against (.+)$", logs, re.MULTILINE)
    if starts != [("netbus-version", f"{TARGET}:{PORT}.")]:
        sample["failures"].append(f"Unexpected action set: {starts}")
    if logs.count(begin) != 1 or logs.count(end) != 1:
        sample["failures"].append("Cannot confirm exactly one completed target action")
    elif logs.index(end) <= logs.index(begin):
        sample["failures"].append("Action completion precedes action start")
    else:
        # The phase ending after this action includes socket cleanup. This is
        # useful for upstream, whose socket is closed after action returns.
        tail = logs[logs.index(begin):]
        completed = re.search(r"Completed NSE at [^\n]*, ([0-9.]+)s elapsed", tail)
        if not completed:
            sample["failures"].append("Missing completed action-phase duration")
        else:
            sample["action_phase_seconds"] = float(completed[1])
            phase = tail[:completed.end()]
            connects = re.findall(r"NSOCK INFO \[([0-9.]+)s\].*Callback: CONNECT SUCCESS", phase)
            deletes = re.findall(r"NSOCK INFO \[([0-9.]+)s\].*nsock_iod_delete", phase)
            if len(connects) == 1 and len(deletes) == 1:
                sample["nsock_connection_seconds"] = round(float(deletes[0]) - float(connects[0]), 6)
                if sample["nsock_connection_seconds"] < 0:
                    sample["failures"].append("Negative NSOCK connection duration")
            else:
                sample["nsock_connection_seconds"] = None
                sample["nsock_timing_note"] = "This build did not expose exactly one CONNECT/delete timestamp pair."
    sample["all_nse_phase_seconds"] = round(sum(float(v) for v in re.findall(
        r"Completed NSE at [^\n]*, ([0-9.]+)s elapsed", logs)), 6)
    try:
        tree = ET.parse(xml_path).getroot()
        finished = tree.find("./runstats/finished")
        if finished is None or finished.get("exit") != "success":
            raise ValueError("XML does not report a successful completed scan")
        sample["nmap_elapsed_seconds"] = float(finished.attrib["elapsed"])
        port = tree.find(f"./host/ports/port[@protocol='tcp'][@portid='{PORT}']")
        if port is None or port.find("state") is None or port.find("state").get("state") != "open":
            raise ValueError("Expected loopback port was not open")
        service = port.find("service")
        if service is None:
            raise ValueError("No service identification in final XML")
        sample["service"] = dict(service.attrib)
        actual = {key: service.get(key) for key in expected}
        if actual != expected:
            sample["failures"].append(f"Service metadata mismatch: {actual}; expected {expected}")
        if any("ERROR:" in item.get("output", "") for item in port.findall("script")):
            sample["failures"].append("XML contains an NSE error")
    except (OSError, ET.ParseError, ValueError, KeyError) as exc:
        sample["failures"].append(str(exc))
    if digest(datadir / "scripts/netbus-version.nse") != script_sha256:
        sample["failures"].append("Overlay script changed during sample")
    sample["status"] = "fail" if sample["failures"] else "pass"
    sample["artifacts"] = {
        path.name: {"sha256": digest(path), "size_bytes": path.stat().st_size}
        for suffix in (".xml", ".stdout.log", ".stderr.log", ".command.json")
        if (path := output / (name + suffix)).exists()}
    return sample


def summarize(samples, labels):
    measured = [sample for sample in samples if not sample["warmup"] and sample["status"] == "pass"]
    summaries = {}
    for label in labels:
        entries = [sample for sample in measured if sample["variant"] == label]
        summaries[label] = {}
        for metric in METRICS:
            values = [sample[metric] for sample in entries if sample.get(metric) is not None]
            if values:
                summaries[label][metric] = {"n": len(values), "median": statistics.median(values),
                                           "min": min(values), "max": max(values), "values": values}
    comparisons = {}
    if "upstream" in labels:
        baseline = {s["round"]: s for s in measured if s["variant"] == "upstream"}
        for label in labels:
            if label == "upstream":
                continue
            entries = {s["round"]: s for s in measured if s["variant"] == label}
            comparison = {}
            for metric in METRICS:
                pairs = [{"round": i, "difference_seconds": round(entries[i][metric] - baseline[i][metric], 6)}
                         for i in sorted(baseline.keys() & entries.keys())
                         if baseline[i].get(metric) is not None and entries[i].get(metric) is not None]
                if pairs:
                    comparison[metric] = {"meaning": f"{label} minus upstream, paired by round",
                                          "n": len(pairs), "pairs": pairs,
                                          "median_difference_seconds": statistics.median(p["difference_seconds"] for p in pairs)}
            comparisons[label] = comparison
    return summaries, comparisons


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--product", required=True, choices=("netbus", "netbuster"))
    parser.add_argument("--variant", action="append", required=True, metavar="LABEL=PATH")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20261024)
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("--repeats must be positive")
    variants = {}
    for argument in args.variant:
        label, separator, value = argument.partition("=")
        if not separator or not re.fullmatch(r"[A-Za-z0-9_-]+", label) or label in variants:
            parser.error("Each --variant needs a unique simple LABEL=PATH")
        variants[label] = Path(value).resolve(strict=True)
    if len(variants) < 2:
        parser.error("Provide at least two variants")
    output = args.output.resolve()
    if output.exists():
        parser.error("Choose a new output directory to preserve previous evidence")
    nmap = shutil.which("nmap")
    if not nmap:
        parser.error("Nmap is required")
    output.mkdir(parents=True)
    (output / "scripts").mkdir()
    labels = list(variants)
    random.Random(args.seed).shuffle(labels)
    plan = [{"variant": label, "warmup": True, "round": None} for label in labels]
    for round_index in range(args.repeats):
        order = labels[round_index % len(labels):] + labels[:round_index % len(labels)]
        plan.extend({"variant": label, "warmup": False, "round": round_index} for label in order)
    report = {"status": "incomplete", "product": args.product,
              "scope": "Actual application on isolated guest loopback; not a deployment benchmark",
              "target": f"{TARGET}:{PORT}", "started_at_utc": datetime.now(timezone.utc).isoformat(),
              "repeats_per_variant": args.repeats, "warmups_per_variant": 1, "seed": args.seed,
              "ordering": "Seeded initial shuffle, then rotate one position per measured round",
              "log_streams": "Nmap stderr is merged into stdout during capture to preserve marker/timestamp ordering; .stderr.log is empty",
              "timing_definitions": {
                  "wall_seconds": "Monotonic process duration, including Nmap startup and capture setup",
                  "nmap_elapsed_seconds": "Nmap XML finished.elapsed",
                  "action_phase_seconds": "NSE phase containing the sole target action, including its socket cleanup; printed at 0.01-second resolution",
                  "nsock_connection_seconds": "Successful NSE socket CONNECT callback to socket deletion, when debug timestamps are available"},
              "platform": platform.platform(), "python_version": platform.python_version(),
              "runner_sha256": digest(Path(__file__)), "variants": {}, "plan": plan, "samples": []}
    try:
        report["nmap_version"] = subprocess.check_output([nmap, "--version"], text=True, timeout=15).strip()
        installed = script_location(nmap)
        for label, source in variants.items():
            snapshot = output / "scripts" / (label + ".nse")
            shutil.copyfile(source, snapshot)
            report["variants"][label] = {"source_path": str(source), "snapshot": str(snapshot.relative_to(output)),
                                           "sha256": digest(snapshot), "expected_service": expected_service(args.product, label)}
        with tempfile.TemporaryDirectory(prefix="netbus-live-benchmark-") as temporary:
            overlays = {}
            for label in labels:
                datadir = Path(temporary) / label
                (datadir / "scripts").mkdir(parents=True)
                shutil.copyfile(installed.parent / "script.db", datadir / "scripts/script.db")
                shutil.copyfile(output / "scripts" / (label + ".nse"), datadir / "scripts/netbus-version.nse")
                selected = script_location(nmap, datadir)
                if selected != (datadir / "scripts/netbus-version.nse").resolve():
                    raise RuntimeError("Nmap did not select the intended overlay")
                if digest(selected) != report["variants"][label]["sha256"]:
                    raise RuntimeError("Overlay digest mismatch")
                overlays[label] = datadir
            report["overlay_selection_verified"] = True
            write_json(output / "report.json", report)
            for ordinal, planned in enumerate(plan):
                label = planned["variant"]
                sample = run_sample(nmap, label, overlays[label], expected_service(args.product, label),
                                    output, ordinal, planned["round"], planned["warmup"],
                                    report["variants"][label]["sha256"])
                report["samples"].append(sample)
                write_json(output / "report.json", report)
                print(f"{ordinal:03d} {label} {'warmup' if sample['warmup'] else 'measured'}: "
                      f"{sample['status']} phase={sample.get('action_phase_seconds')}s "
                      f"wall={sample['wall_seconds']}s", flush=True)
                if sample["status"] != "pass":
                    raise RuntimeError("Sample failed; stopping to avoid measuring an unhealthy application: "
                                       + "; ".join(sample["failures"]))
        for label, source in variants.items():
            if digest(source) != report["variants"][label]["sha256"]:
                raise RuntimeError("A source variant changed during the benchmark")
        report["summaries"], report["paired_comparisons"] = summarize(report["samples"], labels)
        report["status"] = "pass"
        return 0
    except Exception as exc:
        report["status"] = "fail"
        report["error"] = repr(exc)
        print("FAIL:", exc, flush=True)
        return 1
    finally:
        report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(output / "report.json", report)


if __name__ == "__main__":
    raise SystemExit(main())
