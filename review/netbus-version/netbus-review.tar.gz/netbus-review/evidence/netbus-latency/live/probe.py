import socket,time,json,sys
product=sys.argv[1]
rows=[]
for mode in ('coalesced','split_lines'):
 for i in range(3):
  with socket.create_connection(('127.0.0.1',12345),timeout=5) as s:
   s.settimeout(5);banner=b''
   while not banner.endswith(b'\r'):
    b=s.recv(1)
    if not b:raise RuntimeError('banner EOF')
    banner+=b
   t=time.monotonic()
   if mode=='coalesced':s.sendall(b'nbver\rGetInfo\r')
   else:
    s.sendall(b'nbver\r');time.sleep(.05);s.sendall(b'GetInfo\r')
   response=b''
   while len(response)<8:
    b=s.recv(8-len(response))
    if not b:raise RuntimeError('response EOF')
    response+=b
   rows.append(dict(mode=mode,repeat=i+1,banner_hex=banner.hex(),request_hex=b'nbver\rGetInfo\r'.hex(),response_hex=response.hex(),elapsed_seconds=round(time.monotonic()-t,6),scope='first eight response bytes; no inference about message termination'))
print(json.dumps(rows,indent=2));open('/home/lab/latency/'+product+'-combined.json','w').write(json.dumps(rows,indent=2)+'\n')
