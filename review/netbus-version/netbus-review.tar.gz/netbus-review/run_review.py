"""Verify this attachment and reproduce the regression on localhost."""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FORCED_CASES = (
    "real_positive", "real_negative", "positive_tail", "negative_denied",
    "split_4", "valid_hold", "valid_eof",
    "response_eof_7", "response_timeout_0", "response_timeout_7",
)
ORDINARY_CASES = (
    "real_positive", "real_negative", "response_eof_7",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for relative, expected in manifest["files"].items():
        relative_path = Path(relative)
        if relative_path.is_absolute() or ".." in relative_path.parts:
            raise ValueError("Unsafe manifest path")
        path = ROOT / relative_path
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"Missing/nonregular attachment: {relative}")
        if path.stat().st_size != expected["size_bytes"] or digest(path) != expected["sha256"]:
            raise ValueError(f"Attachment digest mismatch: {relative}")
    return manifest


def apply_patch(output):
    commands = []
    with tempfile.TemporaryDirectory(prefix="netbus-review-apply-") as temp:
        work = Path(temp)
        (work / "scripts").mkdir()
        target = work / "scripts/netbus-version.nse"
        shutil.copyfile(ROOT / "tests/fixtures/upstream/netbus-version.nse", target)
        for check in (True, False):
            cmd = ["git", "apply"] + (["--check"] if check else [])
            cmd += ["--whitespace=error-all", str(ROOT / "patches/netbus-version.patch")]
            result = subprocess.run(cmd, cwd=work, capture_output=True, text=True)
            commands.append({"command": cmd, "exit_code": result.returncode,
                             "stdout": result.stdout, "stderr": result.stderr})
            if result.returncode:
                raise RuntimeError(f"Patch {'check' if check else 'application'} failed: {result.stderr}")
        if target.read_bytes() != (ROOT / "nse/netbus-version.nse").read_bytes():
            raise RuntimeError("Applied patch differs from the bundled candidate")
        result = {"status": "pass", "commands": commands,
                  "applied_sha256": digest(target), "exact_candidate_byte_equality": True}
        (output / "patch-check.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def run_harness(command, report_path, expected_returncode):
    print("Running:", " ".join(command), flush=True)
    process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=300)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    (report_path.parent / "harness.stdout.log").write_text(process.stdout)
    (report_path.parent / "harness.stderr.log").write_text(process.stderr)
    print(process.stdout, end="", flush=True)
    if process.returncode != expected_returncode:
        raise RuntimeError(f"Unexpected harness exit {process.returncode}; see {report_path.parent}")
    report = json.loads(report_path.read_text())
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    parser.add_argument("--verify-only", action="store_true",
                        help="Verify hashes and patch application without opening sockets")
    parser.add_argument("--full", action="store_true",
                        help="Run all replay cases instead of the smaller review subset")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        parser.error("Use a fresh output directory to preserve prior evidence")
    output.mkdir(parents=True, exist_ok=True)
    summary = {"status": "incomplete", "scope": "loopback replay and patch reproducibility",
               "live_application_execution": False, "checks": {}}
    try:
        manifest = verify_manifest()
        summary["checks"]["manifest"] = "pass"
        summary["candidate_sha256"] = manifest["files"]["nse/netbus-version.nse"]["sha256"]
        summary["checks"]["patch"] = apply_patch(output)
        if args.verify_only:
            summary["status"] = "pass"
            summary["network_tests"] = "not run (--verify-only)"
            return 0
        if not shutil.which("nmap"):
            raise RuntimeError("Install Nmap, including its standard NSE scripts/data, before running the tests")
        for selection, cases in (("forced", FORCED_CASES), ("ordinary", ORDINARY_CASES)):
            case_dir = output / selection
            command = [sys.executable, str(ROOT / "tests/test_netbuster_detection.py"),
                       "--selection", selection, "--output", str(case_dir)]
            if not args.full:
                command += ["--cases", *cases]
            report = run_harness(command, case_dir / "report.json", 0)
            if report["status"] != "pass" or report["failed_cases"]:
                raise RuntimeError(f"{selection} candidate regressions failed")
            if not args.full and [c["case"] for c in report["cases"]] != list(cases):
                raise RuntimeError(f"{selection} case set was incomplete")
            if report["script_sha256"] != summary["candidate_sha256"]:
                raise RuntimeError("Harness executed a different candidate")
            summary["checks"][selection] = {"status": "pass", "cases": len(report["cases"])}
        baseline_dir = output / "upstream-bug"
        command = [sys.executable, str(ROOT / "tests/test_netbus_loopback.py"),
                   "--selection", "ordinary", "--output", str(baseline_dir),
                   "--cases", "auth_timeout", "auth_eof"]
        baseline = run_harness(command, baseline_dir / "report.json", 1)
        cases = baseline.get("cases", [])
        if (baseline.get("status") != "fail" or baseline.get("false_identifications") != 2
                or [c["case"] for c in cases] != ["auth_timeout", "auth_eof"]
                or not all(c.get("false_identification") is True and c.get("nmap_exit_code") == 0
                           for c in cases)):
            raise RuntimeError("The pinned upstream bug was not reproduced as expected")
        expected = manifest["files"]["tests/fixtures/upstream/netbus-version.nse"]["sha256"]
        if baseline["script_sha256"] != expected:
            raise RuntimeError("Baseline executed a different upstream file")
        summary["checks"]["upstream_bug"] = {
            "status": "reproduced", "false_identifications": 2,
            "note": "Expected harness exit 1; Nmap itself completed successfully in both cases."}
        summary["status"] = "pass"
        print("PASS: attachment integrity, patch, candidate regressions and upstream bug reproduction")
        return 0
    except Exception as exc:
        summary["status"] = "fail"
        summary["error"] = str(exc)
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    finally:
        (output / "review-report.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
