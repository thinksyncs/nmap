# fix(nse): prevent false NetBuster identification on receive failure

## Summary

A NetBus banner followed by an authentication timeout or EOF currently causes
`netbus-version` to report NetBuster. Require the explicit NetBuster 1.31 version
response instead, while preserving existing service metadata on failed reads.

## Changes

- Require a complete CR-terminated banner and successful acquisition of the
  eight-byte `1.31-[0-4]-[0-9]` response prefix before identifying NetBuster.
- Send `nbver\rGetInfo\r` on the same connection. NetBuster answers the first
  query; responsive NetBus answers `GetInfo`, avoiding the five-second wait seen
  with `nbver` alone. Keep the existing five-second socket timeout.
- Close sockets on normal exit paths. The code patch changes only
  `scripts/netbus-version.nse` and introduces no library.

## Testing

- Nmap 7.99 / Lua 5.4.8: 41 candidate socket cases passed through `unittest`.
- Actual archived NetBuster 1.31 and NetBus 1.70 returned the expected first eight
  bytes on three combined-query connections and three connections with the two
  complete command lines sent separately, for each product.
- Compared the upstream script, the `nbver`-only candidate, and the final candidate
  in one isolated Wine 10.7 / Alpine 3.22.7 / QEMU 11.1.1 VM. Nmap 7.97 `-sS -sV`
  verified the expected service metadata for every run. Each variant had one
  excluded warmup and five measured runs, with order rotated between rounds.

| Median NSE phase duration | Upstream | `nbver` only | Final candidate |
| --- | ---: | ---: | ---: |
| NetBus 1.70 | 0.06 s | 5.07 s | 0.06 s |
| NetBuster 1.31 | 5.32 s | 0.38 s | 0.40 s |

- Recorded-response replay passed 31 forced-selection and ten ordinary-selection
  cases with the final harness checks.
- Password-protected NetBus returned the `Info;Sor` prefix on six direct-query
  connections. Both upstream and the final candidate preserved `NetBus trojan
  1.70` in two live scans each, including one warmup.

## Notes

The fingerprint consumes the first eight bytes, not the full counter or a message
terminator. Live positive coverage is NetBuster 1.31 with default settings; other
versions, changed settings, and native Windows remain unverified. These tests do
not estimate deployment detection rates. NetBus required disabled Wine audio/MIDI
drivers; NetBuster crashed in the separate TCP-connect-scan experiment, so live
success here is limited to SYN scanning.

Timing reports retain all samples, including a 4.543883-second final-candidate
NetBuster process-duration outlier. NSE phase values have 0.01-second resolution;
process durations also include Nmap startup and scanning.

`REPRODUCE.md` describes the review attachment: fixed upstream source, patch,
control responses and provenance, a reduced capture, and a localhost-only runner.
It also includes the optional live timing runner. Application executables are
excluded. The runner verifies file hashes, applies the patch to the supplied
upstream source, and checks both candidate behavior and the original false
identification. This PR draft has not been submitted.
