"""Exercise an unchanged NSE script against synthetic loopback-only responses.

Exit 0 means no synthetic negative was labelled NetBuster. Exit 1 means a
false identification was observed. Harness failures raise an exception.
These fixtures are not captured NetBus or NetBuster traffic.
"""

import argparse
import hashlib
import json
import shutil
import socket
import socketserver
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIXTURE_SCRIPT = ROOT / "tests/fixtures/upstream/netbus-version.nse"
CASES = (
    "normal_reply",
    "split_banner_normal_reply",
    "auth_timeout",
    "auth_eof",
    "auth_partial_eof",
    "banner_timeout",
    "banner_eof",
    "no_banner_timeout",
    "unrelated_banner",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_case(nmap, script, case, output, selection, datadir=None, expect_diagnostics=False):
    stop = threading.Event()
    events = []
    lock = threading.Lock()

    def event(**fields):
        with lock:
            events.append(fields)

    class Handler(socketserver.BaseRequestHandler):
        def handle(self):
            self.request.settimeout(8)
            try:
                if case == "no_banner_timeout":
                    stop.wait(7)
                    return
                if case.startswith("banner_"):
                    self.request.sendall(b"NetBus 1.70")
                    if case == "banner_timeout":
                        stop.wait(7)
                    return
                if case == "split_banner_normal_reply":
                    self.request.sendall(b"Net")
                    stop.wait(0.03)
                    self.request.sendall(b"Bus 1.70\r")
                elif case == "unrelated_banner":
                    self.request.sendall(b"synthetic unrelated service\r")
                else:
                    self.request.sendall(b"NetBus 1.70\r")

                request = b""
                while not request.endswith(b"\r") and len(request) < 256:
                    chunk = self.request.recv(256)
                    if not chunk:
                        return  # Also handles the port-scan connection.
                    request += chunk
                event(request_hex=request.hex())
                if request != b"Password;0;\r":
                    event(error="unexpected request")
                    return
                if case == "auth_timeout":
                    stop.wait(7)
                elif case == "auth_eof":
                    self.request.shutdown(socket.SHUT_WR)
                elif case == "auth_partial_eof":
                    self.request.sendall(b"Access;0")
                    self.request.shutdown(socket.SHUT_WR)
                else:
                    self.request.sendall(b"Access;0\r")
            except (BrokenPipeError, ConnectionResetError):
                pass  # The initial TCP connect scan may close immediately.
            except Exception as exc:
                event(error=repr(exc))

    class Server(socketserver.ThreadingTCPServer):
        daemon_threads = True

    # No external address or target can be supplied to this harness.
    with Server(("127.0.0.1", 0), Handler) as server:
        port = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        command = [
            nmap, "--unprivileged", "-n", "-Pn", "-sT", "-p", str(port),
            "--script", "+" + str(script) if selection == "forced" else "netbus-version",
            "--script-timeout", "12s",
            "--script-trace", "-d1", "-oX", str(output / (case + ".xml")), "127.0.0.1",
        ]
        if selection == "ordinary":
            command[1:1] = ["-sV", "--version-intensity", "7"]
        if datadir:
            command[1:1] = ["--datadir", str(datadir)]
        start = time.monotonic()
        try:
            process = subprocess.run(command, capture_output=True, text=True, timeout=20)
        finally:
            stop.set()
            server.shutdown()
            thread.join(timeout=2)

    (output / (case + ".stdout.log")).write_text(process.stdout)
    (output / (case + ".stderr.log")).write_text(process.stderr)
    if process.returncode != 0:
        raise RuntimeError(f"{case}: nmap exited {process.returncode}; see saved logs")
    logs = process.stdout + process.stderr
    if any(marker in logs for marker in ("threw an error!", "ERROR: Script execution failed", "yielded unexpectedly")):
        raise RuntimeError(f"{case}: NSE failed; result is incomplete")
    if "execution timed out" in logs.lower():
        raise RuntimeError(f"{case}: NSE timed out; result is incomplete")
    tree = ET.parse(output / (case + ".xml")).getroot()
    target = tree.find(f"./host/ports/port[@portid='{port}']")
    if target is None or target.find("state").get("state") != "open":
        raise RuntimeError(f"{case}: loopback service was not scanned as open")
    service = target.find("service")
    product = service.get("product") if service is not None else None
    if any("error" in record for record in events):
        raise RuntimeError(f"{case}: fixture errors: {events}")
    if case in ("normal_reply", "split_banner_normal_reply", "auth_timeout", "auth_eof", "auth_partial_eof"):
        if not any("request_hex" in record for record in events):
            raise RuntimeError(f"{case}: NSE did not reach the auth exchange")
    if f"NSE: Starting {script.stem} against 127.0.0.1:{port}." not in logs:
        raise RuntimeError(f"{case}: cannot confirm NSE action executed")
    if f"NSE: Finished {script.stem} against 127.0.0.1:{port}." not in logs:
        raise RuntimeError(f"{case}: cannot confirm successful NSE completion")
    diagnostic = {item.get("key"): item.text for item in target.findall("./script/elem")}
    expected = {}
    if case in ("normal_reply", "split_banner_normal_reply"):
        expected = {"verdict": "no_signal", "reason": "authentication_response_received"}
    elif case != "unrelated_banner":
        expected = {
            "verdict": "inconclusive",
            "reason": "authentication_receive_failed" if case.startswith("auth_") else "banner_receive_failed",
            "error": "TIMEOUT" if case.endswith("timeout") else "EOF",
        }
    mismatch = expect_diagnostics and diagnostic != expected
    return {
        "case": case,
        "synthetic_negative": True,
        "command": command,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "nmap_exit_code": process.returncode,
        "service": dict(service.attrib) if service is not None else {},
        "false_identification": product == "NetBuster",
        "diagnostic": diagnostic,
        "diagnostic_mismatch": mismatch,
        "fixture_events": events,
        "xml": case + ".xml",
        "stdout": case + ".stdout.log",
        "stderr": case + ".stderr.log",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--script", type=Path, default=FIXTURE_SCRIPT)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--selection", choices=("forced", "ordinary"), default="forced")
    parser.add_argument("--cases", nargs="+", choices=CASES, default=CASES)
    parser.add_argument("--expect-diagnostics", action="store_true")
    args = parser.parse_args()
    nmap = shutil.which("nmap")
    if not nmap:
        parser.error("nmap is required")
    script = args.script.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = {
        "scope": "synthetic loopback integration, no real-service controls",
        "selection": args.selection,
        "diagnostics_checked": args.expect_diagnostics,
        "script": str(script),
        "script_sha256": digest(script),
        "harness_sha256": digest(Path(__file__)),
        "nmap_version": subprocess.check_output([nmap, "--version"], text=True).strip(),
        "cases": [],
        "positive_detection_preserved": "unverified: no real NetBuster fixture",
        "status": "incomplete",
    }
    report_path = output / "report.json"
    try:
        with tempfile.TemporaryDirectory(prefix="netbus-nmap-data-") as temporary:
            datadir = None
            if args.selection == "ordinary":
                # Overlay only this script and the installed index; leave the
                # system installation intact and retain normal -sV selection.
                datadir = Path(temporary).resolve()
                (datadir / "scripts").mkdir()
                help_xml = subprocess.check_output([nmap, "--script-help", "netbus-version", "-oX", "-"], text=True)
                installed = Path(ET.fromstring(help_xml).find("script").get("filename")).resolve(strict=True)
                shutil.copyfile(installed.parent / "script.db", datadir / "scripts/script.db")
                shutil.copyfile(script, datadir / "scripts/netbus-version.nse")
                selected_xml = subprocess.check_output([nmap, "--datadir", str(datadir), "--script-help", "netbus-version", "-oX", "-"], text=True)
                selected = Path(ET.fromstring(selected_xml).find("script").get("filename")).resolve(strict=True)
                if selected != datadir / "scripts/netbus-version.nse" or digest(selected) != digest(script):
                    raise RuntimeError("Nmap did not select the intended overlay script")
                report["overlay_script_verified"] = True
            for case in args.cases:
                result = run_case(nmap, script, case, output, args.selection, datadir, args.expect_diagnostics)
                report["cases"].append(result)
                print(f"{case}: {'FALSE IDENTIFICATION' if result['false_identification'] else 'no NetBuster label'}; diagnostic={result['diagnostic']}", flush=True)
        failures = sum(case["false_identification"] for case in report["cases"])
        report["false_identifications"] = failures
        failures += sum(case["diagnostic_mismatch"] for case in report["cases"])
        report["status"] = "fail" if failures else "pass"
    finally:
        report_path.write_text(json.dumps(report, indent=2) + "\n")
    return int(failures > 0)


if __name__ == "__main__":
    raise SystemExit(main())
