"""Replay recorded NetBuster/NetBus responses against NSE on loopback only.

The unmodified application bytes come from the named real-service fixtures.
Segmentation, truncation, malformed replies, and transport failures are injected
locally. Passing this harness does not measure deployment detection rates.
"""

import argparse
import errno
import hashlib
import json
import re
import shutil
import socket
import socketserver
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
POSITIVE = ROOT / "tests/fixtures/real/netbuster/combined-default.json"
NEGATIVE = ROOT / "tests/fixtures/real/netbus/combined-170.json"
REQUEST = b"nbver\rGetInfo\r"
HOLD_SECONDS = 7
CASES = (
    "real_positive", "real_negative", "positive_tail", "negative_denied",
    "valid_eof", "valid_hold",
    "split_banner", "malformed_status", "malformed_count", "other_version",
    "unrelated_banner", "banner_eof", "banner_timeout", "no_banner_timeout",
) + tuple(f"split_{n}" for n in range(1, 8)) + tuple(
    f"response_eof_{n}" for n in range(8)
) + ("response_timeout_0", "response_timeout_7")
ORDINARY_CASES = (
    "real_positive", "real_negative", "positive_tail", "negative_denied",
    "valid_eof", "valid_hold",
    "response_eof_7", "response_timeout_0", "malformed_status", "other_version",
)
FORCED_ONLY = {"unrelated_banner", "banner_eof", "banner_timeout", "no_banner_timeout"}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def shutdown_write(connection):
    try:
        connection.shutdown(socket.SHUT_WR)
    except OSError as exc:
        # Nmap may close/reset a scan connection while the fixture is holding it.
        # Suppress only peer-disconnection errors from this shutdown operation.
        if exc.errno not in (errno.ENOTCONN, errno.EPIPE, errno.ECONNRESET):
            raise


def load_fixture(path, positive):
    value = json.loads(path.read_text())
    for key in ("banner_hex", "request_hex", "response_hex"):
        if not isinstance(value.get(key), str):
            raise ValueError(f"{path}: missing hexadecimal field {key}")
        value[key.removesuffix("_hex")] = bytes.fromhex(value[key])
    if value["request"] != REQUEST:
        raise ValueError(f"{path}: the recorded request must be exactly nbver CR GetInfo CR")
    if not re.fullmatch(rb"NetBus [\d.]+[^\r]*\r", value["banner"]):
        raise ValueError(f"{path}: expected a complete NetBus banner")
    if positive:
        if value["response"] != b"1.31-1-1":
            raise ValueError(f"{path}: expected the recorded default NetBuster reply")
    elif value["response"] != b"Info;Pro":
        raise ValueError(f"{path}: expected the recorded eight-byte NetBus reply prefix")
    return value


def case_spec(case, positive, negative):
    fixture = negative if case in {"real_negative", "negative_denied"} else positive
    spec = {
        "banner": fixture["banner"], "response": fixture["response"],
        "expect_signal": case in {"real_positive", "positive_tail", "valid_eof", "valid_hold", "split_banner"} or case.startswith("split_"),
        "expect_request": case not in FORCED_ONLY,
        "hold": case in {"real_negative", "positive_tail", "negative_denied", "valid_hold"} or "timeout" in case,
        "source": "recorded_application_bytes" if case in {"real_positive", "real_negative"} else "controlled_mutation_of_recorded_bytes",
    }
    if case == "positive_tail":
        spec["response"] = b"1.31-1-12345Info;additional response\r"
    elif case == "negative_denied":
        spec["response"] = b"Info;Sorry, host is password protected.\r"
    elif case == "unrelated_banner":
        spec["banner"] = b"unrelated service\r"
    elif case in {"banner_eof", "banner_timeout"}:
        spec["banner"] = fixture["banner"][:-1]
    elif case == "no_banner_timeout":
        spec["banner"] = b""
    elif case.startswith(("response_eof_", "response_timeout_")):
        spec["response"] = fixture["response"][:int(case.rsplit("_", 1)[1])]
    elif case == "malformed_status":
        spec["response"] = b"1.31-5-1"
    elif case == "malformed_count":
        spec["response"] = b"1.31-1-X"
    elif case == "other_version":
        spec["response"] = b"1.32-1-1"
    if not spec["expect_request"]:
        spec["response"] = b""
    return spec


def check_receive_log(case, logs, script_name, port):
    prefix = rf"^NSE: \[{re.escape(script_name)} 127\.0\.0\.1:{port}\] "
    reasons = re.findall(prefix + r"([^\r\n]+)$", logs, re.MULTILINE)
    # Some Nmap builds omit NSOCK trace lines, but retain NSE debug reasons.
    read_timeout = "READ TIMEOUT" in logs or any(reason in {
        "banner_receive_failed: TIMEOUT", "version_receive_failed: TIMEOUT",
    } for reason in reasons)
    failures = []
    if "timeout" not in case and read_timeout:
        failures.append("Unexpected socket read timeout")
    expected = None
    if case in {"real_negative", "negative_denied", "malformed_status", "malformed_count", "other_version"}:
        expected = "fingerprint_mismatch"
    elif case in {"banner_timeout", "no_banner_timeout"}:
        expected = "banner_receive_failed: TIMEOUT"
    elif case.startswith("response_timeout_"):
        expected = "version_receive_failed: TIMEOUT"
    if expected and expected not in reasons:
        failures.append(f"Cannot confirm NSE receive outcome: {expected}")
    return reasons, read_timeout, failures


def run_case(nmap, script, case, output, selection, datadir, positive, negative):
    spec = case_spec(case, positive, negative)
    stop = threading.Event()
    lock = threading.Lock()
    events, handlers = [], []

    def event(**fields):
        with lock:
            events.append(fields)

    class Handler(socketserver.BaseRequestHandler):
        def handle(self):
            done = threading.Event()
            with lock:
                handlers.append(done)
            try:
                self.request.settimeout(HOLD_SECONDS + 1)
                if case == "split_banner":
                    self.request.sendall(spec["banner"][:3])
                    stop.wait(0.05)
                    self.request.sendall(spec["banner"][3:])
                elif spec["banner"]:
                    self.request.sendall(spec["banner"])
                if not spec["expect_request"]:
                    if spec["hold"]:
                        stop.wait(HOLD_SECONDS)
                    shutdown_write(self.request)
                else:
                    request = b""
                    # A TCP read need not contain both command lines.
                    while len(request) < len(REQUEST):
                        chunk = self.request.recv(257 - len(request))
                        if not chunk:
                            return  # TCP connect scan or version-detection connection.
                        request += chunk
                    event(request_hex=request.hex())
                    if request != REQUEST:
                        event(error="unexpected request bytes")
                        return
                    if case.startswith("split_") and case != "split_banner":
                        position = int(case.split("_")[1])
                        self.request.sendall(spec["response"][:position])
                        stop.wait(0.05)
                        self.request.sendall(spec["response"][position:])
                    elif spec["response"]:
                        self.request.sendall(spec["response"])
                    if spec["hold"]:
                        stop.wait(HOLD_SECONDS)
                    shutdown_write(self.request)
                # Observe any extra commands after the expected combined query.
                self.request.settimeout(1)
                extra = self.request.recv(257)
                if extra:
                    event(error="unexpected additional request bytes", request_hex=extra.hex())
            except (BrokenPipeError, ConnectionResetError):
                pass  # Nmap's connect scan may close before reading its banner.
            except Exception as exc:
                event(error=repr(exc))
            finally:
                done.set()

    class Server(socketserver.ThreadingTCPServer):
        daemon_threads = True

    result = {
        "case": case, "data_origin": spec["source"],
        "expected_signal": spec["expect_signal"], "failures": [],
        "fixture_banner_hex": spec["banner"].hex(),
        "fixture_response_hex": spec["response"].hex(),
        "injected_hold_seconds": HOLD_SECONDS if spec["hold"] else 0,
    }
    xml_path = output / (case + ".xml")
    stdout_path, stderr_path = output / (case + ".stdout.log"), output / (case + ".stderr.log")
    started = time.monotonic()
    with Server(("127.0.0.1", 0), Handler) as server:
        port = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        command = [
            nmap, "--unprivileged", "-n", "-Pn", "-sT", "-p", str(port),
            "--script", "+" + str(script) if selection == "forced" else "netbus-version",
            "--script-timeout", "12s", "--script-trace", "-d1",
            "-oX", str(xml_path), "127.0.0.1",
        ]
        if selection == "ordinary":
            command[1:1] = ["-sV", "--version-intensity", "7", "--datadir", str(datadir)]
        result["command"] = command
        (output / (case + ".command.json")).write_text(json.dumps(command, indent=2) + "\n")
        stdout, stderr = "", ""
        try:
            process = subprocess.run(command, capture_output=True, text=True, timeout=25)
            stdout, stderr = process.stdout, process.stderr
            result["nmap_exit_code"] = process.returncode
            if process.returncode:
                result["failures"].append(f"Nmap exit code {process.returncode}")
        except subprocess.TimeoutExpired as exc:
            stdout, stderr = exc.stdout or b"", exc.stderr or b""
            stdout = stdout.decode(errors="replace") if isinstance(stdout, bytes) else stdout
            stderr = stderr.decode(errors="replace") if isinstance(stderr, bytes) else stderr
            result["nmap_exit_code"] = None
            result["failures"].append("Nmap process exceeded the 25-second deadline")
        finally:
            stop.set()
            server.shutdown()
            thread.join(timeout=2)
            with lock:
                active = list(handlers)
            if not all(done.wait(2) for done in active):
                result["failures"].append("Fixture handlers did not finish")

    stdout_path.write_text(stdout)
    stderr_path.write_text(stderr)
    result["fixture_events"] = events
    result["elapsed_seconds"] = round(time.monotonic() - started, 3)
    logs = stdout + stderr
    script_name = script.stem if selection == "forced" else "netbus-version"
    reasons, read_timeout, failures = check_receive_log(case, logs, script_name, port)
    result["receive_reasons"] = reasons
    result["read_timeout_observed"] = read_timeout
    result["failures"].extend(failures)
    for marker in ("threw an error!", "ERROR: Script execution failed", "yielded unexpectedly", "execution timed out"):
        if marker.lower() in logs.lower():
            result["failures"].append(f"NSE failure marker: {marker}")
    if re.search(r"^NSE:.*timed out", logs, re.MULTILINE | re.IGNORECASE):
        result["failures"].append("NSE timeout marker")
    for phase in ("Starting", "Finished"):
        if f"NSE: {phase} {script_name} against 127.0.0.1:{port}." not in logs:
            result["failures"].append(f"Cannot confirm NSE {phase.lower()}")
    if any("error" in record for record in events):
        result["failures"].append("Fixture handler error or unexpected request")
    requests = [record["request_hex"] for record in events if "request_hex" in record]
    if requests != ([REQUEST.hex()] if spec["expect_request"] else []):
        result["failures"].append("NSE did not send exactly the expected request bytes once")
    try:
        tree = ET.parse(xml_path).getroot()
        finished = tree.find("./runstats/finished")
        if finished is None or finished.get("exit") != "success":
            result["failures"].append("Nmap XML does not report successful completion")
        target = tree.find(f"./host/ports/port[@portid='{port}']")
        if target is None or target.find("state") is None or target.find("state").get("state") != "open":
            raise ValueError("The loopback port was not reported open")
        service = target.find("service")
        metadata = dict(service.attrib) if service is not None else {}
        result["service"] = metadata
        actual = {key: metadata.get(key) for key in ("name", "product", "version", "extrainfo")}
        if spec["expect_signal"]:
            expected = {"name": "netbus", "product": "NetBuster", "version": "1.31", "extrainfo": "honeypot"}
            if actual != expected:
                result["failures"].append(f"Positive metadata mismatch: {actual}")
        elif selection == "ordinary":
            version = re.match(rb"NetBus ([\d.]+)", spec["banner"])[1].decode("ascii")
            expected = {"name": "netbus", "product": "NetBus trojan", "version": version, "extrainfo": None}
            if actual != expected:
                result["failures"].append(f"Existing NetBus version metadata changed: {actual}")
        elif any(metadata.get(key) is not None for key in ("product", "version", "extrainfo")) or metadata.get("method", "table") != "table":
            result["failures"].append(f"Negative result altered version metadata: {metadata}")
        if any("ERROR:" in item.get("output", "") for item in target.findall("script")):
            result["failures"].append("XML contains a script error")
    except (ET.ParseError, OSError, ValueError) as exc:
        result["failures"].append(f"Cannot validate XML: {exc}")
    result["status"] = "fail" if result["failures"] else "pass"
    result["artifacts"] = {
        path.name: {"sha256": digest(path), "size_bytes": path.stat().st_size}
        for path in (xml_path, stdout_path, stderr_path, output / (case + ".command.json")) if path.exists()
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--script", type=Path, default=ROOT / "nse/netbus-version.nse")
    parser.add_argument("--positive-fixture", type=Path, default=POSITIVE)
    parser.add_argument("--negative-fixture", type=Path, default=NEGATIVE)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--selection", choices=("forced", "ordinary"), default="forced")
    parser.add_argument("--cases", choices=CASES, nargs="+")
    args = parser.parse_args()
    cases = args.cases or (CASES if args.selection == "forced" else ORDINARY_CASES)
    if args.selection == "ordinary" and FORCED_ONLY.intersection(cases):
        parser.error("Incomplete or unrelated banners require --selection forced to exercise the NSE action")
    nmap = shutil.which("nmap")
    if not nmap:
        parser.error("nmap is required")
    script = args.script.resolve(strict=True)
    positive_path, negative_path = args.positive_fixture.resolve(strict=True), args.negative_fixture.resolve(strict=True)
    positive, negative = load_fixture(positive_path, True), load_fixture(negative_path, False)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any((output / (case + suffix)).exists() for case in cases for suffix in (".xml", ".stdout.log", ".stderr.log", ".command.json")) or (output / "report.json").exists():
        parser.error("Choose a fresh output directory to preserve previous evidence")
    report = {
        "scope": "loopback replay of recorded application bytes with controlled transport and response mutations",
        "selection": args.selection, "status": "incomplete", "cases": [],
        "script": str(script), "script_sha256": digest(script),
        "harness_sha256": digest(Path(__file__)),
        "fixtures": {str(path): {"sha256": digest(path)} for path in (positive_path, negative_path)},
        "negative_recorded_response_hex": negative["response"].hex(),
        "positive_detection_preserved": "not yet evaluated",
        "nmap_version": subprocess.check_output([nmap, "--version"], text=True).strip(),
    }
    try:
        with tempfile.TemporaryDirectory(prefix="netbuster-nmap-data-") as temporary:
            datadir = None
            if args.selection == "ordinary":
                datadir = Path(temporary).resolve()
                (datadir / "scripts").mkdir()
                help_xml = subprocess.check_output([nmap, "--script-help", "netbus-version", "-oX", "-"], text=True)
                installed = Path(ET.fromstring(help_xml).find("script").get("filename")).resolve(strict=True)
                shutil.copyfile(installed.parent / "script.db", datadir / "scripts/script.db")
                shutil.copyfile(script, datadir / "scripts/netbus-version.nse")
                selected_xml = subprocess.check_output([nmap, "--datadir", str(datadir), "--script-help", "netbus-version", "-oX", "-"], text=True)
                selected = Path(ET.fromstring(selected_xml).find("script").get("filename")).resolve(strict=True)
                if selected != datadir / "scripts/netbus-version.nse" or digest(selected) != digest(script):
                    raise RuntimeError("Nmap did not select the intended overlay script")
                report["overlay_script_verified"] = True
            for case in cases:
                result = run_case(nmap, script, case, output, args.selection, datadir, positive, negative)
                report["cases"].append(result)
                print(f"{case}: {result['status']}" + ("; " + "; ".join(result["failures"]) if result["failures"] else ""), flush=True)
        if digest(script) != report["script_sha256"]:
            raise RuntimeError("The candidate script changed during the run")
        report["failed_cases"] = sum(case["status"] != "pass" for case in report["cases"])
        report["status"] = "fail" if report["failed_cases"] else "pass"
        real_positive = next((case for case in report["cases"] if case["case"] == "real_positive"), None)
        report["positive_detection_preserved"] = (
            "recorded real NetBuster default reply identified in loopback replay"
            if real_positive and real_positive["status"] == "pass"
            else "failed or not evaluated"
        )
    except Exception as exc:
        report["error"] = repr(exc)
        raise
    finally:
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    return int(report["status"] != "pass")


if __name__ == "__main__":
    raise SystemExit(main())
