# honeypot-signals

[日本語](README.ja.md)

Measured results: [VALIDATION.md](VALIDATION.md) records 12 passing Lua test groups, 6 real Nmap integration cases, and the independent stock-Nmap camouflage result.

A self-contained Lua script for the Nmap Scripting Engine (NSE) that reports **observable signals associated with honeypots**. Version 0.1 is a research prototype, released under the BSD 2-Clause license.

## Purpose

This project studies defensive camouflage: a legitimate service deliberately exposes a honeypot-associated fingerprint, and an attacker may decide to move on. The detector reports the evidence it actually observed, while the accompanying local fixture makes selected signals reproducible.

All detection rules are visible in the script and each finding includes its evidence and limitations. The deliberate intervention is the service's response camouflage.

The research question is whether distributing useful detection rules and making their signals reproducible can reduce subsequent attack attempts. A fingerprint match establishes neither that a host is a honeypot nor that an attacker will avoid it. Detector adoption, attacker decisions, and attack reduction require separate measurements; see [EVALUATION.md](EVALUATION.md).

## Quick start

Run Nmap from this directory against a host you own or are authorized to assess:

```sh
nmap -sT -Pn -n -p22,80,443,365,2222,8081 --script ./honeypot-signals.nse <authorized-host>
```

Select HTTP explicitly and request diagnostic output:

```sh
nmap -sT -Pn -n -p8081 --script ./honeypot-signals.nse \
  --script-args honeypot-signals.protocol=http,honeypot-signals.verbose=true \
  <authorized-host>
```

Adding `-sV` supplies Nmap service-detection metadata. It also causes Nmap to send its own additional version-detection probes, separate from this script's requests.

### Arguments

| Argument | Default | Meaning |
| --- | --- | --- |
| `honeypot-signals.protocol` | `auto` | `auto`, `ssh`, `dtk`, `http`, or `metadata`. An explicit protocol selects the check for the chosen open TCP ports. |
| `honeypot-signals.timeout` | `3000` | Integer timeout in milliseconds, from `100` to `30000`. |
| `honeypot-signals.verbose` | `false` | Also report checks with no findings or incomplete observations. |

In `auto` mode, checks apply to supported open TCP services: SSH on ports 22/2222 or identified as SSH, the DTK declaration on port 365, HTTP services selected by Nmap's HTTP service rule, and relevant recognized service metadata. Use an explicit protocol for a service on a custom port.

### Network behavior

- **SSH and DTK:** receive a service banner, with a maximum of 4096 bytes retained and an absolute deadline covering connection and banner reading; perform no authentication. The default deadline is 3000 milliseconds.
- **HTTP:** issue one logical `OPTIONS /` request through Nmap's HTTP library, with a 4096-byte response-body limit, without redirects or authentication. The library may retry plain/TLS transport; the configured timeout applies per socket operation rather than as a single overall HTTP deadline.
- **Metadata:** inspect service information already provided by Nmap; perform no additional application request.

The script uses the NSE `safe` and `discovery` categories. The limits above describe this script's application checks, not other scan phases or scripts selected by the user.

The HTTP body limit is not a bound on the complete HTTP response or total network traffic.

## Understanding results

| `assessment` | Interpretation |
| --- | --- |
| `honeypot_indicated` | A supported declaration, response profile, or honeypot identification in probed Nmap metadata was observed. A legitimate service can reproduce the same evidence. |
| `weak_signal_only` | Only a shared or ambiguous indicator was observed. In particular, an SSH banner alone cannot identify Cowrie. |
| `no_known_signal` | The completed check found none of this prototype's known signals. This does not establish that the service is genuine. |
| `inconclusive` | The check did not provide enough usable evidence for a completed assessment. |

Findings contain `id`, `kind`, `evidence`, `caveat`, and `source`. There is no probability or aggregate score: the available evidence does not support a calibrated probability that a host is a honeypot.

By default, checks without findings produce no script output. Set `honeypot-signals.verbose=true` to see no-match and incomplete results for selected services. This option does not widen service selection, and missing output does not establish the absence of a honeypot.

### Supported evidence in v0.1

| Evidence | Scope and limitations |
| --- | --- |
| DTK declaration | Match `The Deception ToolKit is running on this system`. Port 365 alone is insufficient, and the declaration can be copied. See the [DTK FAQ](https://all.net/dtk/faq.html) and [project description](https://all.net/dtk/). |
| Cowrie configuration banners | The pinned configurations use `OpenSSH_6.0p1 Debian-4+deb7u2` and `OpenSSH_9.2p1 Debian-2+deb12u3`. Genuine OpenSSH services can use these strings, so these are weak signals. See the [legacy configuration](https://github.com/cowrie/cowrie/blob/000116838246ce522b1f6953c6f108a3a4f0611c/etc/cowrie.cfg.dist) and [newer configuration](https://github.com/cowrie/cowrie/blob/c7773f49758bc021c8276924f05b5c58dc20d542/src/cowrie/data/etc/cowrie.cfg.dist). |
| Probed Nmap metadata | Recognize supported honeypot names in service/product information generated by Nmap's version probes. This is evidence from Nmap's classifier, rather than an independent confirmation. |
| Legacy Dionaea HTTP profile | Match a historical combination of an HTTP/1.0 `OPTIONS` response and headers. The reference is [Dionaea source from 2014](https://github.com/DinoTools/dionaea/blob/f47b24cefbf07f1ada7bad9952059f85830b84e6/modules/python/scripts/http.py). This is not a claim about current Dionaea defaults. |

An unmatched or modified honeypot can return `no_known_signal`. A camouflaged production service can return `honeypot_indicated`. Preserve that distinction when using results in inventories or research datasets.

The `dionaea-http-options-legacy` rule requires HTTP/1.0 status 200, an empty body, and exactly three headers: `Allow: OPTIONS, GET, HEAD, POST`, `Content-Length: 0`, and `Connection: close`. It accepts header-name case and header-order variation after HTTP parsing. Extra headers or changed values do not match. This normalized `OPTIONS /` rule differs from the independent raw-response signature associated with `SIPOptions` in [Nmap's service-probe database](https://svn.nmap.org/nmap/nmap-service-probes); a result from one does not automatically establish a result from the other.

## Local camouflage lab

The fixture binds to `127.0.0.1`. Start one profile, then scan it from a second terminal:

```sh
python3 examples/camouflage_lab.py --profile dionaea-legacy --port 8081
```

```sh
nmap -sT -Pn -n -p8081 --script ./honeypot-signals.nse \
  --script-args honeypot-signals.protocol=http,honeypot-signals.verbose=true \
  127.0.0.1
```

Available profiles are `normal`, `dionaea-legacy`, `dtk`, `cowrie-legacy`, and `cowrie-current`. Match the selected protocol to the fixture: `http` for `normal` and `dionaea-legacy`, `dtk` for `dtk`, and `ssh` for either Cowrie profile. A fixture reproduces a response; it is not a deployment of the corresponding honeypot software.

## Development and validation

```sh
lua tests/test_nse.lua
python3 tests/integration.py --nmap /path/to/nmap
```

These commands are the intended unit and localhost integration checks. Record the actual tool versions and results when running them. The research evaluation is separate from these implementation checks.

For a new signature, provide a pinned primary source, its version scope, a reproducible positive example, and plausible legitimate collisions. Include cases where the expected evidence is missing or contradictory. Keep findings explainable and distinguish ordinary false positives from deliberate camouflage.

## Prior work

Defensive systems presenting honeypot signals have substantial prior art. DTK explicitly described its port-365 declaration as a possible deterrent. **“Fake Honeypots: A Defensive Tactic for Cyberspace”**, Neil C. Rowe, Binh T. Duong, and E. John Custy (2006), discusses this exact strategy; its initial Internet observations do not isolate causation. [Author full text](https://faculty.nps.edu/ncrowe/fakehoney.htm), DOI: [10.1109/IAW.2006.1652099](https://doi.org/10.1109/IAW.2006.1652099).

The contribution intended here is reproducible NSE tooling and careful evaluation of attacker decisions. Camouflage recipes and the detector's limitations are documented openly.

## License

BSD 2-Clause; see [LICENSE](LICENSE). This license applies to this repository's code. Nmap and its dependencies are required separately, are not bundled here, and retain their own licenses. References to Nmap and honeypot projects identify the evidence sources and do not imply endorsement or official inclusion in Nmap.
