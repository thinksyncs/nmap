# honeypot-signals

[English](README.md)

実測結果は [VALIDATION.md](VALIDATION.md) に記録しています。Luaテスト12群、実Nmapの統合検証6ケース、および標準Nmapへの誤認誘導を確認しました。

Nmap Scripting Engine（NSE）用の、単一ファイルで動作する Lua スクリプトです。**ハニーポットに関連する観測可能な特徴**を報告します。v0.1 は研究用プロトタイプで、BSD 2-Clause ライセンスで公開する構成です。

## 目的

正規のサービスにハニーポットと共通する特徴を持たせ、攻撃者が「罠かもしれない」と判断して次の攻撃を避ける可能性を調べます。検出器は実際に観測した根拠を出力し、付属のローカル用サンプルで一部の特徴を再現できます。

検出規則はソースで公開し、出力には観測根拠と限界を付けます。意図的に変えるのはサービスの応答です。

「特徴に一致した」「攻撃者が利用した」「攻撃者が撤退した」「攻撃が減った」は別々の検証事項です。このプロトタイプだけで抑止効果が実証されたことにはなりません。評価計画は [EVALUATION.md](EVALUATION.md) を参照してください。

## 実行

このディレクトリで、自分が管理するか、調査の許可があるホストを指定します。

```sh
nmap -sT -Pn -n -p22,80,443,365,2222,8081 --script ./honeypot-signals.nse <authorized-host>
```

HTTP を明示し、診断情報を含める場合:

```sh
nmap -sT -Pn -n -p8081 --script ./honeypot-signals.nse \
  --script-args honeypot-signals.protocol=http,honeypot-signals.verbose=true \
  <authorized-host>
```

`-sV` を追加すると、Nmap のサービス検出結果も利用できます。ただし、その場合は Nmap 自体による追加のバージョン検出プローブも送信されます。

### 引数

| 引数 | 既定値 | 内容 |
| --- | --- | --- |
| `honeypot-signals.protocol` | `auto` | `auto` / `ssh` / `dtk` / `http` / `metadata`。明示した場合、選択した open 状態の TCP ポートにその検査を適用します。 |
| `honeypot-signals.timeout` | `3000` | タイムアウト。単位はミリ秒、`100` から `30000` の整数。 |
| `honeypot-signals.verbose` | `false` | 一致する特徴がない検査や、情報不足の検査も出力します。 |

`auto` は対応する open 状態の TCP サービスを検査します。対象は SSH の 22/2222 番または SSH と判別されたポート、DTK 宣言の 365 番、Nmap の HTTP 判定に該当するサービス、関連するサービス識別情報です。独自のポート番号ではプロトコルを明示してください。

### 通信内容

- **SSH / DTK:** 接続開始からバナー受信までを合わせた時間上限を設定し、最大 4096 バイトを保持します。既定の時間上限は 3000 ミリ秒です。認証は行いません。
- **HTTP:** Nmap の HTTP ライブラリで `OPTIONS /` を論理的に 1 回送信します。レスポンス本文の上限は 4096 バイトで、リダイレクト追従と認証は行いません。ライブラリが平文/TLS の接続を再試行する場合があります。タイムアウトはソケット操作ごとの上限で、HTTP 検査全体の時間上限ではありません。
- **metadata:** Nmap が既に取得したサービス情報を参照し、アプリケーションへの追加要求は送りません。

NSE カテゴリは `safe` と `discovery` です。上記の通信内容はこのスクリプトの検査を示しており、Nmap の他の検査段階や同時指定したスクリプトの通信は別です。

HTTP 本文の上限は、HTTP 応答全体や総通信量の上限ではありません。

## 結果の読み方

| `assessment` | 意味 |
| --- | --- |
| `honeypot_indicated` | 対応する宣言、応答パターン、または Nmap のプローブによるハニーポット識別情報を観測しました。正規サービスでも同じ特徴を再現できます。 |
| `weak_signal_only` | 他の実装と共通する、弱い特徴だけを観測しました。SSH バナー単独では Cowrie を特定できません。 |
| `no_known_signal` | 完了した検査では既知の特徴に一致しませんでした。正規サービスであることの証明にはなりません。 |
| `inconclusive` | 検査の判定を完了するための情報が十分に得られませんでした。 |

各 finding は `id`、`kind`、`evidence`、`caveat`、`source` を持ちます。確率や合計スコアは出しません。現在の根拠から、対象がハニーポットである確率を較正することはできないためです。

既定では、一致する特徴がない検査は出力を省略します。`honeypot-signals.verbose=true` で、検査対象サービスの不一致・情報不足の結果も表示できます。この指定は検査対象を増やすものではなく、出力がないこともハニーポットの不在を証明しません。

### v0.1 の対応範囲

| 特徴 | 扱いと限界 |
| --- | --- |
| DTK 宣言 | `The Deception ToolKit is running on this system` と照合します。365 番ポートが開いているだけでは判定しません。宣言自体も複製可能です。[DTK FAQ](https://all.net/dtk/faq.html) / [プロジェクトの説明](https://all.net/dtk/) |
| Cowrie の設定上のバナー | 固定した版の設定にある `OpenSSH_6.0p1 Debian-4+deb7u2` と `OpenSSH_9.2p1 Debian-2+deb12u3` を弱い特徴として扱います。実際の OpenSSH と一致し得ます。[旧設定](https://github.com/cowrie/cowrie/blob/000116838246ce522b1f6953c6f108a3a4f0611c/etc/cowrie.cfg.dist) / [新しい設定](https://github.com/cowrie/cowrie/blob/c7773f49758bc021c8276924f05b5c58dc20d542/src/cowrie/data/etc/cowrie.cfg.dist) |
| Nmap のプローブによる識別情報 | 対応するハニーポット名をサービス・製品情報から調べます。Nmap の既存の判定を根拠にした結果であり、独立した再確認ではありません。 |
| 過去の Dionaea HTTP 応答 | HTTP/1.0 の `OPTIONS` 応答と複数ヘッダの組み合わせを照合します。[2014 年のソース](https://github.com/DinoTools/dionaea/blob/f47b24cefbf07f1ada7bad9952059f85830b84e6/modules/python/scripts/http.py)を対象とし、現在の既定設定に該当するとは主張しません。 |

変更済み・未対応のハニーポットは `no_known_signal` になり得ます。逆に、特徴を再現した正規サービスは `honeypot_indicated` になり得ます。資産台帳や研究用データに転記するときも、この区別を保持してください。

`dionaea-http-options-legacy` は、HTTP/1.0 のステータス 200、空の本文、`Allow: OPTIONS, GET, HEAD, POST`、`Content-Length: 0`、`Connection: close` の 3 ヘッダだけを要求します。HTTP 解析後に照合するため、ヘッダ名の大文字・小文字やヘッダの順序が異なっても一致します。余分なヘッダや値の変更は一致しません。この `OPTIONS /` の正規化後の規則は、[Nmap のサービス検出データベース](https://svn.nmap.org/nmap/nmap-service-probes)にある `SIPOptions` プローブ用の生の応答パターンとは異なり、一方の結果から他方の結果は断定できません。

## ローカルで特徴を再現する

サンプルは `127.0.0.1` に固定して待ち受けます。片方のターミナルで起動し、別のターミナルで検査します。

```sh
python3 examples/camouflage_lab.py --profile dionaea-legacy --port 8081
```

```sh
nmap -sT -Pn -n -p8081 --script ./honeypot-signals.nse \
  --script-args honeypot-signals.protocol=http,honeypot-signals.verbose=true \
  127.0.0.1
```

プロファイルは `normal`、`dionaea-legacy`、`dtk`、`cowrie-legacy`、`cowrie-current` です。`normal` と `dionaea-legacy` は `http`、`dtk` は `dtk`、Cowrie の 2 種類は `ssh` を指定します。これは応答の再現用サンプルであり、各ハニーポットソフトウェアを導入した環境ではありません。

## 開発・検証

```sh
lua tests/test_nse.lua
python3 tests/integration.py --nmap /path/to/nmap
```

上記は単体検査とローカルでの結合検査の実行方法です。実行時のバージョンと実際の結果を記録してください。検出器が動作することと、攻撃者への抑止効果があることは別に評価します。

シグネチャを追加する場合は、版を固定した一次資料、対応範囲、再現可能な陽性例、正規サービスとの衝突例を示してください。根拠の欠落や矛盾も検証し、通常の誤検出率と意図した擬装の成功率を分けて報告します。

## 先行研究と公開方針

正規システムをハニーポットらしく見せる考え方には先行例があります。DTK は 365 番ポートの宣言を抑止に使う案を記述しています。また、Neil C. Rowe、Binh T. Duong、E. John Custy の **“Fake Honeypots: A Defensive Tactic for Cyberspace”**（2006）は、この方法を直接扱っています。同論文の初期観測だけで因果効果が確定したとはいえません。[著者公開全文](https://faculty.nps.edu/ncrowe/fakehoney.htm)、DOI: [10.1109/IAW.2006.1652099](https://doi.org/10.1109/IAW.2006.1652099)。

本プロジェクトは、NSE による再現可能な検査と、攻撃者の判断を含む評価を目指します。検出根拠・擬装方法・限界を明記して配布します。

## ライセンス

BSD 2-Clause。[LICENSE](LICENSE) を参照してください。このライセンスは本リポジトリのコードに適用します。Nmap とその依存関係は別途必要で、同梱せず、それぞれのライセンスに従います。Nmap や各ハニーポットの名称は根拠となる実装を示しており、公式採用や推奨を意味しません。
