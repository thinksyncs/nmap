# Evaluation plan

This document separates implementation correctness, fingerprint reliability, and defensive effect. They answer different questions and need different evidence.

## 1. Claims and evidence levels

| Claim | Suitable evidence | Insufficient evidence |
| --- | --- | --- |
| The NSE script works as specified. | Unit checks and localhost integration runs, recording versions and outputs. | Reading the script alone. |
| A response matches a supported fingerprint. | A pinned implementation/configuration source and reproducible response matching. | A port number or a generic software name alone. |
| A fingerprint is useful for classifying real deployments. | A labeled, version-diverse evaluation set with legitimate collision cases. | A self-authored fixture that reproduces the signature. |
| Camouflage induces the detector's signal. | The same legitimate service with camouflage off/on, holding application behavior fixed. | A genuine honeypot producing the signal. |
| A signal changes attacker decisions. | A controlled task recording evidence exposure and subsequent attacker choices. | A detector printing `honeypot_indicated`. |
| Publishing the project reduces attacks in practice. | Adoption evidence and matched field observations of subsequent attack behavior. | Downloads, stars, scan counts, or a lab bot programmed to skip every positive. |

The local fixture is primarily for reproducibility and implementation checks. It is not a representative labeled deployment dataset, and it does not establish deterrence.

## 2. Implementation validation

Run and record:

```sh
lua tests/test_nse.lua
python3 tests/integration.py --nmap /path/to/nmap
```

Record the script revision, Nmap version, Lua version, operating system, commands, exit status, and actual assertions checked. Do not describe planned or inferred checks as passing checks.

The test inventory should cover:

- Valid and invalid protocol, timeout, and verbose arguments.
- Supported positive profiles and ordinary negative responses.
- Realistic OpenSSH banner collisions remaining weak signals.
- Missing, changed, or contradictory HTTP header evidence.
- Unavailable, incomplete, oversized, delayed, or malformed responses.
- Open TCP selection and custom-port protocol overrides.
- Output evidence, caveats, and sources; no invented probability.
- Bounded banner reads and the absence of HTTP redirects or authentication.

Implementation results should state what was actually tested. An independently installed Nmap returning a similar service identification, if checked, is a separate result and should include its version and output.

### Normalized NSE profile versus independent Nmap identification

The `dionaea-http-options-legacy` check sends `OPTIONS /` and inspects a parsed HTTP response. It requires HTTP/1.0 status 200, an empty body, and exactly the `Allow`, `Content-Length`, and `Connection` headers with the values in the script. It tolerates header-name case and header-order variation, while rejecting additional headers and changed values.

Nmap's independent Dionaea identification uses a specific raw response associated with its `SIPOptions` probe in the [service-probe database](https://svn.nmap.org/nmap/nmap-service-probes). It is a different test. To check it against the running local fixture without this NSE script:

```sh
nmap -sT -Pn -n -sV -p8081 127.0.0.1
```

Record its actual output alongside a normal-profile control and normal application requests. Do not infer that this independent match succeeds merely because the NSE profile matches. Conversely, a result reported through `nmap-version-honeypot` is a reuse of Nmap metadata, not another independent classifier decision.

## 3. Three populations, three different metrics

Keep these evaluation populations distinct:

1. **Known genuine honeypots:** deployments with independently verified software, version, and configuration.
2. **Ordinary legitimate services:** unmodified services whose role and implementation are known independently.
3. **Deliberately camouflaged legitimate services:** legitimate services configured to reproduce a documented signal.

Report separately:

| Metric | Denominator |
| --- | --- |
| Genuine-honeypot signal rate | All eligible known honeypot deployments, with inconclusive outcomes reported separately. |
| Ordinary false-positive rate | All eligible unmodified legitimate deployments. |
| Deliberate camouflage signal rate | All eligible camouflaged legitimate deployments. |
| Inconclusive rate | All attempted checks in each population. |

For each metric, distinguish `honeypot_indicated` from `weak_signal_only`. Specify whether a downstream policy uses either outcome as a positive. Do not silently exclude inconclusive cases to inflate performance.

Deliberate camouflage may correctly cause a fingerprint match while causing an incorrect inference about the host's role. Calling it an ordinary classifier error without identifying the intervention hides the experiment's objective. Conversely, mixing it with ordinary services makes the reported false-positive rate hard to interpret.

Use pinned but diverse versions and nondefault configurations. A Cowrie banner duplicated by real OpenSSH is a required collision case. A legacy Dionaea signature must be evaluated as a legacy signature, not as coverage of today's entire Dionaea population. Exclude fixture-derived examples from claims about generalization, or report them separately.

## 4. Attacker-decision experiment

The causal sequence is:

**detector adoption → signal exposure → belief about the target → skip/continue decision → subsequent attack outcome.**

Initially use an authorized red-team exercise with independent participants and a factorial design:

| Service presentation | Detector unavailable | Detector available |
| --- | --- | --- |
| Ordinary | Baseline decisions | Effect of providing the tool on ordinary targets |
| Camouflaged | Effect of the visible signal without the supplied tool | Intended combined intervention |

Include genuine honeypots among the exercise's reference targets so detecting a trap has a real task consequence. Keep exploitability, content value, credentials, service health, and time budget matched across ordinary and camouflaged legitimate targets. Randomize assignment and avoid telling participants that a positive result must be skipped.

Measure at least:

- Whether the participant actually ran the detector or an equivalent test.
- Whether and when the participant received the marker evidence.
- The next action: abandon, verify further, continue, or select another target.
- Exploitation attempts after marker exposure and progression to later attack stages.
- Time spent verifying and the final task outcome.
- Normal client compatibility and operational overhead.

Report intention-to-treat results for detector availability. Analyses restricted to people who chose to use the tool are useful but selected: tool users may differ before the intervention. If the tool's causal effect among users is central, use a separate randomized tool-exposure task.

Separate human decisions, automated workflows with honeypot-skip logic, and automation without that logic. A script configured to skip on a match demonstrates the workflow's mechanics, not the prevalence of that behavior among attackers.

Run a second phase after disclosing that legitimate targets can imitate the signals. Use independent participant groups where possible to avoid learning contaminating the first phase. This tests whether uncertainty remains useful after the camouflage technique becomes known.

## 5. Field evaluation, if separately undertaken

Use authorized observation infrastructure, not production compromise as an outcome-generating method. Randomly assign matched instances to ordinary and camouflaged presentations, keeping provider, region, exposure, service version, and uptime comparable. Observe treatments concurrently rather than comparing only an early period with a later one.

Choose persistent assignments or explicitly account for carryover: an IP address previously marked as a honeypot can remain on a scanner's exclusion list after its presentation changes. Switching one address repeatedly does not reset attacker beliefs.

Predefine the primary outcome as an attack action after the relevant signal could have been observed. Initial SYNs and reconnaissance requests can remain unchanged because they are needed to discover the signal. Report both the number of eligible encounters and later attempts.

An IP address is not necessarily an attacker identity. Account for repeated sessions, shared infrastructure, botnets, and time-correlated campaigns rather than treating packets as independent observations. Distinguish known research scans where evidence permits, and report uncertainty where actor attribution is unavailable.

A decrease in traffic alone cannot establish that attackers recognized a honeypot. Useful corroboration includes an observed detection request followed by stopping, a changed tool policy, or a controlled replication. State alternative explanations, including outages, service incompatibility, address reputation, and changing background traffic.

## 6. Adoption and adaptation

Public source code does not automatically reveal whether an individual matching host is a trap. However, the signal's meaning can change as genuine honeypots change configuration and legitimate operators copy the marker.

For illustration, let `pi` be honeypot prevalence, `alpha` the signal rate among genuine honeypots, and `beta` the signal rate among legitimate targets. Under these assumptions:

```text
P(honeypot | signal) = pi * alpha / (pi * alpha + (1 - pi) * beta)
```

This is an explanatory model, not a probability estimate produced by the tool. More camouflage can raise `beta` and reduce an informed attacker's belief that a match is a real trap. A signal appearing only in the camouflage implementation can be particularly uninformative after disclosure.

At the same time, wider detector adoption can expose more attackers to the signal. Record these effects separately. An attacker protecting a valuable technique may react differently from one using a disposable exploit or pursuing a uniquely valuable target. Avoid claiming either universal protection or universal failure from a single assumed attacker payoff.

## 7. Prior evidence and its limits

- **Fake Honeypots: A Defensive Tactic for Cyberspace.** Neil C. Rowe, Binh T. Duong, E. John Custy (2006). DOI: [10.1109/IAW.2006.1652099](https://doi.org/10.1109/IAW.2006.1652099). [Author full text](https://faculty.nps.edu/ncrowe/fakehoney.htm). Direct prior art for making normal systems resemble honeypots. The 42-day experiment found declining alert categories as honeypots became more conspicuous, but the authors explicitly acknowledge a possible site-age explanation. It does not isolate a causal deterrence effect.
- **The Art of False Alarms in the Game of Deception: Leveraging Fake Honeypots for Enhanced Security.** Apostolis Zarras (2014). DOI: [10.1109/CCST.2014.6987017](https://doi.org/10.1109/CCST.2014.6987017). [University publication record](https://www.sec.in.tum.de/i20/publications/the-art-of-false-alarms-in-the-game-of-deception-leveraging-fake-honeypots-for-enhanced-security). SCARECROW induced anti-analysis responses in malicious websites. This supports the mechanism in a browser-client setting; it does not establish Nmap-based server deterrence.
- **Picky Attackers: Quantifying the Role of System Properties on Intruder Behavior.** Timothy Barron, Nick Nikiforakis (2017). DOI: [10.1145/3134600.3134614](https://doi.org/10.1145/3134600.3134614). [Author full text](https://www.securitee.org/files/pickyattackers_acsac2017.pdf). A four-month study of 102 honeypots found differences between observed human and bot responses to system properties. This motivates separating attacker behaviors in the evaluation.
- **Towards bio-inspired cyber-deception: a case study of SSH and Telnet honeypots.** Anastasia Safargalieva, Emmanouil Vasilomanolakis (2025). DOI: [10.1109/EuroSPW67616.2025.00079](https://doi.org/10.1109/EuroSPW67616.2025.00079). [University publication record](https://orbit.dtu.dk/en/publications/towards-bio-inspired-cyber-deception-a-case-study-of-ssh-and-teln/). The evaluated modifications increased SSH engagement while Telnet attackers left faster. This is evidence that the effect depends on the service and intervention, not a direct evaluation of this prototype.

## 8. Reporting checklist

A release or study report should give the tested revision, signature sources and version scope, population definitions, raw outcome counts, handling of inconclusive results, and observed implementation results. Report detector behavior and attacker behavior in separate sections. Publish camouflage recipes and collision cases alongside positive examples. Describe unmeasured adoption or defensive outcomes as open questions.
