-- SPDX-License-Identifier: BSD-2-Clause
local http = require "http"
local nmap = require "nmap"
local shortport = require "shortport"
local stdnse = require "stdnse"

description = [[
Reports documented honeypot-associated responses and existing Nmap version
matches. Its research purpose is to measure when legitimate services can imitate
these responses. Findings are spoofable observations, not proof of a honeypot.

The initial profiles cover a legacy Dionaea HTTP OPTIONS response, the DTK
announcement, two non-exclusive Cowrie SSH banner defaults, and explicit
honeypot matches already obtained by Nmap service detection. No credentials or
exploit payloads are sent. HTTP probing sends one logical OPTIONS request;
Nmap's HTTP library may retry plain/TLS transport. No redirects are followed.
See README.md for profile versions, sources, limits, and reproducible examples.
]]

---
-- @usage
-- nmap -sT -Pn -n -p 22,80,443,365,2222,8081 --script ./honeypot-signals.nse TARGET
-- nmap -sT -Pn -n -sV -p 8081 --script ./honeypot-signals.nse TARGET
-- nmap -sT -Pn -n -p 18081 --script ./honeypot-signals.nse \
--   --script-args honeypot-signals.protocol=http,honeypot-signals.verbose=true TARGET
-- @args honeypot-signals.protocol auto (default), ssh, dtk, http, or metadata.
--       An explicit protocol applies to each selected open TCP port.
-- @args honeypot-signals.timeout Socket/deadline timeout in milliseconds,
--       integer 100..30000; default 3000. The HTTP limit is per socket operation.
-- @args honeypot-signals.verbose Also report no-match and incomplete observations.
--       Default false. Incomplete results never establish the absence of a honeypot.
-- @output
-- | honeypot-signals:
-- |   schema_version: 1
-- |   assessment: honeypot_indicated
-- |   findings:
-- |     1:
-- |       id: dionaea-http-options-legacy
-- |       kind: profile_match
-- |       caveat: Historical response profile; any server can reproduce it.
-- |_  interpretation: Observed signals only; server identity and deterrence are unverified.

author = "Honeypot Signals contributors"
license = "BSD-2-Clause; see the accompanying LICENSE"
categories = {"discovery", "safe"}

local ARG = "honeypot-signals."
local MAX_GREETING = 4096
local SOURCE = {
  dtk = "https://all.net/dtk/faq.html",
  cowrie_legacy = "https://github.com/cowrie/cowrie/blob/000116838246ce522b1f6953c6f108a3a4f0611c/etc/cowrie.cfg.dist",
  cowrie_current = "https://github.com/cowrie/cowrie/blob/c7773f49758bc021c8276924f05b5c58dc20d542/src/cowrie/data/etc/cowrie.cfg.dist",
  dionaea = "https://github.com/DinoTools/dionaea/blob/f47b24cefbf07f1ada7bad9952059f85830b84e6/modules/python/scripts/http.py",
  nmap = "https://nmap.org/book/nse-api.html",
}

local function printable(value)
  local text = tostring(value or "")
  local clipped = text:sub(1, 240)
  clipped = clipped:gsub("[^ -~]", function(c)
    return ("\\x%02X"):format(c:byte())
  end)
  return clipped .. (#text > 240 and "..." or "")
end

local function configuration()
  local protocol = stdnse.get_script_args(ARG .. "protocol") or "auto"
  local allowed = {auto=true, ssh=true, dtk=true, http=true, metadata=true}
  if type(protocol) ~= "string" or not allowed[protocol] then
    return nil, "protocol must be auto, ssh, dtk, http, or metadata"
  end
  local timeout = tonumber(stdnse.get_script_args(ARG .. "timeout") or 3000)
  if not timeout or timeout ~= math.floor(timeout) or timeout < 100 or timeout > 30000 then
    return nil, "timeout must be an integer from 100 to 30000 milliseconds"
  end
  local verbose = stdnse.get_script_args(ARG .. "verbose")
  if verbose ~= nil and verbose ~= true and verbose ~= false
    and verbose ~= "true" and verbose ~= "false" and verbose ~= "1" and verbose ~= "0" then
    return nil, "verbose must be true or false"
  end
  return {protocol=protocol, timeout=timeout,
          verbose=(verbose == true or verbose == "true" or verbose == "1")}
end

local function upstream_honeypot(port)
  local version = port.version or {}
  if version.service_dtype ~= "probed" then return false end
  local name = tostring(version.name or ""):lower()
  local product = tostring(version.product or ""):lower()
  return name == "honeypot" or product:find("honeypot", 1, true) ~= nil
end

local function protocol_for(host, port, configured)
  if configured ~= "auto" then return configured end
  local name = tostring((port.version or {}).name or port.service or ""):lower()
  if name == "ssh" or port.number == 22 or port.number == 2222 then return "ssh" end
  if port.number == 365 then return "dtk" end
  if shortport.http(host, port) then return "http" end
  if upstream_honeypot(port) then return "metadata" end
  return nil
end

portrule = function(host, port)
  if port.protocol ~= "tcp" or port.state ~= "open" then return false end
  local config = configuration()
  -- Invalid arguments must be reported rather than silently suppressing a scan.
  return not config or protocol_for(host, port, config.protocol) ~= nil
end

local function add_finding(findings, id, kind, evidence, caveat, source)
  local finding = stdnse.output_table()
  finding.id, finding.kind = id, kind
  finding.evidence, finding.caveat, finding.source = evidence, caveat, source
  findings[#findings + 1] = finding
end

local function read_greeting(host, port, protocol, timeout)
  local socket = nmap.new_socket()
  local deadline = nmap.clock_ms() + timeout
  socket:set_timeout(timeout)
  local connected = socket:connect(host, port, "tcp")
  if not connected then
    socket:close()
    return nil, "connect_failed"
  end
  local bytes = ""
  local function finish(line, status)
    socket:close()
    return line, status
  end
  while #bytes < MAX_GREETING do
    local remaining = deadline - nmap.clock_ms()
    if remaining <= 0 then return finish(nil, "timeout") end
    socket:set_timeout(remaining)
    local ok, chunk = socket:receive_bytes(1)
    if not ok then
      -- A DTK notification may end at EOF without a trailing newline.
      if protocol == "dtk" and chunk == "EOF" and #bytes > 0 then
        return finish(bytes:gsub("\r$", ""), "complete")
      end
      return finish(nil, chunk == "TIMEOUT" and "timeout" or "incomplete")
    end
    if type(chunk) ~= "string" or #chunk == 0 then return finish(nil, "incomplete") end
    local capacity = MAX_GREETING - #bytes
    bytes = bytes .. chunk:sub(1, capacity)
    -- SSH permits informational lines before the identification line.
    for line in bytes:gmatch("([^\n]*)\n") do
      line = line:gsub("\r$", "")
      if protocol == "dtk" or line:sub(1, 4) == "SSH-" then
        return finish(line, "complete")
      end
    end
    if #chunk > capacity then return finish(nil, "size_limit") end
  end
  return finish(nil, "size_limit")
end

local function inspect_greeting(line, protocol, findings)
  if protocol == "dtk" then
    if line == "The Deception ToolKit is running on this system" then
      add_finding(findings, "dtk-announcement", "self_announcement", printable(line),
        "A declaration of deception; it does not prove that DTK is installed.", SOURCE.dtk)
    end
    return
  end
  local profiles = {
    ["SSH-2.0-OpenSSH_6.0p1 Debian-4+deb7u2"] = {"cowrie-default-v2.5.0", SOURCE.cowrie_legacy},
    ["SSH-2.0-OpenSSH_9.2p1 Debian-2+deb12u3"] = {"cowrie-default-2026-10-15", SOURCE.cowrie_current},
  }
  local profile = profiles[line]
  if profile then
    add_finding(findings, profile[1], "weak_overlap", printable(line),
      "Configurable Cowrie default; genuine OpenSSH can present the same banner. Not a Cowrie identification.", profile[2])
  end
end

local function dionaea_legacy_options(response)
  if response.status ~= 200 or response.version ~= "1.0" or response.truncated then return false end
  local header = response.header or {}
  local expected = {allow="OPTIONS, GET, HEAD, POST", ["content-length"]="0", connection="close"}
  for key, value in pairs(expected) do
    if header[key] ~= value then return false end
  end
  -- Extra headers are evidence of a different response profile. Do not broaden
  -- this to an Apache/nginx name or the Allow header alone.
  for key in pairs(header) do
    if expected[key] == nil then return false end
  end
  return response.body == ""
end

action = function(host, port)
  local config, err = configuration()
  if not config then return stdnse.format_output(false, err) end
  local protocol = protocol_for(host, port, config.protocol)
  if not protocol then return nil end
  local findings, probes = {}, {}
  if upstream_honeypot(port) then
    local version = port.version
    add_finding(findings, "nmap-version-honeypot", "upstream_match",
      "service=" .. printable(version.name) .. "; product=" .. printable(version.product),
      "Existing Nmap service-detection match; spoofable and dependent on the installed fingerprint database.", SOURCE.nmap)
  end
  local complete = false
  if protocol == "ssh" or protocol == "dtk" then
    local line, status = read_greeting(host, port, protocol, config.timeout)
    probes[#probes + 1] = protocol .. " greeting: " .. status
    complete = status == "complete"
    if line then inspect_greeting(line, protocol, findings) end
  elseif protocol == "http" then
    local response = http.generic_request(host, port, "OPTIONS", "/", {
      timeout=config.timeout, redirect_ok=false, max_body_size=4096,
      truncated_ok=false, bypass_cache=true, no_cache=true,
      header={["Accept-Encoding"]="identity", Connection="close"},
    })
    complete = type(response) == "table" and response.status ~= nil
      and not response.truncated and not response.incomplete
    probes[#probes + 1] = "HTTP OPTIONS /: " .. (complete and "complete" or "incomplete")
    if complete and dionaea_legacy_options(response) then
      add_finding(findings, "dionaea-http-options-legacy", "profile_match",
        "HTTP/1.0 200; Allow=OPTIONS, GET, HEAD, POST; Content-Length=0; Connection=close; no other headers or body",
        "Historical 2014 response profile, not the current Dionaea default; any server can reproduce it.", SOURCE.dionaea)
    end
  else
    local version = port.version or {}
    complete = version.service_dtype == "probed"
    probes[#probes + 1] = "Nmap version metadata: " .. (complete and "available" or "unavailable (use -sV)")
  end
  if #findings == 0 and not config.verbose then return nil end
  local assessment = complete and "no_known_signal" or "inconclusive"
  for _, finding in ipairs(findings) do
    if finding.kind == "weak_overlap" then
      if assessment ~= "honeypot_indicated" then assessment = "weak_signal_only" end
    else
      assessment = "honeypot_indicated"
    end
  end
  local output = stdnse.output_table()
  output.schema_version = "1"
  output.assessment = assessment
  output.findings = findings
  output.probes = probes
  output.interpretation = "Observed signals only; server identity and deterrence are unverified. No match does not rule out a honeypot."
  return output
end
