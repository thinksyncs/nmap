#!/usr/bin/env python3
"""Local-only response fixtures, including an ordinary HTTP service with camouflage.

The HTTP fixture serves / and /health. Its optional OPTIONS response reproduces
the historical 2014 Dionaea profile. Other profiles are greeting-only fixtures,
not running honeypot distributions or complete SSH implementations.
"""
# SPDX-License-Identifier: BSD-2-Clause

import argparse
import socketserver


PROFILES = ("normal", "dionaea-legacy", "dtk", "cowrie-legacy", "cowrie-current")
GREETINGS = {
    "dtk": b"The Deception ToolKit is running on this system\r\n",
    "cowrie-legacy": b"SSH-2.0-OpenSSH_6.0p1 Debian-4+deb7u2\r\n",
    "cowrie-current": b"SSH-2.0-OpenSSH_9.2p1 Debian-2+deb12u3\r\n",
}


def http_response(status, body=b"", *, head=False):
    header = (
        f"HTTP/1.1 {status}\r\n"
        "Content-Type: text/plain; charset=utf-8\r\n"
        f"Content-Length: {len(body)}\r\n"
        "Connection: close\r\n\r\n"
    ).encode("ascii")
    return header + (b"" if head else body)


class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        # Nmap's initial NULL probe treats early close as tcpwrapped. Keep the
        # empty connection alive long enough for subsequent version probes.
        self.request.settimeout(9)
        try:
            self.respond()
        except (TimeoutError, ConnectionError, OSError):
            pass

    def respond(self):
        profile = self.server.profile
        if profile in GREETINGS:
            self.request.sendall(GREETINGS[profile])
            return
        request = bytearray()
        while b"\r\n\r\n" not in request and len(request) < 8192:
            data = self.request.recv(min(1024, 8192 - len(request)))
            if not data:
                return
            request.extend(data)
            self.request.settimeout(1)
            known_methods = (b"GET ", b"HEAD ", b"OPTIONS ", b"POST ", b"PUT ",
                             b"DELETE ", b"PATCH ", b"TRACE ", b"CONNECT ")
            prefix = bytes(request)
            if not any(prefix.startswith(method) or method.startswith(prefix)
                       for method in known_methods):
                return
        if b"\r\n\r\n" not in request:
            return
        line = bytes(request).split(b"\r\n", 1)[0]
        words = line.split()
        if len(words) != 3:
            return
        method, path, version = words
        if profile == "dionaea-legacy" and method == b"OPTIONS":
            # This reproduces the old implementation's OPTIONS dispatch even
            # for SIPOptions. It intentionally ignores the request's version.
            # This is a bounded local fixture, not a production HTTP front end.
            self.request.sendall(
                b"HTTP/1.0 200 OK\r\n"
                b"Allow: OPTIONS, GET, HEAD, POST\r\n"
                b"Content-Length: 0\r\n"
                b"Connection: close\r\n\r\n"
            )
            return
        if version not in (b"HTTP/1.0", b"HTTP/1.1"):
            return
        if method == b"OPTIONS":
            self.request.sendall(
                b"HTTP/1.1 204 No Content\r\n"
                b"Allow: GET, HEAD, OPTIONS\r\n"
                b"Content-Length: 0\r\n"
                b"Connection: close\r\n\r\n"
            )
        elif method in (b"GET", b"HEAD"):
            if path == b"/health":
                status, body = "200 OK", b"ok\n"
            elif path == b"/":
                status, body = "200 OK", b"Example application is running.\n"
            else:
                status, body = "404 Not Found", b"not found\n"
            self.request.sendall(http_response(status, body, head=method == b"HEAD"))
        else:
            self.request.sendall(http_response("405 Method Not Allowed"))


class LabServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
    block_on_close = False

    def __init__(self, profile, port=0):
        if profile not in PROFILES:
            raise ValueError("unknown fixture profile")
        self.profile = profile
        # Fixed IPv4 loopback: importing or running this example cannot expose
        # a deliberately unusual protocol handler to a public interface.
        super().__init__(("127.0.0.1", port), Handler)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=PROFILES, default="normal")
    parser.add_argument("--port", type=int, default=8081)
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error("port must be 0..65535")
    with LabServer(args.profile, args.port) as server:
        print(f"{args.profile}: 127.0.0.1:{server.server_address[1]}", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
