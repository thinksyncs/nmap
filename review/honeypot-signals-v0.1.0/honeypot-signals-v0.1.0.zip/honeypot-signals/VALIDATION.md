# Validation record — 2026-10-17

## What was established

The supplied local HTTP service can continue answering ordinary application
requests while an unmodified Nmap service scan identifies it as a Dionaea
honeypot. The custom NSE is not involved in that independent identification.
This establishes induced fingerprint misclassification for the tested response
and Nmap release. It does not establish that attackers avoid the service.

## Environment

| Component | Tested value |
| --- | --- |
| OS | Ubuntu 24.04, x86-64 |
| Nmap | 7.992, built from the official release archive |
| Lua | 5.4.9, including the standalone interpreter used for unit checks |
| NSE | `honeypot-signals.nse`, this v0.1.0 bundle |
| Targets | Temporary listeners on IPv4 loopback only |

Nmap source: <https://nmap.org/dist/nmap-7.992.tar.bz2>

Official archive SHA-256, verified after download:
`0c12660eddbf7eabeff6996cb0c044a4eadf2bb0c6fbcb340d6cf72b1caee402`

The tested `nmap-service-probes` SHA-256 was
`bd1bc6b1904632c617d6cf70e1f21877f4b0abefc8db977ceaf1699accdde5ff`.
Its bytes also matched the file in the original release archive. The detector
database was not edited to obtain the match. Nmap and its database are not
distributed in this bundle.

## Implementation checks

**12/12 focused Lua test groups passed.** They exercise the NSE's `action` and
`portrule` through mocked library boundaries. Cases cover ordinary SSH,
both Cowrie defaults remaining weak, exact DTK declarations, probed-only version
metadata, output escaping, the historical HTTP profile and negative variants,
partial/time-limited responses, bounded banner reads, argument errors, and
TCP/open-port selection. The tests inspect the HTTP method and library options.

**6/6 real Nmap integration cases passed.**

| Local fixture / mode | Expected and observed assessment |
| --- | --- |
| Normal HTTP / HTTP | `no_known_signal` |
| Historical Dionaea-compatible HTTP / HTTP | `honeypot_indicated` |
| DTK declaration / DTK | `honeypot_indicated` |
| Cowrie legacy greeting / SSH | `weak_signal_only` |
| Cowrie newer greeting / SSH | `weak_signal_only` |
| Normal HTTP / metadata without `-sV` | `inconclusive` |

The integration harness checks `/health` before and after both HTTP cases.
These fixtures do not run full Cowrie, DTK, or Dionaea distributions. Therefore
the pass count is not a real-world honeypot detection-accuracy measurement.

Reproduce from the project directory:

```sh
lua tests/test_nse.lua
python3 tests/integration.py --nmap /path/to/nmap
```

## Independent Nmap result using the supplied fixture

Terminal 1:

```sh
python3 examples/camouflage_lab.py --profile dionaea-legacy --port 8081
```

Terminal 2:

```sh
nmap --unprivileged -sT -Pn -n -sV --version-all -p8081 127.0.0.1
```

Observed service line:

```text
8081/tcp open  honeypot Dionaea Honeypot httpd
```

The trace identifies the `SIPOptions` probe as the hard match, with no earlier
soft match. XML records `name="honeypot"`, `product="Dionaea Honeypot httpd"`,
and `method="probed"`. Its `conf="10"` field is Nmap's service-name confidence,
not a calibrated probability that this host is actually a honeypot.

A separate scan added this project's NSE in `protocol=metadata` mode. It
successfully read the real Nmap `port.version` fields and returned
`nmap-version-honeypot`, `kind=upstream_match`, and `honeypot_indicated`.

After both scans, `GET /` and `GET /health` returned HTTP 200 and their expected
application bodies. The fixture SHA-256 before and after these scans was:
`dfb695260ca1ce22716a4a6f33dc7908daa9fabc9759effd9b7d0e2b9834ccfa`.

Raw evidence is in [validation/](validation/): `stock.nmap`, `stock.xml`,
`metadata.nmap`, `metadata.xml`, and `independent-summary.json`. Trace logs
preserve diagnostics as well as the service match.

### Diagnostics and limits

Both scans exited successfully. The supplied Nmap release's automatically
selected version-category scripts `rpcinfo` and `vmware-version` logged an
error involving `nmap.version_intensity` after the core service fingerprint had
matched. The traces retain those errors. This record establishes core service
detection and this project's NSE results, not error-free execution of every
bundled Nmap script.

The fixture is a small working test HTTP application, not a production server.
In particular, the historical response accepts an OPTIONS method even with a
SIP request version. A normal HTTP frontend may reject that request first, add
headers, or match a different service fingerprint earlier; the same result is
not guaranteed after moving this response behind such a frontend.

Replacing ordinary OPTIONS handling can also change CORS preflight behavior.
The local example is not a production reverse-proxy recipe. A deployment
adaptation needs to preserve the application's actual protocol requirements.

HTTPS transport, full current honeypot deployments, representative legitimate
services, and human/bot attack decisions were not covered by these integration
runs. See [EVALUATION.md](EVALUATION.md) for those separate questions.
