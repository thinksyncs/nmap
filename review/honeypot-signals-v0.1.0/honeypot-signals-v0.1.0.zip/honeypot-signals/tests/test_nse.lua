-- SPDX-License-Identifier: BSD-2-Clause
-- Run from the project root: lua tests/test_nse.lua
-- Exercises NSE entry points with deterministic library-boundary fixtures.
-- It performs no network requests and does not reproduce detector internals.

local script_path = arg[1] or "honeypot-signals.nse"
local host = {ip = "127.0.0.1", targetname = "localhost"}
local default_port = {number = 2222, protocol = "tcp", state = "open", service = "ssh"}
local tests, passed = {}, 0

local function expect(value, message)
  assert(value, message or "expectation failed")
end

local function equal(actual, expected, message)
  assert(actual == expected, (message or "unexpected value") ..
    ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
end

local function add(name, action)
  tests[#tests + 1] = {name = name, action = action}
end

local function config(protocol, verbose)
  return {
    ["honeypot-signals.protocol"] = protocol,
    ["honeypot-signals.verbose"] = verbose == nil and true or verbose,
  }
end

local function load_case(case)
  case = case or {}
  local state = {connects = 0, closes = 0, reads = 0, clocks = 0,
                 timeouts = {}, http_calls = {}}
  local socket = {}
  function socket:set_timeout(milliseconds)
    state.timeouts[#state.timeouts + 1] = milliseconds
  end
  function socket:connect(target, port, transport)
    state.connects = state.connects + 1
    state.target, state.port, state.transport = target, port, transport
    if case.connect_error then return false, case.connect_error end
    return true
  end
  function socket:receive_bytes(minimum)
    equal(minimum, 1, "read should request the next available greeting data")
    state.reads = state.reads + 1
    local reply = (case.reads or {})[state.reads] or {false, "EOF"}
    return table.unpack(reply)
  end
  function socket:send()
    error("greeting inspection must not send credentials or protocol payloads")
  end
  function socket:close()
    state.closes = state.closes + 1
    return true
  end

  local mocks = {
    nmap = {
      new_socket = function() return socket end,
      clock_ms = function()
        state.clocks = state.clocks + 1
        local values = case.clocks or {0}
        return values[math.min(state.clocks, #values)]
      end,
    },
    http = {
      generic_request = function(target, port, method, path, options)
        state.http_calls[#state.http_calls + 1] = {
          target = target, port = port, method = method, path = path, options = options,
        }
        return case.response
      end,
    },
    shortport = {
      http = function(_, port)
        return port.service == "http" or port.service == "https" or
          port.number == 80 or port.number == 443 or port.number == 8081
      end,
    },
    stdnse = {
      get_script_args = function(name) return (case.args or {})[name] end,
      output_table = function() return {} end,
      format_output = function(success, message)
        state.formatted_success = success
        return "ERROR: " .. message
      end,
    },
  }
  for name, mock in pairs(mocks) do
    local module = mock
    package.loaded[name] = nil
    package.preload[name] = function() return module end
  end
  local environment = setmetatable({}, {__index = _G})
  assert(loadfile(script_path, "t", environment))()
  return environment, state
end

local function run(case, port)
  local environment, state = load_case(case)
  local output = environment.action(host, port or default_port)
  return output, state, environment
end

local function finding(output, id, kind)
  expect(type(output) == "table", "expected structured NSE output")
  equal(#output.findings, 1, "expected exactly one finding")
  equal(output.findings[1].id, id)
  equal(output.findings[1].kind, kind)
  expect(type(output.findings[1].source) == "string", "finding needs a source")
  expect(type(output.findings[1].caveat) == "string", "finding needs a caveat")
end

local function legacy_http()
  return {status = 200, version = "1.0", body = "", header = {
    allow = "OPTIONS, GET, HEAD, POST",
    ["content-length"] = "0", connection = "close",
  }}
end

add("ordinary SSH is a completed nonmatch; default output stays quiet", function()
  local reads = {{true, "SSH-2.0-OpenSSH_10.0p2 Debian-7\r\n"}}
  local output, state = run({args = config("ssh"), reads = reads})
  equal(output.assessment, "no_known_signal")
  equal(#output.findings, 0)
  equal(state.closes, 1)
  equal(state.transport, "tcp")
  equal(run({args = config("ssh", false), reads = reads}), nil)
end)

add("both configurable Cowrie defaults remain weak evidence", function()
  local profiles = {
    {"SSH-2.0-OpenSSH_6.0p1 Debian-4+deb7u2", "cowrie-default-v2.5.0"},
    {"SSH-2.0-OpenSSH_9.2p1 Debian-2+deb12u3", "cowrie-default-2026-10-15"},
  }
  for _, profile in ipairs(profiles) do
    local output = run({args = config("ssh"), reads = {
      {true, "Informational greeting\r\n" .. profile[1]:sub(1, 9)},
      {true, profile[1]:sub(10) .. "\r\n"},
    }})
    finding(output, profile[2], "weak_overlap")
    equal(output.assessment, "weak_signal_only")
  end
end)

add("DTK declaration is exact, including EOF termination", function()
  local announcement = "The Deception ToolKit is running on this system"
  for _, ending in ipairs({"\r\n", ""}) do
    local output, state = run({args = config("dtk"), reads = {
      {true, announcement .. ending}, {false, "EOF"},
    }})
    finding(output, "dtk-announcement", "self_announcement")
    equal(output.assessment, "honeypot_indicated")
    equal(state.closes, 1)
  end
  local changed = run({args = config("dtk"), reads = {{true, announcement .. ".\n"}}})
  equal(changed.assessment, "no_known_signal")
  equal(#changed.findings, 0)
end)

add("only probed version metadata supplies an upstream match", function()
  for _, dtype in ipairs({"table", "probed"}) do
    local port = {number = 18081, protocol = "tcp", state = "open", version = {
      service_dtype = dtype, name = "honeypot", product = "Dionaea Honeypot httpd",
    }}
    local output, state = run({args = config("metadata")}, port)
    equal(state.connects, 0)
    equal(#state.http_calls, 0)
    if dtype == "probed" then
      finding(output, "nmap-version-honeypot", "upstream_match")
      equal(output.assessment, "honeypot_indicated")
    else
      equal(#output.findings, 0)
      equal(output.assessment, "inconclusive")
    end
  end
  local output = run({args = config("metadata")}, {number = 7, protocol = "tcp", state = "open",
    version = {service_dtype = "probed", name = "echo", product = "Example echo service"}})
  equal(output.assessment, "no_known_signal")
end)

add("metadata control characters are escaped and excessive evidence is clipped", function()
  local output = run({args = config("metadata")}, {number = 18081, protocol = "tcp", state = "open",
    version = {service_dtype = "probed", name = "http", product =
      "honeypot\27[31m\n\0\t" .. string.rep("x", 400)}})
  finding(output, "nmap-version-honeypot", "upstream_match")
  local evidence = output.findings[1].evidence
  expect(not evidence:find("[%c]"), "unescaped terminal controls in evidence")
  for _, escape in ipairs({"\\x1B", "\\x0A", "\\x00", "\\x09"}) do
    expect(evidence:find(escape, 1, true), "missing escaped control " .. escape)
  end
  expect(evidence:sub(-3) == "...", "long evidence should be visibly clipped")
  expect(#evidence < 1024, "evidence must stay bounded")
end)

add("legacy HTTP profile sends one bounded OPTIONS without redirects or cache", function()
  local args = config("http")
  args["honeypot-signals.timeout"] = "1500"
  local output, state = run({args = args, response = legacy_http()})
  finding(output, "dionaea-http-options-legacy", "profile_match")
  equal(output.assessment, "honeypot_indicated")
  equal(#state.http_calls, 1)
  equal(state.connects, 0)
  local request = state.http_calls[1]
  equal(request.method, "OPTIONS")
  equal(request.path, "/")
  equal(request.options.timeout, 1500)
  equal(request.options.redirect_ok, false)
  equal(request.options.bypass_cache, true)
  equal(request.options.no_cache, true)
  equal(request.options.max_body_size, 4096)
  equal(request.options.truncated_ok, false)
  equal(request.options.header["Accept-Encoding"], "identity")
  equal(request.options.header.Connection, "close")
end)

add("modern HTTP, extra headers, body, redirect and changed Allow are nonmatches", function()
  local variants = {
    function(r) r.version = "1.1" end,
    function(r) r.header.server = "nginx" end,
    function(r) r.body = "not empty" end,
    function(r) r.status = 302; r.header.location = "https://example.invalid/" end,
    function(r) r.header.allow = "OPTIONS, GET, HEAD" end,
  }
  for _, change in ipairs(variants) do
    local response = legacy_http()
    change(response)
    local output, state = run({args = config("http"), response = response})
    equal(output.assessment, "no_known_signal")
    equal(#output.findings, 0)
    equal(#state.http_calls, 1, "a redirect must not cause a second logical request")
  end
end)

add("HTTP truncation or incomplete transport never becomes a completed negative", function()
  for _, flag in ipairs({"truncated", "incomplete"}) do
    local response = legacy_http()
    response[flag] = true
    local output = run({args = config("http"), response = response})
    equal(output.assessment, "inconclusive")
    equal(#output.findings, 0)
  end
  for _, response in ipairs({false, {status = nil}}) do
    local output = run({args = config("http"), response = response})
    equal(output.assessment, "inconclusive")
  end
end)

add("greeting timeout, partial SSH, connect failure and deadline are inconclusive", function()
  local cases = {
    {reads = {{false, "TIMEOUT"}}, expected = "timeout"},
    {reads = {{true, "SSH-2.0-OpenSSH_6.0p1"}, {false, "EOF"}}, expected = "incomplete"},
    {connect_error = "connection refused", expected = "connect_failed"},
    {clocks = {0, 3001}, expected = "timeout"},
  }
  for _, case in ipairs(cases) do
    case.args = config("ssh")
    local output, state = run(case)
    equal(output.assessment, "inconclusive")
    equal(#output.findings, 0)
    equal(output.probes[1], "ssh greeting: " .. case.expected)
    equal(state.closes, 1)
  end
end)

add("greetings beyond 4096 retained bytes do not produce matches", function()
  local output, state = run({args = config("ssh"), reads = {
    {true, string.rep("x", 4096) .. "\nSSH-2.0-OpenSSH_6.0p1 Debian-4+deb7u2\r\n"},
  }})
  equal(output.assessment, "inconclusive")
  equal(output.probes[1], "ssh greeting: size_limit")
  equal(#output.findings, 0)
  equal(state.reads, 1)
  equal(state.closes, 1)
end)

add("invalid arguments surface errors before any network work", function()
  local bad = {
    {"protocol", "smtp"}, {"protocol", {}},
    {"timeout", "99"}, {"timeout", "30001"}, {"timeout", "100.5"},
    {"timeout", "garbage"}, {"verbose", "yes"},
  }
  for _, item in ipairs(bad) do
    local args = config("ssh")
    args["honeypot-signals." .. item[1]] = item[2]
    local environment, state = load_case({args = args})
    expect(environment.portrule(host, default_port), "invalid arguments should be reported")
    local output = environment.action(host, default_port)
    expect(type(output) == "string" and output:find("ERROR:", 1, true), "expected argument error")
    equal(state.formatted_success, false)
    equal(state.connects, 0)
    equal(#state.http_calls, 0)
  end
end)

add("portrule excludes UDP and non-open TCP; auto covers documented services", function()
  local environment, state = load_case({args = config("auto")})
  for _, port in ipairs({
    {number = 22, protocol = "udp", state = "open"},
    {number = 22, protocol = "tcp", state = "closed"},
    {number = 22, protocol = "tcp", state = "open|filtered"},
    {number = 7, protocol = "tcp", state = "open", service = "echo"},
  }) do
    equal(environment.portrule(host, port), false)
  end
  for _, number in ipairs({22, 2222, 365, 80, 443, 8081}) do
    expect(environment.portrule(host, {number = number, protocol = "tcp", state = "open"}),
      "auto did not select " .. number)
  end
  expect(environment.portrule(host, {number = 49152, protocol = "tcp", state = "open", version = {
    service_dtype = "probed", name = "honeypot", product = "Example honeypot",
  }}), "auto should include an upstream honeypot match")
  equal(state.connects, 0)
  equal(#state.http_calls, 0)
end)

for _, test in ipairs(tests) do
  local ok, message = pcall(test.action)
  if ok then
    passed = passed + 1
    print("PASS " .. test.name)
  else
    io.stderr:write("FAIL " .. test.name .. ": " .. tostring(message) .. "\n")
  end
end
print(("%d/%d focused NSE tests passed"):format(passed, #tests))
if passed ~= #tests then os.exit(1) end
