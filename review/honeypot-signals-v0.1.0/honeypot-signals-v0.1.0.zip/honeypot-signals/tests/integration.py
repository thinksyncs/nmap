#!/usr/bin/env python3
"""Run real NSE checks against temporary localhost fixtures only."""
# SPDX-License-Identifier: BSD-2-Clause

import argparse
import contextlib
import importlib.util
import pathlib
import subprocess
import tempfile
import threading
import urllib.request
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("camouflage_lab", ROOT / "examples/camouflage_lab.py")
lab = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab)


@contextlib.contextmanager
def fixture(profile):
    with lab.LabServer(profile, 0) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield server.server_address[1]
        finally:
            server.shutdown()
            thread.join(timeout=5)


def run_scan(nmap, port, protocol):
    with tempfile.TemporaryDirectory(prefix="honeypot-signals-test-") as tmp:
        xml = pathlib.Path(tmp) / "scan.xml"
        command = [
            nmap, "--unprivileged", "-sT", "-Pn", "-n", "-p", str(port),
            "--script", str(ROOT / "honeypot-signals.nse"),
            "--script-args", f"honeypot-signals.protocol={protocol},honeypot-signals.verbose=true",
            "--script-timeout", "15s", "-oX", str(xml), "127.0.0.1",
        ]
        result = subprocess.run(command, text=True, capture_output=True, timeout=30)
        if result.returncode != 0:
            raise AssertionError(f"Nmap failed:\n{result.stdout}\n{result.stderr}")
        document = ET.parse(xml)
        script = document.find(".//port/script[@id='honeypot-signals']")
        if script is None:
            raise AssertionError(f"Missing NSE output:\n{result.stdout}\n{result.stderr}")
        assessment = script.find("elem[@key='assessment']")
        if assessment is None:
            raise AssertionError(f"Missing structured assessment:\n{result.stdout}\n{result.stderr}")
        ids = {node.text for node in script.findall(".//elem[@key='id']")}
        return assessment.text, ids


def check_health(port):
    # Ignore environment proxy configuration for the loopback fixture.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(f"http://127.0.0.1:{port}/health", timeout=3) as response:
        assert response.status == 200
        assert response.read() == b"ok\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nmap", default="nmap")
    args = parser.parse_args()
    cases = (
        ("normal", "http", "no_known_signal", None),
        ("dionaea-legacy", "http", "honeypot_indicated", "dionaea-http-options-legacy"),
        ("dtk", "dtk", "honeypot_indicated", "dtk-announcement"),
        ("cowrie-legacy", "ssh", "weak_signal_only", "cowrie-default-v2.5.0"),
        ("cowrie-current", "ssh", "weak_signal_only", "cowrie-default-2026-10-15"),
        ("normal", "metadata", "inconclusive", None),
    )
    for profile, protocol, expected, expected_id in cases:
        with fixture(profile) as port:
            if protocol == "http":
                check_health(port)
            assessment, ids = run_scan(args.nmap, port, protocol)
            assert assessment == expected, (profile, expected, assessment)
            assert ids == ({expected_id} if expected_id else set()), (profile, ids)
            if protocol == "http":
                check_health(port)
            print(f"PASS {profile}/{protocol}: {assessment}")
    print(f"PASS {len(cases)} real Nmap localhost integration cases")


if __name__ == "__main__":
    main()
